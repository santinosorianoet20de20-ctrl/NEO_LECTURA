/* =====================  LIBRÍN COMPAÑERO · CONTROLADOR  =====================
   En la lectura, la mascota (Librín, Librón o Librina) cambia de cara y de comentario según lo que pasa:
   - Al entrar: la pregunta para pensar de esa parte (campo "lb" del cuento).
   - Audiolibro (avisos de js/audio): empieza, sigue, por la mitad, pausa y final.
   - Palabras del vocabulario: explica qué significan.
   - Si lo tocan: dice algo divertido.
   Los comentarios "de paso" duran un ratito y después vuelve a la pregunta.
   (En el quiz no hace falta controlador: la pantalla se vuelve a dibujar en
   cada respuesta y Librín sale ya con la reacción que corresponde.)        */
const Companero=(()=>{
  const C=COMP_CFG,L=C.lectura;
  let tVolver=0,toques=0;
  const caja=()=>document.querySelector('[data-cp-lectura]');

  /* Cambia la cara y el comentario. ms = a los cuántos ms vuelve a la pregunta (sin ms, se queda) */
  function decir(reaccion,html,ms){
    const c=caja();if(!c)return false;
    clearTimeout(tVolver);
    const im=c.querySelector('.cp-yo img'),t=c.querySelector('.cp-txt');
    if(im.dataset.r!==reaccion){im.src=CompaneroVista.ruta(reaccion);im.dataset.r=reaccion}
    t.innerHTML=CON_GENERO(html);t.dataset.raw=html; // el texto original, por si después cambia el personaje
    c.classList.remove('pop');void c.offsetWidth;c.classList.add('pop'); // salto y globo nuevo
    if(ms)tVolver=setTimeout(volver,ms);
    return true;
  }
  function volver(){
    const c=caja();if(c)decir(L.pregunta,c.dataset.base);
  }

  /* Palabra del vocabulario: la explica Librín (devuelve false si no está en pantalla) */
  function definir(palabra,definicion){
    return decir(L.palabra,`<b>${ESC(palabra)}:</b> ${ESC(definicion)}`);
  }

  /* Avisos del audiolibro */
  Audiolibro.alEvento((ev,d)=>{
    const c=caja();if(!c)return;
    if(ev==='suena'){
      const [r,t]=d.antes==='pausa'?L.sigue:d.antes==='fin'?L.otraVez:L.empieza;
      decir(r,t,d.antes==='pausa'?2500:C.temporal);
    }
    else if(ev==='mitad')decir(L.mitad[0],L.mitad[1],4000);
    else if(ev==='pausa')decir(L.pausa[0],L.pausa[1]);
    else if(ev==='fin'){
      const preg=c.dataset.pregunta;
      decir(L.fin[0],L.fin[1]+(preg?`<small>${L.finPregunta} ${preg}</small>`:'')+(c.dataset.ultima?`<small>${L.antesDelQuiz}</small>`:''));
    }
  });

  /* Si se elige otra voz en el panel del reproductor, la mascota cambia en el momento
     (Librín ↔ Librón ↔ Librina), con la misma cara que tenía. Corre después del clic del audio,
     que es el que guarda la voz nueva. */
  function refrescar(){
    const c=document.querySelector('[data-cp]');if(!c)return;
    const m=MASCOTA();if(c.dataset.mascota===m.id)return;
    CompaneroVista.precargar();
    c.dataset.mascota=m.id;
    c.classList.remove(...PERSONAJES.map(p=>'cp-'+p.id));c.classList.add('cp-'+m.id);
    c.setAttribute('style',CompaneroVista.colores(m));
    const im=c.querySelector('.cp-yo img');im.src=CompaneroVista.ruta(im.dataset.r);
    document.querySelectorAll('[data-cp-nombre]').forEach(el=>{el.textContent=m.nombre});
    const b=c.querySelector('[data-cp-toque]');if(b)b.setAttribute('aria-label','Tocar a '+m.nombre);
    // el mismo comentario, con "orgulloso" / "orgullosa" según el personaje nuevo
    const t=c.querySelector('.cp-txt'),raw=t&&(t.dataset.raw!==undefined?t.dataset.raw:c.dataset.base);
    if(raw!==undefined)t.innerHTML=CON_GENERO(raw);
    c.classList.remove('pop');void c.offsetWidth;c.classList.add('pop');
  }
  document.addEventListener('click',e=>{if(e.target.closest('[data-audio="voz"]'))refrescar()});
  AudioVoces.alCambiar(refrescar); // por si una cuenta vieja pasó a otro personaje al cargar las voces

  /* Tocar a la mascota */
  document.addEventListener('click',e=>{
    if(!e.target.closest('[data-cp-toque]'))return;
    const [r,t]=L.toques[toques++%L.toques.length];
    decir(r,t,2500);
  });

  return {decir,definir,volver,refrescar};
})();
