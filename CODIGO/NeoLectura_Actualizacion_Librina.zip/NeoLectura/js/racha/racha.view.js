/* =====================  RACHA · VISTA  =====================
   HTML del indicador (menú principal), del detalle y del aviso de racha completa. */
const RachaVista=(()=>{
  const C=RACHA_CFG,T=C.textos;
  Object.assign(ICON,{x:'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>'}); // ícono de cerrar (se suma a utils.js)
  // Imagen fija del fuego: solo para los circulitos chicos del calendario
  const fuego=(encendido,clase='',ancho=48)=>`<img class="rc-fuego ${clase}" src="${encendido?C.img.encendido:C.img.apagado}" alt="" width="${ancho}" height="${Math.round(ancho*1.2)}" draggable="false">`;

  /* Calendario de los últimos 7 días. "mini" = versión chica del indicador */
  function semana(mini,animarHoy){
    return `<ol class="rc-sem${mini?' mini':''}" aria-label="Últimos 7 días">${Racha.semana().map(d=>{
      return `<li class="${d.hecho?'hecho':''}${d.hoy?' hoy':''}${animarHoy&&d.hoy?' prender':''}" aria-label="${d.nombre}${d.hoy?' (hoy)':''}: ${d.hecho?'leído':'sin leer'}">
        <span class="rc-dot">${d.hecho?fuego(true,'',mini?14:22):''}</span><span class="rc-letra">${d.letra}</span></li>`;
    }).join('')}</ol>`;
  }

  /* Indicador en la tarjeta del menú principal */
  function indicador(){
    const e=Racha.estado(),enc=e.tipo==='hecha';
    const est={hecha:T.hecha,pendiente:T.pendiente,apagada:T.apagada}[e.tipo];
    return `<button class="rc-ind rc-${e.tipo}" data-racha="abrir" aria-label="Racha: ${e.dias} ${T.unidad(e.dias)}. ${est} Ver detalle">
      <span class="rc-ind-fuego">${RachaPersonaje.html({estado:enc?'prendido':'dormido',ancho:46})}${e.tipo==='pendiente'?'<i class="rc-alerta" aria-hidden="true">!</i>':''}</span>
      <span class="rc-ind-txt"><b>${e.dias}</b><small>${T.unidad(e.dias)}</small><em>${est}</em></span>
      ${semana(true)}
    </button>`;
  }

  /* Ventana con el detalle de la racha */
  function detalle(){
    const e=Racha.estado(),enc=e.tipo==='hecha';
    const msg=e.tipo==='hecha'?T.detHecha:e.tipo==='pendiente'?T.detPendiente:(e.perdida?T.detApagada:T.detNueva);
    const gana=enc?`<div><small>Mañana ganas</small><b>+${e.mananaGana} pts</b></div>`:`<div><small>Hoy ganas</small><b>+${e.hoyGana} pts</b></div>`;
    return `<div class="rc-modal" data-racha-modal>
      <div class="rc-box rc-${e.tipo}" role="dialog" aria-modal="true" aria-labelledby="rc-det-t">
        <button class="rc-x" data-racha="cerrar" aria-label="Cerrar">${ic('x',18)}</button>
        <div class="rc-hero">${RachaPersonaje.html({estado:enc?'prendido':'dormido',ancho:110,clase:'rc-big'})}</div>
        <h2 id="rc-det-t" class="rc-num"><b>${e.dias}</b><span>${T.unidad(e.dias)}</span></h2>
        <p class="rc-msg">${msg}</p>
        ${semana(false)}
        <div class="rc-stats"><div><small>Tu récord</small><b>${e.mejor} ${e.mejor===1?'día':'días'}</b></div>${gana}</div>
        <p class="rc-como">${T.comoFunciona}</p>
        <button class="rc-btn" data-racha="cerrar">¡A leer! 📖</button>
      </div></div>`;
  }

  /* Aviso al aprobar el primer quiz del día */
  function aviso(res){
    const msg=res.nueva?(res.perdida?T.avisoReinicio(res.perdida):T.avisoNueva):T.avisoSigue(res.dias);
    return `<div class="rc-modal rc-aviso" data-racha-modal>
      <div class="rc-box" role="dialog" aria-modal="true" aria-labelledby="rc-av-t" aria-describedby="rc-av-m">
        <div class="rc-hero"><span class="rc-rayos" aria-hidden="true"></span><span class="rc-chispas" aria-hidden="true"></span>${RachaPersonaje.html({estado:'festeja',ancho:130,clase:'rc-big rc-entra'})}</div>
        <div class="rc-num" aria-hidden="true"><b class="rc-cuenta" data-de="${Math.max(0,res.dias-1)}" data-a="${res.dias}">${Math.max(0,res.dias-1)}</b><span>${T.unidad(res.dias)}</span></div>
        <h2 id="rc-av-t">${T.avisoTitulo} 🔥</h2>
        <p id="rc-av-m" class="rc-msg"><span class="rc-vh">${res.dias} ${T.unidad(res.dias)}. </span>${msg}</p>
        ${res.record?`<span class="rc-record">🏆 ${T.record}</span>`:''}
        ${semana(false,true)}
        <div class="rc-bonus"><span>+${res.bonus}</span> puntos de racha ⭐</div>
        <button class="rc-btn" data-racha="cerrar">${T.boton}</button>
      </div></div>`;
  }

  return {indicador,detalle,aviso};
})();
