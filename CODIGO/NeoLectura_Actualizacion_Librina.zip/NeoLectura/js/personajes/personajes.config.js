/* =====================  PERSONAJES  =====================
   Los personajes de NeoLectura. Cada uno es, a la vez:
   - una VOZ del audiolibro (se elige en Opciones o en el reproductor del cuento), y
   - la MASCOTA que acompaña la lectura, el quiz y las tarjetas: el personaje cuya
     voz elegiste es el que aparece (lo decide MASCOTA() de js/utils.js).

   **Para agregar un personaje nuevo** (por ejemplo, la versión mujer de Librón):
   1. Crear la carpeta img/<id>/ con sus 21 reacciones: los mismos nombres de archivo
      que img/librin/ (saludo.png, bien.png, triste.png…), todas de 513×508 y con el
      libro del mismo tamaño y en el mismo lugar que en las de Librín.
   2. Agregar un renglón abajo, copiando uno parecido.
   Con eso ya aparece en Opciones, en el panel de voces del cuento y como mascota.

   Qué es cada dato:
   - id:      nombre de la carpeta de imágenes (img/<id>/). No cambiarlo después de publicar:
              es lo que queda guardado en la cuenta de cada usuario.
   - nombre:  como se muestra (con tildes).
   - genero:  'm' o 'f'. Sirve para los textos que cambian: "orgulloso" / "orgullosa"
              (en los textos se escribe "orgullos{o}", ver js/companero/companero.config.js).
   - emoji:   por si la imagen no carga.
   - base:    sobre qué voz del equipo se arma su voz: 'f' = de mujer, 'm' = de hombre.
   - tono:    1 = normal (0 a 2). Más alto = más aguda. Algunas voces ignoran el tono.
   - vel:     velocidad propia (1 = normal). Se multiplica por la velocidad elegida (Lenta / Normal / Rápida).
   - det:     cómo suena (se lee debajo del nombre, en la lista de voces).
   - saludo:  lo que dice al elegirlo o al tocar "Probar".
   - color:   color de su nombre en el globito [modo claro, modo oscuro] (mejor si combina con su tapa).
   - cambios: si le falta una cara con cierto sentimiento, cuál usa en su lugar ({'cara':'otra'}).
   - antes:   ids viejos que tuvo (para las cuentas que lo eligieron con ese nombre).
   El primero de la lista es el que se usa si no se eligió ninguno.                       */
const PERSONAJES=[
  {id:'librin', nombre:'Librín', genero:'m', emoji:'📘',
   base:'f', tono:1.65, vel:1.05, det:'Aguda y divertida',
   saludo:'¡Hola, hola! Soy Librín. ¡Vamos a leer juntos!',
   color:['#12787A','#7EE3E3']},

  // Librón no tiene cara preocupada (su 'no-te-rindas' sonríe): al errar en el quiz pone la de la nube
  {id:'libron', nombre:'Librón', genero:'m', emoji:'📚',
   base:'m', tono:.7, vel:.88, det:'Grave y tranquila',
   saludo:'Hola, soy Librón. Ponte cómodo, que empieza el cuento.',
   color:['#B3261E','#FF9A8F'], cambios:{'no-te-rindas':'nublado'}, antes:['gigante']},

  // Voz de mujer, aguda como la de Librín (un poquito más grave y más tranquila, para que no suenen igual)
  {id:'librina', nombre:'Librina', genero:'f', emoji:'🎀',
   base:'f', tono:1.45, vel:1, det:'Dulce y alegre',
   saludo:'¡Hola! Soy Librina. ¡Qué lindo que vengas a leer conmigo!',
   color:['#B4236A','#FF9CCB']}
];
/* Datos que se completan solos (no hace falta escribirlos arriba) */
PERSONAJES.forEach(p=>{
  p.carpeta=p.carpeta||`img/${p.id}/`;
  p.img=p.carpeta+'saludo.png';
  p.cambios=p.cambios||{};
  p.antes=p.antes||[];
});
/* Busca un personaje por su id (o por un id viejo). null si no existe. */
const PERSONAJE=id=>PERSONAJES.find(p=>p.id===id)||PERSONAJES.find(p=>p.antes.includes(id))||null;
