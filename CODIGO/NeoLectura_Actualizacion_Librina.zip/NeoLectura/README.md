# NeoLectura — versión modular

Esta versión separa el código original por responsabilidades, manteniendo el contenido y la lógica originales.
Desde esta actualización incluye el **inicio de sesión** (degradé azul–turquesa, tarjeta de vidrio esmerilado) con Librín reaccionando a lo que hace el usuario.

## Estructura

- `index.html` — estructura HTML mínima y carga de archivos.
- `css/styles.css` — estilos originales de la app.
- `css/login.css` — estilos del inicio de sesión (fondo, tarjeta, botones y animaciones de Librín).
- `css/racha.css` — estilos de la racha diaria (indicador, detalle y aviso).
- `css/audio.css` — estilos del reproductor del audiolibro, del texto que se pinta mientras se lee y de las voces en Opciones (todo empieza con `ap-`).
- `css/companero.css` — la mascota compañera con su globito (lectura y quiz, todo empieza con `cp-`; el nombre va del color de cada personaje) y la mascota chica de las tarjetas.
- `css/cuentos.css` — el camino de niveles de la pantalla principal, el dibujo de cada escena, los párrafos del cuento y el aviso de nivel desbloqueado.
- `img/racha/` — fuego de racha (`fuego.svg` encendido y `fuego-apagado.svg`).
- `img/escenas/` — los dibujos de cada cuento: `<cuento>/portada.svg` y `parte-1.svg`, `parte-2.svg`, `parte-3.svg`. Son **bocetos simples** para pasarle a otra IA; `img/escenas/LEEME.md` explica las medidas, el estilo, cómo es cada personaje, qué muestra cada escena y cómo reemplazarlos.
- `img/librin/` — Librín: la versión base (`saludo.png`) y sus 20 reacciones (PNG con fondo transparente, todas de 513×508 para que no "salte" al cambiar): `bien`, `excelente`, `guino`, `vamos`, `orgullo`, `increible`, `animo`, `ojos-cerrados`, `aprender`, `logrado` y las nuevas `muy-bien`, `segui-asi`, `mejorar`, `vos-podes`, `nublado`, `no-te-rindas`, `gran-trabajo`, `pensando`, `genial`, `triste`. Se usan en el inicio de sesión, en las tarjetas y en el compañero de lectura.
- `img/libron/` — Librón: la versión base (`saludo.png`) y sus 20 reacciones, con **los mismos nombres** que las de Librín, mismo tamaño y ubicadas igual (recortadas de la hoja de reacciones, sin fondo ni globitos).
- `img/librina/` — Librina (el libro rosa con moño lila): igual que Librón, la versión base y sus 20 reacciones con los mismos nombres, tamaño y ubicación que las de Librín (ver «Personajes»).
- `js/personajes/personajes.config.js` — **los personajes** (Librín, Librón, Librina): nombre, si es él o ella, cómo suena su voz, el color de su nombre y sus cambios de cara. **Para agregar un personaje nuevo, se agrega un renglón acá** (ver «Personajes»).
- `js/utils.js` — utilidades, iconos, `PARRAFOS()` (párrafos y versos de los cuentos), `MASCOTA()` (el personaje cuya voz eligió el usuario), `MASCOTA_RUTA('reacción')` y `MASCOTA_IMG('reacción')`, que ponen la imagen de la mascota, y `CON_GENERO()` (cambia `orgullos{o}` por *orgulloso* u *orgullosa* según el personaje).
- `js/cuentos/` — **los cuentos: cada uno es un nivel y vive en su propio archivo** (ver «Cuentos y niveles»):
  - `cuentos.registro.js` — explica qué lleva cada cuento y define `registrarCuento()`.
  - `caperucita-roja.js`, `el-gato-con-botas.js`, `barba-azul.js`, `hansel-y-gretel.js` — texto (de los PDF del proyecto) dividido en 3 partes, vocabulario, preguntas de Librín, descripción de cada dibujo y quiz.
  - `cuentos.camino.js` — ordena los cuentos del más corto al más largo, arma los niveles (`STORIES`), marca el vocabulario, mezcla las opciones del quiz y dice qué nivel está desbloqueado (`Camino`). En `CAMINO_CFG` se cambia el orden, la carpeta de los dibujos y su formato.
- `js/data/config.js` — tamaños de letra, cantidad de partes y **los créditos del equipo** (`EQUIPO`: integrantes y roles que se ven en *Créditos*).
- `js/state.js` — estado, localStorage y funciones relacionadas con el progreso (un progreso por usuario). Las cuentas nuevas empiezan con **0 puntos**.
- `js/screens.js` — pantallas/interfaz.
- `js/filtro/` — **filtro de nombres** (sin malas palabras, temas fuertes ni datos personales):
  - `filtro.config.js` — las listas de palabras (partes, enteras, permitidas y reservadas), cuántos números se aceptan y los mensajes. **Para agregar o sacar una palabra, se cambia acá.**
  - `filtro.logic.js` — `Filtro.revisar(nombre)` (devuelve el motivo o nada), `Filtro.permitido(nombre)` y `Filtro.mostrar(nombre)` (muestra "Lector" en lugar de un nombre no permitido de antes).
- `js/login/` — módulo de inicio de sesión:
  - `login.config.js` — textos, frases de Librín, qué imagen usa en cada momento, avatares y reglas. **Para cambiar un texto o una reacción, se cambia acá.**
  - `login.storage.js` — cuentas (localStorage), sesión (sessionStorage) y hash de contraseñas.
  - `login.validation.js` — validación de usuario, contraseña y nombre, y fuerza de la contraseña.
  - `login.mascot.js` — Librín: cambia de imagen según el estado, se inclina hacia el puntero y muestra el globito.
  - `login.view.js` — HTML de la pantalla de inicio de sesión.
  - `login.controller.js` — eventos, reacciones de Librín y conexión con la app (entrar / salir).
- `js/racha/` — módulo de racha diaria:
  - `racha.config.js` — puntos por día, tope, imágenes y textos. **Para cambiar cuántos puntos da la racha, se cambia acá.**
  - `racha.logic.js` — fechas, estado de la racha (hecha / pendiente / apagada) y suma del día.
  - `racha.personaje.js` — **Fueguito**, el fuego de la racha dibujado en la página para poder animarlo (prendido, dormido o festejando).
  - `racha.view.js` — HTML del indicador, del detalle y del aviso de racha completa.
  - `racha.controller.js` — abre y cierra las ventanas, animación del aviso.
- `js/audio/` — módulo del audiolibro (lectura en voz alta):
  - `audio.config.js` — segundos que saltan los botones, velocidades (Lenta, Normal, Rápida) y textos. **Para cambiar el salto de 5 segundos o una velocidad, se cambia acá** (cómo suena cada personaje está en `js/personajes/personajes.config.js`).
  - `audio.voces.js` — arma los personajes sobre las voces en español del equipo (elige una de mujer o de hombre según cada personaje) y pasa las cuentas viejas que tenían una voz del navegador al personaje que más se le parece.
  - `audio.motor.js` — habla con la voz del navegador, lleva la cuenta del tiempo y de la palabra que se está leyendo, pausa, reanuda, salta y cambia volumen, voz y velocidad.
  - `audio.view.js` — HTML del reproductor, del texto palabra por palabra, del panel de voces y de las tarjetas de Opciones (y sus íconos).
  - `audio.controller.js` — eventos de los botones, del volumen y de la elección de voz; pinta el texto mientras se lee y abre/cierra el panel de voces.
- `js/companero/` — la mascota compañera de lectura (Librín, Librón o Librina):
  - `companero.config.js` — todo lo que dice la mascota y qué cara pone en cada momento. **Para cambiar sus frases, se cambia acá.** Donde cambia si es él o ella se escribe `{o}` (`orgullos{o}`).
  - `companero.view.js` — HTML de la mascota con su globito (lectura, preguntas del quiz y resultado).
  - `companero.controller.js` — en la lectura, cambia el comentario según el audiolibro, el vocabulario o si lo tocan.
- `js/ranking/` — ranking de cuentas reales:
  - `ranking.config.js` — textos y cuántos se muestran.
  - `ranking.storage.js` — **fuente de datos**: lee y guarda la tabla del ranking (hoy en localStorage). Es lo único que habría que cambiar para usar un servidor.
  - `ranking.logic.js` — anota los puntos de la cuenta al guardar el progreso y arma la lista ordenada.
  - `ranking.view.js` — pantalla del ranking.
- `css/ranking.css` — detalles de la pantalla del ranking (las filas usan los estilos de siempre).
- `js/pruebas/prueba-dia.js` — **TEMPORAL**: botón para cambiar de día y probar la racha (ver «Racha diaria»).
- `js/navigation.js` — navegación, eventos y lógica de interacción.

## Cuentos y niveles

Los niveles ahora son **los 4 cuentos de los PDF**, en orden del más corto al más largo. Cada uno es un nivel: **3 partes + un quiz**, igual que los niveles de antes (audiolibro, texto que se pinta, vocabulario, Librín y puntos).

| Nivel | Cuento | Duración de cada parte (aprox.) | Quiz | Para aprobar |
|---|---|---|---|---|
| 1 | Caperucita Roja (Perrault) | 1,5 · 1,6 · 1,8 min | 6 preguntas, 3 opciones | 3 correctas |
| 2 | El gato con botas (Perrault) | 3,7 · 3,6 · 3,9 min | 8 preguntas, 4 opciones | 5 correctas |
| 3 | Barba Azul (Perrault) | 4,2 · 4,1 · 4,9 min | 9 preguntas, 4 opciones | 6 correctas |
| 4 | Hansel y Gretel (Grimm) | 5,8 · 6,5 · 6,3 min | 10 preguntas, 4 opciones | 7 correctas |

- **Hay que aprobar cada nivel para pasar al siguiente.** En la pantalla principal los cuentos bloqueados tienen un candado que dice cuál hay que aprobar; tampoco se puede entrar por la dirección. Al aprobar, el resultado avisa «🔓 ¡Desbloqueaste el Nivel 2…!» y *Siguiente nivel* abre el cuento que sigue.
- **Partes de la misma duración:** cada cuento está cortado en 3 partes que duran casi lo mismo (menos de 10 % de diferencia), siempre al terminar un párrafo y en un momento de la historia que tenga sentido. En la última parte están las moralejas. Para revisarlo después de cambiar un texto: `Camino.medir()` en la consola del navegador.
- **Texto:** es el de los PDF, completo, con los errores de tipeo corregidos («pálida corno» → «como», «la oreja solamente» → «la vieja», etc.). Se ve en párrafos (las moralejas, en versos).
- **Vocabulario:** cada cuento tiene sus palabras difíciles (`palabras`) y se marcan solas la primera vez que aparecen en cada parte. Hay más en los cuentos más difíciles (castellano antiguo: «afligiros», «heredad», «dragón» como soldado…).
- **Quizzes más difíciles:** dentro de cada cuento las preguntas van por parte (dice «Sobre la parte 2») y se ponen más difíciles hacia el final; entre cuentos hay más preguntas, más opciones y hace falta acertar más. Los primeros niveles preguntan qué pasó; los últimos, por qué pasó, en qué orden, qué significa una palabra en el texto o qué enseña la moraleja.
- **Opciones:** en el archivo del cuento la primera opción es siempre la correcta; la app las mezcla al mostrarlas (siempre igual para cada pregunta).
- **Dibujos:** cada parte muestra el dibujo de su escena arriba del texto, y cada tarjeta tiene su portada (ver `img/escenas/LEEME.md`).
- **Para agregar un cuento:** copiar uno de los archivos de `js/cuentos/`, cambiar los datos, sumar su `<script>` en `index.html` (antes de `cuentos.camino.js`) y sus dibujos en `img/escenas/<id>/`. Se ubica solo en el camino según su largo (o con un orden fijo en `CAMINO_CFG.orden`).
- El progreso de los cuentos viejos (El León y el Ratón, El Roble y la Caña) ya no se usa, pero los puntos que se habían ganado se conservan.

## Filtro de nombres

NeoLectura es para chicos, así que los nombres pasan por un filtro (`js/filtro/`) al **crear una cuenta** y al **cambiar el nombre en Opciones**. No se aceptan:

- **Malas palabras e insultos** (rioplatenses, de otros países y en inglés), también los suaves que no van en primaria (*tonto*, *bobo*, *inútil*).
- **Partes íntimas del cuerpo y contenido sexual**, incluidas las formas que usan los chicos (*pito*, *pitulín*, *lolas*…) y las palabras "de doctor" (*clítoris*, *testículos*…).
- **Palabras "de baño"** (*caca*, *pis*, *pedo*): no son graves, pero quedan feas en un nombre.
- **Violencia, muerte y temas fuertes** (matar, muerto, suicidio, nazismo…), **drogas y alcohol** (también *cerveza*, *birra*, *fernet*) e **insultos discriminatorios**.
- **Trampas comunes:** letras repetidas (*puuuta*), números en lugar de letras (*p0rn0*, *1diota*), símbolos o puntos en el medio (*m.i.e.r.d.a*) y palabras pegadas (*elpelotudo*).
- **Nombres reservados**, para que nadie se haga pasar por un adulto o por la app: *admin*, *profe*, *seño*, *docente*, *moderador*, *NeoLectura*…
- **Datos personales:** más de 4 números (podría ser un teléfono o un DNI) o algo que parezca un mail o una página (@, gmail, www, .com).
- **Nombres sin letras** (al menos 2 letras). En Opciones, solo letras, números y espacios (sin emojis ni símbolos).

No bloquea palabras inocentes que contienen otra (*computadora*, *Penélope*, *Vergara*, *película*, *Analía*, *recoger*, *Felipito*, *Pitágoras*, *Capitán*, *Coitiño*): se probó con más de 300 nombres, apellidos y palabras comunes. Tampoco bloquea palabras sobre quién es una persona (como *gay* o *trans*), porque no son insultos; sí los insultos discriminatorios. El mensaje nunca dice qué palabra se bloqueó (así no se aprende a esquivarla). Las cuentas creadas antes del filtro pueden seguir entrando, pero si su nombre no está permitido se muestra como **"Lector"** en el ranking y en la pantalla principal.

> Ningún filtro es perfecto: alguien muy creativo puede encontrar una forma de escribir algo feo. Conviene que un docente revise el ranking de vez en cuando. Las listas se amplían fácil en `filtro.config.js`.

## Inicio de sesión

- Aparece apenas se abre la app. La sesión dura mientras la pestaña esté abierta (si se recarga, sigue adentro; si se vuelve a abrir la app, pide iniciar sesión otra vez).
- **Iniciar Sesión**: usuario, contraseña (con botón para verla), "Recordarme" y "¿Olvidaste tu contraseña?". Botones **Entrar 🚀** y **Crear cuenta ✨**.
- **Crear Cuenta**: **un solo nombre** (el nombre de usuario, que es también el que se muestra, con la primera letra en mayúscula: `sofía_10` → *Sofía_10*), contraseña con medidor de 1 a 3 estrellas y personaje (avatar). Avisa mientras se escribe si el nombre está libre, si ya lo tiene otra cuenta o si no está permitido. El nombre que se muestra se puede cambiar después en *Opciones*.
- El usuario admite tildes y ñ, y no distingue mayúsculas ni tildes: *Sofía*, *sofia* y *SOFIA* son la misma cuenta.
- **o entra como invitado**: usa el progreso guardado de siempre (`neolectura.v1`), así no se pierde lo que ya estaba.
- Cada usuario tiene su propio progreso guardado en `neolectura.v1:<usuario>`.
- Respeta el tema Claro/Oscuro/Automático de Opciones y la opción de "reducir movimiento" del sistema.
- **Un solo ojito en la contraseña:** Microsoft Edge agrega su propio botón para ver la contraseña; se oculta con `::-ms-reveal` en `login.css`, así queda solo el de la app.
- **Personajes siempre dentro de la tarjeta:** la grilla usa columnas que no pueden ser más anchas que la tarjeta. Además, si el equipo no tiene el emoji 🧑‍🚀 "unido" (pasa en algunos Windows, que lo dibujan como 🧑🚀), se usa el emoji `alt` del avatar (🚀). Lo decide `LOGIN_EMOJI()` en `login.config.js`.

### Reacciones de Librín

| Momento | Imagen |
|---|---|
| Esperando (se mece saludando) | `saludo.png` |
| Escribe el usuario o el nombre | `aprender.png` |
| Escribe la contraseña (no mira) | `ojos-cerrados.png` |
| Muestra la contraseña (espía) | `guino.png` |
| Error en un campo | `vamos.png` |
| Contraseña incorrecta | `animo.png` |
| Usuario libre / volver a iniciar sesión | `bien.png` |
| Contraseña súper segura | `excelente.png` |
| Elige personaje / abre Crear cuenta | `increible.png` |
| Cosquillas (tocarlo 4 veces rápido) | `orgullo.png` |
| Entró a la app (salta) | `logrado.png` |

Además se inclina hacia el puntero, da consejos si lo tocan y, si nadie lo usa por un rato, hace una reacción solo (`reaccionSola` en `login.config.js`).

## Racha diaria de lectura

- Se suma **1 día de racha al aprobar el primer quiz del día** (aprobar = llegar a las correctas que pide ese cuento). Los demás quizzes de ese día no suman otro día.
- Si pasa un día entero sin aprobar un quiz, la racha se apaga y vuelve a empezar desde 1.
- **Puntos extra**: cada día de racha da 5 puntos más que el anterior (día 1: +5, día 2: +10, día 3: +15…), con un tope de +100 por día (desde el día 20). Para comparar: leer una parte da +50 y cada respuesta correcta +100, así que la racha no desbalancea el sistema.
- **Indicador** en la tarjeta del menú principal: fuego encendido (hoy ya leíste), fuego dormido con "!" (falta el quiz de hoy) o apagado (racha en 0), con los últimos 7 días. Al tocarlo se abre el detalle (semana, récord y cuántos puntos se ganan hoy).
- **Aviso de racha completa**: aparece al aprobar el primer quiz del día, con el fuego, el número de días, la semana, los puntos ganados y "¡Nuevo récord!" si corresponde.
- Usa la fecha del dispositivo y se guarda en el progreso de cada usuario (`S.racha`). "Reiniciar progreso" en Opciones también reinicia la racha.

### Fueguito animado

El fuego de la racha es un personaje (**Fueguito**) dibujado directamente en la página (`js/racha/racha.personaje.js`), así cada parte se puede mover por separado. Las animaciones están en `css/racha.css` («Fueguito animado»):

| Cuándo | Qué hace |
|---|---|
| Racha de hoy hecha (indicador y detalle) | Parpadea, mueve las llamitas de los costados, la llama de adentro late, le salen chispitas y se balancea. Si le pasás el mouse (o lo tocás), salta. |
| Racha pendiente o apagada | Duerme: respira despacio y le salen "z" flotando. |
| Aviso de racha completa | Entra creciendo, pone ojitos felices y la boca abierta, y salta de alegría 4 veces (la sombra se achica en cada salto). |

Si el sistema tiene activado *reducir movimiento*, queda quieto. Las imágenes `img/racha/fuego.svg` y `fuego-apagado.svg` tienen el mismo dibujo y se siguen usando en los circulitos chicos del calendario.

### Probar la racha (botón temporal)

Abajo a la izquierda hay un botón **🧪 Prueba** (solo con la sesión abierta): **Día +1** adelanta un día y **Hoy** vuelve a la fecha real. El día simulado se guarda en el navegador, así que sigue igual al recargar. Solo afecta a la racha. Ejemplo: aprobar un quiz → *Día +1* → la racha queda «pendiente» → aprobar otro quiz → 2 días (+10 puntos) → *Día +1* dos veces → la racha se apaga.

**Para quitarlo:** borrar la carpeta `js/pruebas/` y su línea `<script>` en `index.html`. La racha usa `Racha.usarReloj()` (en `racha.logic.js`), que sin el módulo de prueba sigue con la fecha real. Si después de probar quedan días «del futuro» en la racha, se limpian con *Reiniciar progreso* en Opciones.

## Ranking

- **Solo cuentas reales:** se sacaron los jugadores inventados. Aparecen únicamente las cuentas creadas con *Crear cuenta*; el invitado puede ver el ranking pero no aparece en él.
- **Se mantiene entre sesiones:** cada vez que se guarda el progreso de una cuenta (al leer una parte, al terminar un quiz, al cambiar el nombre…), se anotan su nombre, su personaje y sus puntos en una tabla guardada en el navegador (`neolectura.ranking` en localStorage). Al cerrar y volver a abrir la app, siguen ahí. Las cuentas creadas antes de esta actualización se agregan solas con el progreso que ya tenían.
- **Pantalla:** la mascota te señala («¡Buen trabajo!») y dice en qué puesto estás. Tu fila tiene borde turquesa y dice *Tú*.
- **Importante:** como la app no tiene servidor, el ranking muestra las cuentas creadas **en ese dispositivo/navegador**. Para un ranking compartido entre todas las compus hay que guardar la tabla en un servidor (por ejemplo, Supabase o Firebase): alcanza con reemplazar `ranking.storage.js` por uno que tenga las mismas funciones (`leer`, `guardar`, `borrar`).

## Personajes

NeoLectura tiene tres personajes: 📘 **Librín**, 📚 **Librón** y 🎀 **Librina** (el libro rosa con moño lila). Cada uno es **una voz del audiolibro y una mascota**: el personaje que eliges en *Opciones → Personaje y voz* (o en el botón 🗣 del reproductor del cuento) es el que te lee los cuentos **y** el que aparece en las tarjetas de inicio, niveles, créditos y ranking, en la lectura y en los quizzes, con sus propias reacciones y su nombre de su color (Librín turquesa, Librón rojo, Librina rosa). Si lo cambias desde el reproductor, la mascota cambia en el momento, con la misma cara. El inicio de sesión sigue con Librín, porque ahí todavía no hay un usuario elegido.

| Personaje | Voz | Notas |
|---|---|---|
| 📘 Librín | Aguda y divertida (voz de mujer, tono 1,65, un poco más rápida) | Es el que se usa si no se eligió ninguno |
| 📚 Librón | Grave y tranquila (voz de hombre, tono 0,7, un poco más lenta) | Como su `no-te-rindas` sonríe, al errar usa `nublado` |
| 🎀 Librina | Dulce y alegre (voz de mujer, tono 1,45): aguda como la de Librín, un poco más grave y tranquila para que no suenen igual | Dice "orgullosa" donde los otros dicen "orgulloso" |

**Cómo agregar un personaje** (por ejemplo, la versión mujer de Librón):

1. Poner sus 21 reacciones en `img/<id>/` con **los mismos nombres** que las de `img/librin/` (`saludo.png`, `bien.png`… `triste.png`), todas de **513×508**, con el libro del mismo tamaño y en el mismo lugar que en las de Librín (así no "salta" al cambiar de personaje).
2. Agregar un renglón en `js/personajes/personajes.config.js` (copiando el de Librina y cambiando `id`, `nombre`, `genero`, `base` —`'f'` o `'m'`—, `tono`, `vel`, `det`, `saludo` y `color`). Si le falta alguna cara, se indica en `cambios` cuál usar en su lugar.

Nada más: aparece solo en Opciones, en el panel del cuento y como mascota.

### Arreglos en las reacciones de Librina

Las reacciones vienen de dos hojas de 10 dibujos cada una, más la imagen base. Al recortarlas se les sacó el fondo y los globitos de texto (blancos y de colores; la nube de lluvia de `nublado` se mantiene), y se ubicaron con el libro del mismo ancho y los pies a la misma altura que Librín en cada reacción. Además se corrigió:

- **`pensando`**: le faltaba el brazo derecho; se le agregó el de la imagen base, pegado al borde de las páginas.
- **`animo`**: tenía una rayita rosa fuerte cruzando el guante y la esquina del libro; se borró.
- **Pedacitos sueltos** de los dibujos vecinos que quedaban en el borde de algunas (por ejemplo, una puntita verde en `aprender`).
- **Colores parejos:** en una de las hojas el rosa del libro y el lila del moño eran más claros; ahora todas usan los de la imagen base.
- **Textos:** las frases de los globitos estaban en masculino ("¡Qué orgulloso de vos!", "¡Muy bien echo!"); en la app, la mascota dice "orgullosa" cuando es Librina.

## Mascota compañera

La mascota (Librín, Librón o Librina: el personaje que elegiste) acompaña la lectura y los quizzes con un globito. En las tarjetas de inicio, niveles y créditos aparece saludando, con un libro y festejando. Las frases son las mismas para todos los personajes (en `companero.config.js`).

**En la lectura** (debajo del texto):

| Momento | Cara | Qué dice |
|---|---|---|
| Al entrar a una parte | `pensando` | La pregunta para pensar de esa parte (`librin` en el archivo del cuento). En la última parte agrega que después viene el quiz |
| Empieza el audiolibro | `guino` | Que siga con la vista las palabras azules (unos segundos y vuelve a la pregunta) |
| Por la mitad | `vos-podes` | ¡Ya vas por la mitad! |
| Pausa / sigue | `ojos-cerrados` / `segui-asi` | Hacemos una pausa… / ¡Seguimos! |
| Termina | `muy-bien` | ¡Muy bien! + «¿Ya puedes responder?» con la pregunta de la parte |
| Toca una palabra subrayada | `aprender` | Qué significa (reemplaza la cajita de definición de antes) |
| La tocan | `excelente`, `genial`, `gran-trabajo`, `segui-asi` | Algo divertido |

**En el quiz** (debajo de las opciones): da ánimo antes de responder (`vamos` en la primera, `pensando` en las del medio, `vos-podes` en la última), festeja los aciertos con globo verde (`muy-bien`, `gran-trabajo`, `genial`, `excelente`, `increible`, van rotando) y en los errores dice cuál era la respuesta con globo rojo y **siempre con cara triste** (`no-te-rindas`, preocupado/a, o `nublado`; como el `no-te-rindas` de Librón sonríe, Librón usa `nublado` en su lugar). En el resultado: `increible` si respondió todo bien, `logrado` si aprobó, `orgullo` si terminó el último cuento del camino, `nublado` («Si te cuesta un poco más, está bien…») si no aprobó y `triste` («Hoy no te salió como querías… pero cada intento es una nueva oportunidad») si no acertó ninguna. En el ranking, la mascota te señala (`gran-trabajo`). Al terminar el quiz siempre está el botón **🏠 Volver al menú** (a la pantalla principal), además de *Siguiente nivel* / *Ver el cuento* o *Repasar* / *Reintentar*.

Para un cuento nuevo, alcanza con ponerle `librin:'…'` a cada parte (la pregunta la dice la mascota que esté elegida); si falta, dice una frase general.

## Audiolibro (lectura en voz alta)

En cada parte del cuento, debajo del título, hay un reproductor compacto:

| Botón | Qué hace |
|---|---|
| ⏮ | Reinicia la parte desde el principio y la lee de nuevo |
| ↺5 | Retrocede 5 segundos |
| ▶ Escuchar / ⏸ Pausar / ▶ Reanudar | Un solo botón para iniciar, pausar y reanudar (cambia según el momento). Al terminar dice **Otra vez** |
| 5↻ | Adelanta 5 segundos |
| 🔊 + barrita | Volumen. Tocar el parlante silencia / vuelve al volumen anterior |
| 🗣 Librina ▾ | Abre el panel con los **personajes** (Librín, Librón y Librina) y la **velocidad** (en el celular sube desde abajo) |

- Abajo de los botones se ve el avance (tiempo actual, barra y duración).
- El volumen es el mismo que el de **Opciones → Volumen de la voz** (versión grande, con porcentaje y botón **Probar**). Se guarda en el progreso de cada usuario (`S.vol`, de 0 a 1).
- El audio se corta solo al pasar de parte, al tocar «Volver», al usar el botón atrás del navegador y al cerrar sesión.
- En compu el reproductor ocupa una fila; en tablet, dos; en celular, tres (botones · avance · voz y volumen).

### Texto sincronizado

- Mientras suena, el texto se **pinta del azul de la app** (`#1B7DCB`; en modo oscuro, un celeste que se lee bien) a medida que se lee, y la palabra que se está diciendo queda **resaltada**.
- En pausa queda marcada la palabra desde donde va a seguir; con ⏮, ↺5 y 5↻ el pintado se mueve junto con el audio; al terminar queda todo pintado.
- Si el texto es largo (letra "Muy grande", celular), la pantalla **acompaña la lectura** sola. Si el usuario mueve la pantalla para mirar otra cosa, deja de acompañar hasta que toque un botón del reproductor.
- Las palabras del vocabulario siguen siendo botones con su definición.
- Con las voces que avisan por qué palabra van (las de Windows, las naturales de Edge, las de Mac/iPhone) el pintado es exacto. Con las que no avisan (las de Google en Chrome) se calcula por tiempo, contando una pausita en cada coma, y se vuelve a acomodar al empezar cada frase.

### Voces

- **Solo voces de personajes:** se elige entre **Librín, Librón y Librina** (ver «Personajes»). Ya no aparecen las voces sueltas del navegador (Elena, Tomás…).
- **Dónde se eligen:** en **Opciones → Personaje y voz** y en el botón 🗣 del reproductor de cada cuento. Es la misma elección (se guarda en `S.voz` y `S.ritmo` de cada usuario), así que se cambia en un lado y se ve en el otro.
- **Velocidad:** 🐢 **Lenta** (25 % más lenta), 🙂 **Normal** o 🐇 **Rápida** (30 % más rápida), para cualquier personaje. Se ajustan en `ritmos` de `audio.config.js`. Cuando no es Normal, el botón del reproductor muestra la tortuga o el conejo.
- **Cada personaje se arma sobre una voz del equipo** (de mujer o de hombre, según su `base`), cambiándole el tono y la velocidad. Se prefiere una voz **instalada** (las que necesitan internet a veces ignoran el tono) y de Argentina, Uruguay o Latinoamérica antes que de España (orden en `paises` de `audio.config.js`). El navegador no dice si una voz es de mujer o de hombre, así que se adivina por el nombre (Elena, Tomás, Sabina, Raúl…). Si el equipo no tiene voces en español, los personajes usan la voz que venga por defecto y Opciones lo avisa.
- **Cada voz aplica la velocidad a su manera** (algunas justo, otras más o menos, y algunas la ignoran). Por eso el motor **mide** lo rápido que habla cada personaje **en cada velocidad** mientras lee y cuando saluda, y lo guarda en el navegador (`neolectura.audio.medidas`): así el reloj, la barra, el texto azul y los saltos de 5 s van bien, desde la próxima vez desde el principio. Si se mide que la voz no cambia de velocidad en ese navegador, aparece un aviso debajo de los botones de velocidad.
- **Cambiar mientras suena:** el cuento sigue desde la misma palabra con el personaje o la velocidad nueva. Si está en pausa o sin empezar, el personaje saluda ("¡Hola! Soy Librina…") para que se escuche cómo es, sin perder por dónde iba.
- **Cuentas de versiones anteriores:** quien tenía elegida una voz del navegador pasa solo a **Librón** si era de hombre o a **Librín** si no; quien tenía el estilo o la voz *Gigante*, a Librón.

### Cómo funciona por dentro

La app usa la voz del navegador (Web Speech API), que no tiene barra de tiempo ni deja adelantar o retroceder. Por eso `audio.motor.js`:

1. Corta el texto en frases y las lee de a una (así Chrome no corta la voz a los ~15 segundos).
2. Guarda la posición como "letra por la que va" y la convierte a segundos con una velocidad estimada (las comas cuentan como unas letras más, por la pausita). Esa velocidad se ajusta sola midiendo cuánto tarda la voz real en cada frase. Si la voz avisa por qué palabra va (evento `boundary`), se usa ese dato, que es exacto.
3. Pausar = cortar la voz y recordar la palabra; reanudar = volver a hablar desde esa palabra (funciona igual en todos los navegadores).
4. Adelantar/retroceder = mover la posición 5 segundos (redondeando al comienzo de una palabra) y seguir hablando desde ahí.
5. Si se cambia el volumen, la voz o la velocidad mientras suena, sigue desde la misma palabra con el cambio aplicado.
6. Como cada voz habla a su ritmo y aplica la velocidad a su manera, lo rápido que habla se mide y se guarda **por personaje y por velocidad** (cada 3 s cuando la voz avisa por qué palabra va, y al terminar cada frase). Si todavía no hay medida para una velocidad, se calcula a partir de otra velocidad del mismo personaje.
7. Para pintar el texto, cada palabra va en un `<span data-i="…">` con la letra donde empieza; el controlador marca como `leido` las anteriores a la palabra actual y como `actual` la que se está diciendo.

> Como los tiempos son estimados, los 5 segundos pueden no ser exactos al primer salto; después de la primera frase la estimación se ajusta. Algunas voces (por ejemplo, en algunos Android) ignoran el volumen: en ese caso se usa el volumen del dispositivo.

> Es un prototipo sin servidor: las cuentas quedan guardadas en el navegador de este dispositivo. En una app real, el usuario y la contraseña se verifican en un servidor.

## Importante

Las cuentas nuevas (y el invitado nuevo) empiezan con **0 puntos** (`points` en `DEF`, `js/state.js`). *Reiniciar progreso* también vuelve a 0. Las cuentas que ya existían conservan sus puntos.

Abrir `index.html` desde un servidor local/repo web es recomendable para probar el proyecto (también funciona abriéndolo directo).
