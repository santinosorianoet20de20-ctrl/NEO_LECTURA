# NeoLectura — versión modular

Esta versión separa el código original por responsabilidades, manteniendo el contenido y la lógica originales.

## Estructura

- `index.html` — estructura HTML mínima y carga de archivos.
- `css/styles.css` — estilos originales.
- `js/utils.js` — utilidades, iconos y mascota.
- `js/illustrations.js` — ilustraciones SVG y generación de portadas.
- `js/data/stories.js` — cuentos, niveles, partes y preguntas.
- `js/data/config.js` — ranking inicial, tamaños de letra y cantidad de partes.
- `js/state.js` — estado, localStorage y funciones relacionadas con el progreso.
- `js/screens.js` — pantallas/interfaz.
- `js/navigation.js` — navegación, eventos y lógica de interacción.

## Importante

No se cambió intencionalmente la lógica ni el contenido del programa. La modificación consiste en separar el mismo código en archivos y cargar esos archivos en el orden necesario.

Abrir `index.html` desde un servidor local/repo web es recomendable para probar el proyecto.
