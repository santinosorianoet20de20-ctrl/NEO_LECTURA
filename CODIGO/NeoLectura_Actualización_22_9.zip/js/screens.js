/* =====================  PANTALLAS  ===================== */
const bar=(title,back)=>`<header class="hdr bar"><button class="back" data-a="nav" data-to="${back}">${ic('back',16)} Volver</button><h2>${ESC(title)}</h2><span></span></header>`;

function starsRow(){const n=starCount();return `<div class="stars" aria-label="${n} de 3 estrellas">${[0,1,2].map(i=>`<span class="${i<n?'on':''}">${ic('star',16,true)}</span>`).join('')}</div>`}

function storyCard(s){
  const img=cover(s);
  if(s.open){
    const n=doneCount(s.id),st=started(s.id);
    return `<article class="story open" data-a="nav" data-to="levels:${s.id}" role="button" tabindex="0" aria-label="Abrir ${ESC(s.title)}">
      <div class="cover"><img src="${img}" alt="">${st?'':'<span class="badge">¡Nuevo!</span>'}
      <div class="cap"><b>${ESC(s.title)}</b><i>${ESC(s.genre)}</i></div></div>
      <div class="foot">${st?`Continuar · ${n}/${s.levels.length} niveles`:'¡A leer!'}</div></article>`;
  }
  return `<article class="story" aria-disabled="true"><div class="cover"><img src="${img}" alt="">
    <div class="veil">${ic('lock',26)}<span>Próximamente</span></div>
    <div class="cap"><b>${ESC(s.title)}</b><i>${ESC(s.genre)}</i></div></div><div class="foot">Bloqueado</div></article>`;
}

function homeScreen(){
  return `<header class="hdr home"><div><h1>NeoLectura</h1><div class="sub">Bienvenido, ${ESC(S.name)} 👋</div></div>
    <div class="acts">
      <button class="rbtn" data-a="nav" data-to="ranking" aria-label="Ranking">${ic('trophy',18)}</button>
      <button class="rbtn" data-a="nav" data-to="settings" aria-label="Opciones">${ic('gear',18)}</button>
      <button class="rbtn" data-a="logout" aria-label="Salir">${ic('logout',18)}</button>
    </div></header>
  <main>
    <section class="mcard">${MASCOT()}<div><div class="mt">¡Elige un cuento!</div><div class="ms">Tienes <b>${fmt(S.points)} puntos</b></div>${starsRow()}</div></section>
    <div class="sec"><h3>Mis Cuentos</h3><span>${totalDone()} niveles completados</span></div>
    <div class="grid">${STORIES.map(storyCard).join('')}</div>
    <div class="links">
      <button class="link" data-a="nav" data-to="ranking"><span style="color:#F2A900">${ic('trophy',24)}</span>Ranking</button>
      <button class="link" data-a="nav" data-to="credits"><span style="color:var(--teal)">${ic('book',24)}</span>Créditos</button>
    </div>
  </main>`;
}

function levelsScreen(sid){
  const s=story(sid),n=s.levels.length;
  const lv=s.levels.map((L,i)=>{
    if(!unlocked(sid,i))return `<div class="lvl locked"><div class="lvl-top"><div class="num">${ic('lock',22)}</div><div class="t"><h4>Nivel ${i+1}: ${ESC(L.name)}</h4><p>Bloqueado</p></div></div></div>`;
    const dn=!!S.done[kd(sid,i)];
    const steps=L.parts.map((p,j)=>{const r=!!S.parts[kp(sid,i,j)];
      return `<div class="step" data-a="nav" data-to="read:${sid}:${i}:${j}" role="button" tabindex="0" title="${ESC(p.t)}"><div class="circ ${r?'done':''}">${r?ic('check',18):j+1}</div><span class="lab">${ESC(p.t)}</span></div>`}).join('');
    return `<div class="lvl" data-a="cont" data-s="${sid}" data-l="${i}" role="button" tabindex="0">
      <div class="lvl-top"><div class="num">${i+1}</div><div class="t"><h4>Nivel ${i+1}: ${ESC(L.name)}</h4><p>${dn?'Completado ✓':'En progreso'}</p></div><span class="go">${ic('chev',22)}</span></div>
      <div class="steps">${steps}<div class="arrow">${ic('right',16)}</div>
      <div class="step q" data-a="nav" data-to="quiz:${sid}:${i}" role="button" tabindex="0"><div class="circ quiz ${dn?'done':''}">${ic('star',20,dn)}</div><span class="lab">Quiz</span></div></div></div>`;
  }).join('');
  return bar(s.title,'home')+`<main><div class="doc" style="max-width:none">
    <section class="mcard" style="min-height:102px;border-radius:24px">${MASCOT()}<div><div class="mt">¡Selecciona un nivel!</div><div class="ms">Cada nivel tiene 3 partes + un quiz.</div><div class="cnt">${doneCount(sid)}/${n} niveles completados</div></div></section>
    ${lv}</div></main>`;
}

function readScreen(r){
  const s=story(r.sid),L=s.levels[r.l],P=L.parts[r.p];
  const last=r.p===PARTS-1,pos=['50% 22%','50% 50%','50% 82%'][r.p%3];
  return bar(s.title,'levels:'+r.sid)+`<main><div class="doc"><article class="paper">
    <div class="banner"><img src="${cover(s)}" alt="" style="object-position:${pos}"></div>
    <div class="in"><div class="meta">Nivel ${r.l+1}: ${ESC(L.name)} · Parte ${r.p+1} de ${PARTS}</div>
    <h2>${ESC(P.t)}</h2>
    <p class="txt">${vocab(P.x)}</p>
    ${P.x.indexOf('{')>-1?'<p class="hint">Toca las palabras subrayadas para ver qué significan.</p>':''}
    <div class="defbox" id="def" hidden></div>
    <div class="tools">${canSpeak&&S.voice?`<button class="btn ghost" data-a="speak">${ic('vol',18)} Escuchar</button>`:'<span></span>'}
      <div class="dots" aria-hidden="true">${[0,1,2].map(i=>`<i class="${i===r.p?'on':''}"></i>`).join('')}</div></div>
    <div class="nav">${r.p>0?`<button class="btn ghost" data-a="nav" data-to="read:${r.sid}:${r.l}:${r.p-1}">${ic('back',16)} Anterior</button>`:'<span></span>'}
      <button class="btn ${last?'gold':'pri'}" data-a="next">${last?'Ir al Quiz '+ic('star',18,true):'Siguiente '+ic('right',16)}</button></div>
    </div></article></div></main>`;
}

function quizScreen(){
  const s=story(Q.sid),L=s.levels[Q.l],n=L.quiz.length;
  const head=bar('Quiz · Nivel '+(Q.l+1),'levels:'+Q.sid);
  if(Q.end){
    const r=Q.res,lastLv=Q.l===s.levels.length-1;
    const msg=[`Acertaste ${Q.score} de ${n}.`];
    if(r.delta)msg.push(`Ganaste +${fmt(r.delta)} puntos.`);
    if(r.bonus)msg.push(`Bono por completar el nivel: +${r.bonus}.`);
    if(!r.pass)msg.push('Repasa las partes del nivel y vuelve a intentarlo.');
    if(r.pass&&lastLv)msg.push('¡Terminaste todo el cuento!');
    const btns=r.pass
      ?(lastLv?`<button class="btn pri" data-a="nav" data-to="home">Volver a mis cuentos</button>`
              :`<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Ver niveles</button><button class="btn pri" data-a="nav" data-to="read:${Q.sid}:${Q.l+1}:0">Siguiente nivel ${ic('right',16)}</button>`)
      :`<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Repasar</button><button class="btn pri" data-a="nav" data-to="quiz:${Q.sid}:${Q.l}">Reintentar</button>`;
    return head+`<main><div class="doc"><div class="paper"><div class="in center" style="padding-top:28px">
      <div class="bigstars">${Array.from({length:n},(_,i)=>`<span class="${i<Q.score?'on':''}">${ic('star',48,true)}</span>`).join('')}</div>
      <h2>${r.pass?'¡Nivel completado!':'¡Casi lo logras!'}</h2><p class="res-txt">${msg.join(' ')}</p><div class="res-btns">${btns}</div></div></div></div></main>`;
  }
  const q=L.quiz[Q.i],pk=Q.pick;
  const opts=q.o.map((t,k)=>{let c='opt';if(pk!=null){if(k===q.a)c+=' ok';else if(k===pk)c+=' bad'}
    return `<button class="${c}" data-a="pick" data-i="${k}" ${pk!=null?'disabled':''}><span class="k">${'ABC'[k]}</span>${ESC(t)}</button>`}).join('');
  const fb=pk==null?'':pk===q.a?'<div class="fb ok" role="status">¡Muy bien! 🎉</div>':`<div class="fb bad" role="status">Casi. La respuesta correcta era: <b>${ESC(q.o[q.a])}</b></div>`;
  return head+`<main><div class="doc"><div class="paper"><div class="in">
    <div class="meta">Pregunta ${Q.i+1} de ${n}</div>
    <div class="pbar"><i style="width:${(Q.i+(pk!=null?1:0))/n*100}%"></i></div>
    <div class="qq">${ESC(q.q)}</div>${opts}${fb}
    ${pk!=null?`<div class="nav"><span></span><button class="btn pri" data-a="qnext">${Q.i+1<n?'Siguiente':'Ver resultado'} ${ic('right',16)}</button></div>`:''}
    </div></div></div></main>`;
}

const AVC=['#F26B1D','#35BFC0','#1B7DCB','#8E63D4','#E0568A','#3BAA6B','#D99A00','#5C7CFA','#E06666'];
function rankScreen(){
  const list=RIVALS.map(([n,p])=>({n,p,me:false})).concat({n:S.name,p:S.points,me:true}).sort((a,b)=>b.p-a.p);
  const pos=list.findIndex(x=>x.me)+1;
  const rows=list.map((x,i)=>`<div class="row ${x.me?'me':''}"><div class="pos ${i<3?'g'+(i+1):''}">${i+1}</div>
    <div class="av" style="background:${AVC[(x.n.charCodeAt(0)+i)%AVC.length]}">${ESC(x.n.charAt(0).toUpperCase())}</div>
    <div class="nm">${ESC(x.n)}${x.me?'<small>Tú</small>':''}</div><div class="pts">${fmt(x.p)} pts</div></div>`).join('');
  return bar('Ranking','home')+`<main><div class="doc">
    <section class="mcard"><span style="color:#F2A900">${ic('trophy',48)}</span><div><div class="mt">¡Buen trabajo, ${ESC(S.name)}!</div><div class="ms">Estás en el puesto <b>${pos}</b> de ${list.length}</div>${starsRow()}</div></section>
    ${rows}</div></main>`;
}

function creditsScreen(){
  return bar('Créditos','home')+`<main><div class="doc">
    <section class="mcard">${MASCOT()}<div><div class="mt">NeoLectura</div><div class="ms">Plantilla de lectura dinámica</div></div></section>
    <section class="set credit"><h4><span style="color:var(--teal)">${ic('book',22)}</span>Cuentos</h4><p>Fábulas clásicas de la tradición de Esopo, adaptadas y ampliadas para lectores en formación.</p></section>
    <section class="set credit"><h4><span style="color:var(--teal)">${ic('star',22)}</span>Ilustraciones</h4><p>Arte vectorial creado para este prototipo. Puedes reemplazarlo por tus propias fotos en la configuración de cada cuento.</p></section>
    <section class="set credit"><h4><span style="color:var(--teal)">${ic('vol',22)}</span>Lectura en voz alta</h4><p>Usa la voz del navegador o del dispositivo, por lo que puede sonar distinto según el equipo.</p></section>
  </div></main>`;
}

function settingsScreen(){
  const themes=[['auto','Automático'],['light','Claro'],['dark','Oscuro']];
  return bar('Opciones','home')+`<main><div class="doc">
    <section class="mcard"><span style="color:var(--blue)">${ic('gear',44)}</span><div><div class="mt">Opciones</div><div class="ms">Ajusta NeoLectura a tu gusto</div></div></section>
    <section class="set"><h4>Tu nombre</h4><p>Aparece en la pantalla principal y en el ranking.</p><input id="setname" class="inp" maxlength="14" value="${ESC(S.name)}" autocomplete="off" aria-label="Tu nombre"></section>
    <section class="set"><h4>Tamaño de letra</h4><p>Cambia el tamaño del texto de los cuentos.</p>
      <div class="chips">${SIZE_NAMES.map((n,i)=>`<button class="chip ${S.size===i?'on':''}" data-a="size" data-i="${i}">${n}</button>`).join('')}</div>
      <p class="prev" style="font-size:var(--fs)">Así se verá el texto del cuento.</p></section>
    <section class="set two"><div><h4>Lectura en voz alta</h4><p>Muestra el botón «Escuchar» en cada parte del cuento.</p></div>
      <button class="sw ${S.voice?'on':''}" data-a="voice" role="switch" aria-checked="${S.voice}" aria-label="Lectura en voz alta"></button></section>
    <section class="set"><h4>Tema</h4><p>El modo Claro es el diseño original.</p>
      <div class="chips">${themes.map(([v,n])=>`<button class="chip ${S.theme===v?'on':''}" data-a="theme" data-v="${v}">${n}</button>`).join('')}</div></section>
    <section class="set"><h4>Progreso</h4><p>Borra tus puntos y niveles para empezar de nuevo.</p><button class="btn danger" data-a="reset" style="margin-top:12px">Reiniciar progreso</button></section>
  </div></main>`;
}

function loginScreen(){
  return `<div class="login"><div class="lcard">${MASCOT(84)}<h1>NeoLectura</h1><p>¡Hola! ¿Cómo te llamas?</p>
    <input id="lname" class="inp" maxlength="14" value="${ESC(S.name)}" autocomplete="off" aria-label="Tu nombre">
    <button class="btn pri" data-a="enter" style="width:100%">Entrar</button></div></div>`;
}

