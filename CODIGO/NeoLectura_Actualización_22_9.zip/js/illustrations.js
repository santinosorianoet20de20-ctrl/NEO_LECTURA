/* =====================  ILUSTRACIONES (SVG)  ===================== */
const svgWrap=(inner,defs='')=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400" preserveAspectRatio="xMidYMid slice"><defs>${defs}</defs>${inner}</svg>`;
const ART={
 lion(){
  let mane='';
  for(let i=0;i<14;i++){const a=i/14*Math.PI*2;mane+=`<circle cx="${(150+Math.cos(a)*76).toFixed(1)}" cy="${(190+Math.sin(a)*76).toFixed(1)}" r="30" fill="${i%2?'#a2520f':'#b8631c'}"/>`}
  return svgWrap(`
  <rect width="300" height="400" fill="url(#a)"/>
  <circle cx="240" cy="70" r="34" fill="#fff0b3" opacity=".9"/>
  <path d="M0 300Q90 262 170 292T300 278V400H0Z" fill="#8a6a2a"/>
  <path d="M0 338Q100 306 200 338T300 328V400H0Z" fill="#5f8a38"/>
  <rect x="40" y="236" width="7" height="70" fill="#3b2a14"/><ellipse cx="44" cy="232" rx="42" ry="12" fill="#2f4a1f"/>
  ${mane}
  <circle cx="108" cy="146" r="15" fill="#f2bd6e"/><circle cx="192" cy="146" r="15" fill="#f2bd6e"/>
  <circle cx="108" cy="146" r="7" fill="#d98b4b"/><circle cx="192" cy="146" r="7" fill="#d98b4b"/>
  <circle cx="150" cy="190" r="70" fill="#b8631c"/>
  <circle cx="150" cy="198" r="54" fill="#f2bd6e"/>
  <ellipse cx="150" cy="218" rx="25" ry="18" fill="#fbe3b8"/>
  <circle cx="131" cy="188" r="5.5" fill="#2b1a0e"/><circle cx="169" cy="188" r="5.5" fill="#2b1a0e"/>
  <circle cx="133" cy="186" r="1.8" fill="#fff"/><circle cx="171" cy="186" r="1.8" fill="#fff"/>
  <path d="M139 208h22l-11 11z" fill="#4f2a14"/>
  <path d="M150 219v9M150 228q-10 9-19 1M150 228q10 9 19 1" stroke="#4f2a14" stroke-width="3" fill="none" stroke-linecap="round"/>
  <g transform="translate(58 352)"><path d="M-15 2q-16-4-20 8" stroke="#f4a6b6" stroke-width="3" fill="none" stroke-linecap="round"/>
  <ellipse cx="0" cy="0" rx="17" ry="11" fill="#a7b0b8"/><circle cx="18" cy="-4" r="9" fill="#b7c0c8"/>
  <circle cx="14" cy="-13" r="5.5" fill="#f4a6b6"/><circle cx="23" cy="-13" r="5.5" fill="#f4a6b6"/>
  <circle cx="21" cy="-6" r="1.7" fill="#222"/><circle cx="27" cy="-3" r="2.2" fill="#f4a6b6"/></g>`,
  '<linearGradient id="a" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f7c266"/><stop offset=".6" stop-color="#ee8f4e"/><stop offset="1" stop-color="#d9673f"/></linearGradient>');
 },
 storm(){
  const r=seed(7);let grass='';
  for(let i=0;i<80;i++){const x=r()*300,y=268+r()*132,h=14+r()*26;grass+=`<path d="M${x.toFixed(1)} ${y.toFixed(1)}q${(r()*8-4).toFixed(1)} -${(h/2).toFixed(1)} ${(r()*10-5).toFixed(1)} -${h.toFixed(1)}" stroke="${r()>.5?'#e0a655':'#b97a34'}" stroke-width="2" fill="none" stroke-linecap="round"/>`}
  return svgWrap(`
  <rect width="300" height="400" fill="url(#s)"/>
  <g fill="#0d1319" opacity=".85"><ellipse cx="60" cy="40" rx="90" ry="34"/><ellipse cx="210" cy="30" rx="100" ry="38"/><ellipse cx="292" cy="72" rx="60" ry="30"/></g>
  <polygon points="176,0 146,110 172,110 132,215 206,92 178,92 212,0" fill="#fff" opacity=".6" filter="url(#b)"/>
  <polygon points="176,0 146,110 172,110 132,215 206,92 178,92 212,0" fill="#fffbe0"/>
  <polygon points="70,20 55,90 72,90 50,150 92,76 76,76 96,20" fill="#fff" opacity=".85"/>
  <path d="M0 262Q80 246 160 258T300 252V400H0Z" fill="url(#f)"/>
  <rect x="34" y="216" width="8" height="46" fill="#1b140e"/><circle cx="38" cy="204" r="26" fill="#1c2618"/><circle cx="20" cy="218" r="16" fill="#1c2618"/><circle cx="58" cy="218" r="16" fill="#1c2618"/>
  ${grass}
  <path d="M128 400L172 400L156 262L146 262Z" fill="#d8b07a" opacity=".45"/>
  <g stroke="#e3c46a" stroke-width="3" fill="none" stroke-linecap="round"><path d="M252 400Q252 322 286 292"/><path d="M270 400Q272 340 298 322"/><path d="M236 400Q238 340 268 318"/></g>`,
  '<linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#10171f"/><stop offset=".55" stop-color="#3c4a55"/><stop offset="1" stop-color="#7b7f80"/></linearGradient><linearGradient id="f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a5a2b"/><stop offset="1" stop-color="#c58b45"/></linearGradient><filter id="b"><feGaussianBlur stdDeviation="4"/></filter>');
 },
 space(){
  let bolts='';
  for(let i=0;i<8;i++){const a=i/8*Math.PI*2+.4;bolts+=`<circle cx="${(150+Math.cos(a)*126).toFixed(1)}" cy="${(200+Math.sin(a)*126).toFixed(1)}" r="5" fill="#6a717a"/>`}
  return svgWrap(`
  <rect width="300" height="400" fill="#171b20"/>
  <circle cx="150" cy="200" r="138" fill="#2b3037"/>
  <circle cx="150" cy="200" r="118" fill="none" stroke="#454c55" stroke-width="8"/>
  ${bolts}
  <circle cx="150" cy="200" r="102" fill="url(#e)"/>
  <g clip-path="url(#c)"><path d="M85 150q30-26 62-8q14 28-18 46q-30 8-44-38z" fill="#4a9a52" opacity=".85"/><path d="M170 220q28-12 46 12q-4 32-38 34q-22-20-8-46z" fill="#4a9a52" opacity=".85"/>
  <ellipse cx="130" cy="196" rx="40" ry="8" fill="#fff" opacity=".55"/><ellipse cx="190" cy="160" rx="34" ry="7" fill="#fff" opacity=".5"/><ellipse cx="110" cy="250" rx="36" ry="7" fill="#fff" opacity=".45"/>
  <ellipse cx="115" cy="150" rx="46" ry="22" fill="#fff" opacity=".12" transform="rotate(-30 115 150)"/></g>`,
  '<radialGradient id="e" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#3f9be0"/><stop offset=".7" stop-color="#1c5fa8"/><stop offset="1" stop-color="#0b2a4d"/></radialGradient><clipPath id="c"><circle cx="150" cy="200" r="102"/></clipPath>');
 },
 pigs(){
  return svgWrap(`
  <rect width="300" height="400" fill="url(#p)"/>
  <circle cx="240" cy="60" r="30" fill="#fff3b0"/>
  <path d="M0 320Q100 280 200 314T300 300V400H0Z" fill="#79b94a"/>
  <polygon points="98,124 116,78 148,114" fill="#f19cb0"/><polygon points="202,124 184,78 152,114" fill="#f19cb0"/>
  <circle cx="150" cy="190" r="70" fill="#f7b0c2"/>
  <ellipse cx="150" cy="214" rx="32" ry="24" fill="#f28ba5"/>
  <ellipse cx="139" cy="214" rx="4.5" ry="7.5" fill="#c9506f"/><ellipse cx="161" cy="214" rx="4.5" ry="7.5" fill="#c9506f"/>
  <circle cx="122" cy="174" r="6.5" fill="#3a2030"/><circle cx="178" cy="174" r="6.5" fill="#3a2030"/>
  <circle cx="124" cy="172" r="2" fill="#fff"/><circle cx="180" cy="172" r="2" fill="#fff"/>
  <g transform="translate(0 322)"><rect x="24" y="14" width="46" height="34" fill="#e8c95a"/><polygon points="16,16 47,-8 78,16" fill="#c9a233"/>
  <rect x="127" y="14" width="46" height="34" fill="#a5703d"/><polygon points="119,16 150,-8 181,16" fill="#6e4423"/>
  <rect x="230" y="14" width="46" height="34" fill="#c6553d"/><polygon points="222,16 253,-8 284,16" fill="#8f3524"/></g>`,
  '<linearGradient id="p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a9dcf7"/><stop offset="1" stop-color="#e9f7ff"/></linearGradient>');
 },
 hansel(){
  const t=[[20,250,60],[80,270,50],[230,260,64],[275,280,46],[180,285,40]].map(([x,y,s])=>`<polygon points="${x-s/2},${y} ${x},${y-s*1.6} ${x+s/2},${y}" fill="#173222"/>`).join('');
  return svgWrap(`
  <rect width="300" height="400" fill="url(#h)"/>${t}
  <rect x="0" y="300" width="300" height="100" fill="#2f5a34"/>
  <rect x="90" y="236" width="120" height="86" fill="#b06a34"/>
  <polygon points="72,240 150,166 228,240" fill="#7b4620"/>
  <path d="M72 240q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0q9 14 18 0z" fill="#f7efe0"/>
  <rect x="134" y="268" width="32" height="54" rx="6" fill="#5b2f12"/><rect x="100" y="256" width="24" height="24" rx="4" fill="#ffd86b"/><rect x="176" y="256" width="24" height="24" rx="4" fill="#ffd86b"/>
  <circle cx="120" cy="212" r="6" fill="#e5484d"/><circle cx="150" cy="200" r="6" fill="#ffd86b"/><circle cx="180" cy="212" r="6" fill="#4cc38a"/><circle cx="135" cy="222" r="5" fill="#ff8cc6"/><circle cx="168" cy="224" r="5" fill="#6ec1ff"/>`,
  '<linearGradient id="h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1e3b2a"/><stop offset="1" stop-color="#4f7a4a"/></linearGradient>');
 },
 castle(){
  const r=seed(3);let st='';
  for(let i=0;i<40;i++)st+=`<circle cx="${(r()*300).toFixed(0)}" cy="${(r()*200).toFixed(0)}" r="${(r()*1.6+.6).toFixed(1)}" fill="#fff" opacity=".8"/>`;
  return svgWrap(`
  <rect width="300" height="400" fill="url(#c)"/>${st}
  <circle cx="230" cy="80" r="30" fill="#ffeeb0"/><circle cx="240" cy="72" r="26" fill="#a25a9c" opacity=".0"/>
  <g fill="#21103a"><rect x="80" y="220" width="140" height="110"/><rect x="62" y="180" width="44" height="150"/><rect x="194" y="180" width="44" height="150"/><rect x="130" y="150" width="40" height="80"/>
  <polygon points="56,182 84,130 112,182"/><polygon points="188,182 216,130 244,182"/><polygon points="124,152 150,96 176,152"/><rect x="0" y="320" width="300" height="80"/></g>
  <g fill="#ffd86b"><rect x="76" y="200" width="10" height="16" rx="5"/><rect x="214" y="200" width="10" height="16" rx="5"/><rect x="145" y="172" width="10" height="16" rx="5"/><rect x="120" y="260" width="12" height="20" rx="6"/><rect x="168" y="260" width="12" height="20" rx="6"/></g>
  <path d="M136 330v-40a14 14 0 0 1 28 0v40z" fill="#0f0720"/>`,
  '<linearGradient id="c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2d1b4e"/><stop offset=".7" stop-color="#8b4a94"/><stop offset="1" stop-color="#e58bb0"/></linearGradient>');
 }
};
const COVER={};
function cover(s){return s.img||(COVER[s.id]||(COVER[s.id]='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(ART[s.art]())))}

