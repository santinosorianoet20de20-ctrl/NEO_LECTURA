/* =====================  NAVEGACIÓN  ===================== */
const $app=document.getElementById('app');
function applyPrefs(){
  const r=document.documentElement;
  r.style.setProperty('--fs',SIZES[S.size]||SIZES[0]);
  if(S.theme==='auto')r.removeAttribute('data-theme');else r.setAttribute('data-theme',S.theme);
}
function render(){
  applyPrefs();
  let h;
  if(S.out)h=loginScreen();
  else if(R.s==='levels'&&story(R.sid)&&story(R.sid).open)h=levelsScreen(R.sid);
  else if(R.s==='read'&&story(R.sid)&&story(R.sid).levels[R.l])h=readScreen(R);
  else if(R.s==='quiz'&&Q)h=quizScreen();
  else if(R.s==='ranking')h=rankScreen();
  else if(R.s==='settings')h=settingsScreen();
  else if(R.s==='credits')h=creditsScreen();
  else{R={s:'home'};h=homeScreen()}
  $app.innerHTML=h;
}
function parseTo(t){const a=t.split(':');return {s:a[0],sid:a[1],l:+a[2],p:+a[3]}}
function go(r){
  if(typeof r==='string')r=parseTo(r);
  if((r.s==='read'||r.s==='quiz')&&!unlocked(r.sid,r.l))return;
  if(r.s==='quiz'){
    if(partsRead(r.sid,r.l)<PARTS){toast('Primero lee las 3 partes del nivel 📖');return}
    Q={sid:r.sid,l:r.l,i:0,score:0,pick:null,end:false};
  }
  R=r;
  try{window.speechSynthesis.cancel()}catch(e){}
  try{history.pushState(r,'')}catch(e){}
  render();window.scrollTo(0,0);
}
window.addEventListener('popstate',e=>{
  R=e.state||{s:'home'};
  if(R.s==='quiz')R={s:'levels',sid:R.sid};
  render();
});

/* Avisos y diálogos */
let tT;
function toast(t){
  let el=document.getElementById('toast');
  if(!el){el=document.createElement('div');el.id='toast';el.className='toast';el.setAttribute('role','status');document.body.appendChild(el)}
  el.textContent=t;el.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>el.classList.remove('show'),2000);
}
function ask(msg,label,fn){
  const m=document.createElement('div');m.className='modal';
  m.innerHTML=`<div class="mbox" role="dialog" aria-modal="true"><p>${msg}</p><div class="mrow"><button class="btn ghost" data-m="no">Cancelar</button><button class="btn pri" data-m="yes">${label}</button></div></div>`;
  m.addEventListener('click',e=>{const b=e.target.closest('[data-m]');
    if(e.target===m||(b&&b.dataset.m==='no'))m.remove();else if(b){m.remove();fn()}});
  document.body.appendChild(m);m.querySelector('[data-m="yes"]').focus();
}

/* Lógica de juego */
function markRead(sid,l,p){
  const k=kp(sid,l,p);
  if(!S.parts[k]){S.parts[k]=true;S.points+=50;save();toast('+50 puntos ⭐')}
}
function finishQuiz(){
  const L=story(Q.sid).levels[Q.l],n=L.quiz.length,k=kd(Q.sid,Q.l);
  const prev=S.quiz[k]||0,delta=Math.max(0,Q.score-prev)*100;
  const pass=Q.score>=Math.ceil(n/2),bonus=pass&&!S.done[k]?150:0;
  S.quiz[k]=Math.max(prev,Q.score);
  if(pass)S.done[k]=true;
  S.points+=delta+bonus;save();
  Q.end=true;Q.res={delta,bonus,pass};
}
function enter(){
  const v=(document.getElementById('lname')||{}).value||'';
  S.name=v.trim()||'Lector';S.out=false;save();R={s:'home'};render();window.scrollTo(0,0);
}
function speakText(){
  if(!canSpeak)return;
  try{
    const ss=window.speechSynthesis;
    if(ss.speaking){ss.cancel();return}
    const u=new SpeechSynthesisUtterance(plain(story(R.sid).levels[R.l].parts[R.p].x));
    u.lang='es-AR';u.rate=.9;ss.speak(u);
  }catch(e){}
}

/* Eventos */
document.addEventListener('click',e=>{
  const t=e.target.closest('[data-a]');if(!t)return;
  const a=t.dataset.a,d=t.dataset;
  switch(a){
    case 'nav':go(d.to);break;
    case 'cont':{
      const sid=d.s,l=+d.l;let p=-1;
      for(let j=0;j<PARTS;j++){if(!S.parts[kp(sid,l,j)]){p=j;break}}
      go(p<0?{s:'quiz',sid,l}:{s:'read',sid,l,p});break;}
    case 'next':{
      markRead(R.sid,R.l,R.p);
      go(R.p<PARTS-1?{s:'read',sid:R.sid,l:R.l,p:R.p+1}:{s:'quiz',sid:R.sid,l:R.l});break;}
    case 'def':{
      const b=document.getElementById('def');if(!b)break;
      b.hidden=false;b.innerHTML='<b>'+ESC(d.w)+':</b> '+ESC(d.d);break;}
    case 'speak':speakText();break;
    case 'pick':{
      if(Q.pick!=null)break;
      const q=story(Q.sid).levels[Q.l].quiz[Q.i];
      Q.pick=+d.i;if(Q.pick===q.a)Q.score++;render();break;}
    case 'qnext':{
      const n=story(Q.sid).levels[Q.l].quiz.length;
      if(Q.i+1<n){Q.i++;Q.pick=null}else finishQuiz();
      render();window.scrollTo(0,0);break;}
    case 'size':S.size=+d.i;save();render();break;
    case 'voice':S.voice=!S.voice;save();render();break;
    case 'theme':S.theme=d.v;save();render();break;
    case 'reset':ask('¿Seguro que quieres borrar tus puntos y niveles?','Reiniciar',()=>{
      S.points=DEF.points;S.parts={};S.quiz={};S.done={};save();toast('Progreso reiniciado');render()});break;
    case 'logout':ask('¿Quieres cerrar sesión? Tu progreso se guarda en este dispositivo.','Salir',()=>{S.out=true;save();render();window.scrollTo(0,0)});break;
    case 'enter':enter();break;
  }
});
document.addEventListener('input',e=>{
  if(e.target.id==='setname'){S.name=e.target.value.trim()||'Lector';save()}
});
document.addEventListener('keydown',e=>{
  const t=e.target;
  if((e.key==='Enter'||e.key===' ')&&t.getAttribute&&t.getAttribute('role')==='button'){e.preventDefault();t.click()}
  if(e.key==='Enter'&&t.id==='lname')enter();
});

try{history.replaceState({s:'home'},'')}catch(e){}
render();