'use strict';
/* =====================  UTILIDADES  ===================== */
const ESC=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
const seed=s=>()=>((s=(s*16807)%2147483647)/2147483647);

const ICON={
 trophy:'<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
 gear:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
 logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
 lock:'<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
 star:'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
 chev:'<path d="m9 18 6-6-6-6"/>',
 back:'<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
 right:'<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
 book:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
 check:'<path d="M20 6 9 17l-5-5"/>',
 vol:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>'
};
const ic=(n,s=20,fill=false)=>`<svg class="ico" viewBox="0 0 24 24" width="${s}" height="${s}"${fill?' style="fill:currentColor"':''} aria-hidden="true">${ICON[n]}</svg>`;

/* Mascota: el libro con anteojos */
const MASCOT=(w=56)=>`<svg viewBox="0 0 72 98" width="${w}" height="${Math.round(w*98/72)}" style="flex:none" aria-hidden="true">
<g stroke="#12324f" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
<path d="M26 76v11M46 76v11" fill="none"/>
<ellipse cx="23" cy="91" rx="9" ry="4.6" fill="#fff"/><ellipse cx="49" cy="91" rx="9" ry="4.6" fill="#fff"/>
<path d="M10 45c-8 2-9 8-8 14" fill="none"/><circle cx="2.5" cy="60" r="3.6" fill="#F6D2A8"/>
<path d="M62 44c8-2 9-9 8-17" fill="none"/><circle cx="69" cy="25" r="3.6" fill="#F6D2A8"/>
<rect x="10" y="8" width="52" height="70" rx="7" fill="#2CB6E6"/>
<path d="M10 15a7 7 0 0 1 7-7h6v70h-6a7 7 0 0 1-7-7z" fill="#1A8FC4"/>
<path d="M62 16v54" stroke="#fff" stroke-width="3.4" fill="none"/>
<circle cx="32" cy="32" r="10" fill="#fff"/><circle cx="53" cy="32" r="10" fill="#fff"/>
<path d="M42 31h1" fill="none"/>
<circle cx="33" cy="33" r="3.8" fill="#12324f" stroke="none"/><circle cx="52" cy="33" r="3.8" fill="#12324f" stroke="none"/>
<circle cx="34.2" cy="31.8" r="1.2" fill="#fff" stroke="none"/><circle cx="53.2" cy="31.8" r="1.2" fill="#fff" stroke="none"/>
<path d="M31 52q11 12 22 0z" fill="#fff"/>
</g></svg>`;

