/* =====================  ESTADO  ===================== */
const KEY='neolectura.v1';
const DEF={name:'Valentín',points:1250,parts:{},quiz:{},done:{},size:0,voice:true,theme:'auto',out:false};
function load(){try{const r=localStorage.getItem(KEY);return r?JSON.parse(r):null}catch(e){return null}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
let S=Object.assign({},DEF,load()||{});
let R={s:'home'},Q=null;

const story=id=>STORIES.find(s=>s.id===id);
const kd=(sid,l)=>sid+':'+l, kp=(sid,l,p)=>sid+':'+l+':'+p;
const doneCount=sid=>story(sid).levels.filter((_,i)=>S.done[kd(sid,i)]).length;
const totalDone=()=>STORIES.filter(s=>s.open).reduce((a,s)=>a+doneCount(s.id),0);
const unlocked=(sid,l)=>l===0||!!S.done[kd(sid,l-1)];
const partsRead=(sid,l)=>{let n=0;for(let p=0;p<PARTS;p++)if(S.parts[kp(sid,l,p)])n++;return n};
const starCount=()=>S.points>=1200?3:S.points>=600?2:S.points>=200?1:0;
const started=sid=>Object.keys(S.parts).some(k=>k.indexOf(sid+':')===0);
const plain=t=>t.replace(/\{([^|}]+)\|[^}]+\}/g,'$1');
const vocab=t=>t.replace(/\{([^|}]+)\|([^}]+)\}/g,(m,w,d)=>`<button class="vocab" data-a="def" data-w="${ESC(w)}" data-d="${ESC(d)}">${w}</button>`);
const canSpeak=typeof window!=='undefined'&&'speechSynthesis' in window&&'SpeechSynthesisUtterance' in window;

