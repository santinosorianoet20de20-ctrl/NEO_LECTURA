const RIVALS=[['Sofía R.',2480],['Mateo G.',2130],['Lucía P.',1870],['Benjamín',1640],['Camila',980],['Thiago',760],['Martina',540],['Emilia',320]];
const SIZES=['1.0625rem','1.3rem','1.6rem'],SIZE_NAMES=['Normal','Grande','Muy grande'];
const PARTS=3;

