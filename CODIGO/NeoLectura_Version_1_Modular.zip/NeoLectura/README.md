# NeoLectura — versión modular

App de lectura para primaria: un camino de cuentos (cada uno es un nivel de 3 partes + un quiz), audiolibro con personajes, mascota compañera, racha diaria, ranking y cuentas. No necesita servidor ni instalación: se abre `index.html`.

## Estructura (módulos)

Todo el código está dividido en **módulos**: cada carpeta de `js/` es una parte de la app y tiene sus archivos con el mismo nombre que la carpeta (`modulo.parte.js`). Las partes son siempre las mismas:

| Parte | Qué hay |
|---|---|
| `.config.js` | Textos, números y opciones que se pueden cambiar sin tocar la lógica. **Para cambiar algo, casi siempre es acá.** |
| `.storage.js` | Dónde se guardan los datos (hoy, el navegador). |
| `.logic.js` | Las reglas (cuándo se aprueba, cuántos puntos da, cómo se cuenta la racha…). No arma HTML. |
| `.view.js` | El HTML de la pantalla o del componente. No guarda nada. |
| `.controller.js` | Qué pasa cuando se toca un botón: une la vista con la lógica. |

```
index.html            carga todo en orden (núcleo → módulos → pantallas → arranque)
css/                  un archivo por módulo o pantalla (nucleo.css son los estilos generales)
img/                  personajes (librin, librina, libron, librona), escenas de los cuentos y racha
js/
├─ nucleo/            lo que usan todos
│  ├─ nucleo.utils.js       ESC, fmt, íconos (ICON, ic), canSpeak
│  ├─ nucleo.config.js      tamaños de letra, partes por nivel y PUNTOS (cuánto da cada cosa)
│  ├─ nucleo.estado.js      el progreso del usuario (S), la pantalla actual (R), save(), reiniciarProgreso()
│  ├─ nucleo.dialogos.js    toast(), ask() y pedirClave() (pedir la contraseña)
│  ├─ nucleo.pantallas.js   el registro de pantallas y de botones (Pantallas.registrar / Pantallas.accion)
│  └─ nucleo.router.js      render(), go() y el arranque (va último)
├─ personajes/        Librín, Librina, Librón y Librona: voz, colores, imágenes y MASCOTA()
├─ filtro/            filtro de nombres (malas palabras, temas fuertes, datos personales)
├─ cuentos/           un archivo por cuento + el camino (orden y desbloqueo) + el formato del texto
├─ login/             inicio de sesión y cuentas (con Librín animado)
├─ racha/             racha diaria y Fueguito
├─ audio/             audiolibro: voces de los personajes, velocidades, texto que se pinta
├─ companero/         la mascota que acompaña la lectura y el quiz
├─ inicio/            PANTALLA principal (camino de cuentos)          → css/inicio.css
├─ niveles/           PANTALLA de un cuento (partes y quiz)           → css/niveles.css
├─ lectura/           PANTALLA de una parte del cuento                → css/lectura.css
├─ quiz/              PANTALLA del quiz (lógica, vista y botones)     → css/quiz.css
├─ ranking/           PANTALLA del ranking (+ dónde se guarda la tabla) → css/ranking.css
├─ opciones/          PANTALLA de opciones (+ borrar progreso con contraseña) → css/opciones.css
└─ creditos/          PANTALLA de créditos (equipo y fuentes)          → css/creditos.css
```

**Cómo se conectan:** cada pantalla se anota sola al final de su `.view.js` con `Pantallas.registrar('nombre', {html, entrar, permitida})`, y cada módulo anota sus botones con `Pantallas.accion('nombre', fn)`; el núcleo no conoce las pantallas. Un botón con `data-a="nav" data-to="levels:caperucita-roja"` va a esa pantalla; uno con `data-a="reset"` hace la acción `reset` (la anota `js/opciones/opciones.controller.js`).

**Para agregar una pantalla nueva:** crear `js/<nombre>/<nombre>.view.js` (y, si tiene botones, `<nombre>.controller.js`), anotarla con `Pantallas.registrar`, sumar sus `<script>` en `index.html` (en «3. Pantallas», antes de `nucleo.router.js`) y su `css/<nombre>.css`.

### Archivos de cada módulo

- `js/nucleo/` — ver el cuadro de arriba. `nucleo.config.js` tiene **los puntos** (`PUNTOS`: leer una parte +50, cada correcta +100, aprobar un nivel +150, y los puntos para 1, 2 y 3 estrellas).
- `js/personajes/` — `personajes.config.js`: **los personajes** (nombre, si es él o ella, cómo suena su voz, el color de su nombre, su foto de perfil y sus cambios de cara; **para agregar uno, se agrega un renglón acá**). `personajes.logic.js`: `MASCOTA()` (el personaje cuya voz eligió el usuario), `MASCOTA_RUTA('reacción')`, `MASCOTA_IMG('reacción')` y `CON_GENERO()` (cambia `orgullos{o}` por *orgulloso* u *orgullosa*).
- `img/librin/`, `img/librina/`, `img/libron/`, `img/librona/` — cada personaje: la versión base (`saludo.png`) y sus 20 reacciones (PNG sin fondo, todas de 513×508 y con los mismos nombres: `bien`, `excelente`, `guino`, `vamos`, `orgullo`, `increible`, `animo`, `ojos-cerrados`, `aprender`, `logrado`, `muy-bien`, `segui-asi`, `mejorar`, `vos-podes`, `nublado`, `no-te-rindas`, `gran-trabajo`, `pensando`, `genial`, `triste`).
- `img/escenas/` — los dibujos de cada cuento: `<cuento>/portada.svg` y `parte-1.svg`, `parte-2.svg`, `parte-3.svg`. Son **bocetos simples** para pasarle a otra IA; `img/escenas/LEEME.md` explica las medidas, el estilo, cómo es cada personaje, qué muestra cada escena y cómo reemplazarlos.
- `img/racha/` — fuego de racha (`fuego.svg` encendido y `fuego-apagado.svg`).
- `js/cuentos/` — **los cuentos: cada uno es un nivel y vive en su propio archivo** (ver «Cuentos y niveles»):
  - `cuentos.texto.js` — el formato del texto: `{palabra|definición}`, párrafos y versos (`plain()`, `vocab()`, `PARRAFOS()`).
  - `cuentos.registro.js` — explica qué lleva cada cuento y define `registrarCuento()`.
  - `caperucita-roja.js`, `el-gato-con-botas.js`, `barba-azul.js`, `hansel-y-gretel.js` — texto (de los PDF del proyecto) dividido en 3 partes, vocabulario, preguntas de la mascota, descripción de cada dibujo y quiz.
  - `cuentos.camino.js` — ordena los cuentos del más corto al más largo, arma los niveles (`STORIES`), marca el vocabulario, mezcla las opciones del quiz y dice qué nivel está desbloqueado (`Camino`). En `CAMINO_CFG` se cambia el orden, la carpeta de los dibujos y su formato.
- `js/filtro/` — **filtro de nombres** (sin malas palabras, temas fuertes ni datos personales):
  - `filtro.config.js` — las listas de palabras (partes, enteras, permitidas y reservadas), cuántos números se aceptan y los mensajes. **Para agregar o sacar una palabra, se cambia acá.**
  - `filtro.logic.js` — `Filtro.revisar(nombre)` (devuelve el motivo o nada), `Filtro.permitido(nombre)` y `Filtro.mostrar(nombre)` (muestra "Lector" en lugar de un nombre no permitido de antes).
- `js/login/` — inicio de sesión:
  - `login.config.js` — textos, frases de Librín, qué imagen usa en cada momento, avatares y reglas. **Para cambiar un texto o una reacción, se cambia acá.**
  - `login.storage.js` — cuentas (localStorage), sesión (sessionStorage) y hash de contraseñas.
  - `login.validation.js` — validación de usuario, contraseña y nombre, y fuerza de la contraseña.
  - `login.mascot.js` — Librín: cambia de imagen según el estado, se inclina hacia el puntero y muestra el globito.
  - `login.view.js` — HTML de la pantalla de inicio de sesión.
  - `login.controller.js` — eventos, reacciones de Librín, entrar / salir (botón *Salir*) y `Login.verificarClave()` (lo usa Opciones).
- `js/racha/` — racha diaria:
  - `racha.config.js` — puntos por día, tope, imágenes y textos. **Para cambiar cuántos puntos da la racha, se cambia acá.**
  - `racha.logic.js` — fechas (siempre las del dispositivo), estado de la racha (hecha / pendiente / apagada) y suma del día.
  - `racha.personaje.js` — **Fueguito**, el fuego de la racha dibujado en la página para poder animarlo (prendido, dormido o festejando).
  - `racha.view.js` — HTML del indicador, del detalle y del aviso de racha completa.
  - `racha.controller.js` — abre y cierra las ventanas, animación del aviso.
- `js/audio/` — audiolibro (lectura en voz alta):
  - `audio.config.js` — segundos que saltan los botones, velocidades (Lenta, Normal, Rápida) y textos. **Para cambiar el salto de 5 segundos o una velocidad, se cambia acá** (cómo suena cada personaje está en `js/personajes/personajes.config.js`).
  - `audio.voces.js` — arma los personajes sobre las voces en español del equipo (elige una de mujer o de hombre según cada personaje) y pasa las cuentas viejas que tenían una voz del navegador al personaje que más se le parece.
  - `audio.motor.js` — habla con la voz del navegador, lleva la cuenta del tiempo y de la palabra que se está leyendo, pausa, reanuda, salta y cambia volumen, voz y velocidad.
  - `audio.view.js` — HTML del reproductor, del texto palabra por palabra, del panel de voces y de las tarjetas de Opciones (y sus íconos).
  - `audio.controller.js` — eventos de los botones, del volumen y de la elección de voz; pinta el texto mientras se lee y abre/cierra el panel de voces.
- `js/companero/` — la mascota compañera de lectura (Librín, Librina, Librón o Librona):
  - `companero.config.js` — todo lo que dice la mascota y qué cara pone en cada momento. **Para cambiar sus frases, se cambia acá.** Donde cambia si es él o ella se escribe `{o}` (`orgullos{o}`).
  - `companero.view.js` — HTML de la mascota con su globito (lectura, preguntas del quiz y resultado).
  - `companero.controller.js` — en la lectura, cambia el comentario según el audiolibro, el vocabulario o si la tocan.
- `js/inicio/inicio.view.js` — pantalla principal: saludo, puntos y estrellas, racha, el camino de cuentos y los accesos a Ranking y Créditos.
- `js/niveles/` — `niveles.view.js`: la pantalla de un cuento (sus partes, el quiz y el cuento que sigue); `niveles.controller.js`: tocar un nivel lleva a la primera parte sin leer.
- `js/lectura/` — `lectura.view.js`: la pantalla de una parte (escena, reproductor, texto, mascota); `lectura.controller.js`: *Siguiente* (marca la parte como leída y suma puntos) y las palabras del vocabulario.
- `js/quiz/` — `quiz.logic.js`: empezar, responder, pasar de pregunta y terminar (puntos, aprobar, desbloquear el cuento que sigue y la racha); `quiz.view.js`: las preguntas y el resultado; `quiz.controller.js`: los botones.
- `js/ranking/` — ranking de cuentas reales:
  - `ranking.config.js` — textos, colores y cuántos se muestran.
  - `ranking.storage.js` — **fuente de datos**: lee y guarda la tabla del ranking (hoy en localStorage). Es lo único que habría que cambiar para usar un servidor.
  - `ranking.logic.js` — anota los puntos de la cuenta al guardar el progreso y arma la lista ordenada.
  - `ranking.view.js` — pantalla del ranking.
- `js/opciones/` — `opciones.config.js`: los textos; `opciones.view.js`: la pantalla; `opciones.controller.js`: tamaño de letra, voz, tema, nombre y **reiniciar progreso con contraseña**.
- `js/creditos/` — `creditos.config.js`: **el equipo** (`EQUIPO`: integrantes y roles) y las demás secciones; `creditos.view.js`: la pantalla.
- `css/` — `nucleo.css` (colores claro/oscuro, letra, encabezados, tarjetas, botones, diálogos), uno por pantalla (`inicio.css`, `niveles.css`, `lectura.css`, `quiz.css`, `ranking.css`, `opciones.css`, `creditos.css`) y uno por módulo (`login.css`, `racha.css`, `audio.css` —todo empieza con `ap-`—, `companero.css` —todo empieza con `cp-`).

## Cuentos y niveles

Los niveles ahora son **los 4 cuentos de los PDF**, en orden del más corto al más largo. Cada uno es un nivel: **3 partes + un quiz**, igual que los niveles de antes (audiolibro, texto que se pinta, vocabulario, Librín y puntos).

| Nivel | Cuento | Duración de cada parte (aprox.) | Quiz | Para aprobar |
|---|---|---|---|---|
| 1 | Caperucita Roja (Perrault) | 1,5 · 1,6 · 1,8 min | 6 preguntas, 3 opciones | 3 correctas |
| 2 | El gato con botas (Perrault) | 3,7 · 3,6 · 3,9 min | 8 preguntas, 4 opciones | 5 correctas |
| 3 | Barba Azul (Perrault) | 4,2 · 4,1 · 4,9 min | 9 preguntas, 4 opciones | 6 correctas |
| 4 | Hansel y Gretel (Grimm) | 5,8 · 6,5 · 6,3 min | 10 preguntas, 4 opciones | 7 correctas |

- **Hay que aprobar cada nivel para pasar al siguiente.** En la pantalla principal los cuentos bloqueados tienen un candado que dice cuál hay que aprobar; tampoco se puede entrar por la dirección. Al aprobar, el resultado avisa «🔓 ¡Desbloqueaste el Nivel 2…!» y *Siguiente nivel* abre el cuento que sigue.
- **Partes de la misma duración:** cada cuento está cortado en 3 partes que duran casi lo mismo (menos de 10 % de diferencia), siempre al terminar un párrafo y en un momento de la historia que tenga sentido. En la última parte están las moralejas. Para revisarlo después de cambiar un texto: `Camino.medir()` en la consola del navegador.
- **Texto:** es el de los PDF, completo, con los errores de tipeo corregidos («pálida corno» → «como», «la oreja solamente» → «la vieja», etc.). Se ve en párrafos (las moralejas, en versos).
- **Vocabulario:** cada cuento tiene sus palabras difíciles (`palabras`) y se marcan solas la primera vez que aparecen en cada parte. Hay más en los cuentos más difíciles (castellano antiguo: «afligiros», «heredad», «dragón» como soldado…).
- **Quizzes más difíciles:** dentro de cada cuento las preguntas van por parte (dice «Sobre la parte 2») y se ponen más difíciles hacia el final; entre cuentos hay más preguntas, más opciones y hace falta acertar más. Los primeros niveles preguntan qué pasó; los últimos, por qué pasó, en qué orden, qué significa una palabra en el texto o qué enseña la moraleja.
- **Opciones:** en el archivo del cuento la primera opción es siempre la correcta; la app las mezcla al mostrarlas (siempre igual para cada pregunta).
- **Dibujos:** cada parte muestra el dibujo de su escena arriba del texto, y cada tarjeta tiene su portada (ver `img/escenas/LEEME.md`).
- **Para agregar un cuento:** copiar uno de los archivos de `js/cuentos/`, cambiar los datos, sumar su `<script>` en `index.html` (antes de `cuentos.camino.js`) y sus dibujos en `img/escenas/<id>/`. Se ubica solo en el camino según su largo (o con un orden fijo en `CAMINO_CFG.orden`).
- El progreso de los cuentos viejos (El León y el Ratón, El Roble y la Caña) ya no se usa, pero los puntos que se habían ganado se conservan.

## Filtro de nombres

NeoLectura es para chicos, así que los nombres pasan por un filtro (`js/filtro/`) al **crear una cuenta** y al **cambiar el nombre en Opciones**. No se aceptan:

- **Malas palabras e insultos** (rioplatenses, de otros países y en inglés), también los suaves que no van en primaria (*tonto*, *bobo*, *inútil*).
- **Partes íntimas del cuerpo y contenido sexual**, incluidas las formas que usan los chicos (*pito*, *pitulín*, *lolas*…) y las palabras "de doctor" (*clítoris*, *testículos*…).
- **Palabras "de baño"** (*caca*, *pis*, *pedo*): no son graves, pero quedan feas en un nombre.
- **Violencia, muerte y temas fuertes** (matar, muerto, suicidio, nazismo…), **drogas y alcohol** (también *cerveza*, *birra*, *fernet*) e **insultos discriminatorios**.
- **Trampas comunes:** letras repetidas (*puuuta*), números en lugar de letras (*p0rn0*, *1diota*), símbolos o puntos en el medio (*m.i.e.r.d.a*) y palabras pegadas (*elpelotudo*).
- **Nombres reservados**, para que nadie se haga pasar por un adulto o por la app: *admin*, *profe*, *seño*, *docente*, *moderador*, *NeoLectura*…
- **Datos personales:** más de 4 números (podría ser un teléfono o un DNI) o algo que parezca un mail o una página (@, gmail, www, .com).
- **Nombres sin letras** (al menos 2 letras). En Opciones, solo letras, números y espacios (sin emojis ni símbolos).

No bloquea palabras inocentes que contienen otra (*computadora*, *Penélope*, *Vergara*, *película*, *Analía*, *recoger*, *Felipito*, *Pitágoras*, *Capitán*, *Coitiño*): se probó con más de 300 nombres, apellidos y palabras comunes. Tampoco bloquea palabras sobre quién es una persona (como *gay* o *trans*), porque no son insultos; sí los insultos discriminatorios. El mensaje nunca dice qué palabra se bloqueó (así no se aprende a esquivarla). Las cuentas creadas antes del filtro pueden seguir entrando, pero si su nombre no está permitido se muestra como **"Lector"** en el ranking y en la pantalla principal.

> Ningún filtro es perfecto: alguien muy creativo puede encontrar una forma de escribir algo feo. Conviene que un docente revise el ranking de vez en cuando. Las listas se amplían fácil en `filtro.config.js`.

## Inicio de sesión

- Aparece apenas se abre la app. La sesión dura mientras la pestaña esté abierta (si se recarga, sigue adentro; si se vuelve a abrir la app, pide iniciar sesión otra vez).
- **Iniciar Sesión**: usuario, contraseña (con botón para verla), "Recordarme" y "¿Olvidaste tu contraseña?". Botones **Entrar 🚀** y **Crear cuenta ✨**.
- **Crear Cuenta**: **un solo nombre** (el nombre de usuario, que es también el que se muestra, con la primera letra en mayúscula: `sofía_10` → *Sofía_10*), contraseña con medidor de 1 a 3 estrellas y personaje (avatar). Avisa mientras se escribe si el nombre está libre, si ya lo tiene otra cuenta o si no está permitido. El nombre que se muestra se puede cambiar después en *Opciones*.
- El usuario admite tildes y ñ, y no distingue mayúsculas ni tildes: *Sofía*, *sofia* y *SOFIA* son la misma cuenta.
- **o entra como invitado**: usa el progreso guardado de siempre (`neolectura.v1`), así no se pierde lo que ya estaba.
- Cada usuario tiene su propio progreso guardado en `neolectura.v1:<usuario>`.
- Respeta el tema Claro/Oscuro/Automático de Opciones y la opción de "reducir movimiento" del sistema.
- **Un solo ojito en la contraseña:** Microsoft Edge agrega su propio botón para ver la contraseña; se oculta con `::-ms-reveal` en `login.css`, así queda solo el de la app.
- **Personajes siempre dentro de la tarjeta:** la grilla usa columnas que no pueden ser más anchas que la tarjeta. Además, si el equipo no tiene el emoji 🧑‍🚀 "unido" (pasa en algunos Windows, que lo dibujan como 🧑🚀), se usa el emoji `alt` del avatar (🚀). Lo decide `LOGIN_EMOJI()` en `login.config.js`.

### Reacciones de Librín

| Momento | Imagen |
|---|---|
| Esperando (se mece saludando) | `saludo.png` |
| Escribe el usuario o el nombre | `aprender.png` |
| Escribe la contraseña (no mira) | `ojos-cerrados.png` |
| Muestra la contraseña (espía) | `guino.png` |
| Error en un campo | `vamos.png` |
| Contraseña incorrecta | `animo.png` |
| Usuario libre / volver a iniciar sesión | `bien.png` |
| Contraseña súper segura | `excelente.png` |
| Elige personaje / abre Crear cuenta | `increible.png` |
| Cosquillas (tocarlo 4 veces rápido) | `orgullo.png` |
| Entró a la app (salta) | `logrado.png` |

Además se inclina hacia el puntero, da consejos si lo tocan y, si nadie lo usa por un rato, hace una reacción solo (`reaccionSola` en `login.config.js`).

## Racha diaria de lectura

- Se suma **1 día de racha al aprobar el primer quiz del día** (aprobar = llegar a las correctas que pide ese cuento). Los demás quizzes de ese día no suman otro día.
- Si pasa un día entero sin aprobar un quiz, la racha se apaga y vuelve a empezar desde 1.
- **Puntos extra**: cada día de racha da 5 puntos más que el anterior (día 1: +5, día 2: +10, día 3: +15…), con un tope de +100 por día (desde el día 20). Para comparar: leer una parte da +50 y cada respuesta correcta +100, así que la racha no desbalancea el sistema.
- **Indicador** en la tarjeta del menú principal: fuego encendido (hoy ya leíste), fuego dormido con "!" (falta el quiz de hoy) o apagado (racha en 0), con los últimos 7 días. Al tocarlo se abre el detalle (semana, récord y cuántos puntos se ganan hoy).
- **Aviso de racha completa**: aparece al aprobar el primer quiz del día, con el fuego, el número de días, la semana, los puntos ganados y "¡Nuevo récord!" si corresponde.
- Usa la fecha del dispositivo y se guarda en el progreso de cada usuario (`S.racha`). "Reiniciar progreso" en Opciones también reinicia la racha.

### Fueguito animado

El fuego de la racha es un personaje (**Fueguito**) dibujado directamente en la página (`js/racha/racha.personaje.js`), así cada parte se puede mover por separado. Las animaciones están en `css/racha.css` («Fueguito animado»):

| Cuándo | Qué hace |
|---|---|
| Racha de hoy hecha (indicador y detalle) | Parpadea, mueve las llamitas de los costados, la llama de adentro late, le salen chispitas y se balancea. Si le pasás el mouse (o lo tocás), salta. |
| Racha pendiente o apagada | Duerme: respira despacio y le salen "z" flotando. |
| Aviso de racha completa | Entra creciendo, pone ojitos felices y la boca abierta, y salta de alegría 4 veces (la sombra se achica en cada salto). |

Si el sistema tiene activado *reducir movimiento*, queda quieto. Las imágenes `img/racha/fuego.svg` y `fuego-apagado.svg` tienen el mismo dibujo y se siguen usando en los circulitos chicos del calendario.

### Sin botón de prueba

Ya no está el botón **🧪 Prueba / Día +1**: la racha usa siempre **la fecha real del dispositivo**. Si una cuenta había simulado días con ese botón y le quedaron días «del futuro», la app los borra sola y vuelve a contar la racha hasta hoy (los puntos que ganó se mantienen).

## Reiniciar progreso (Opciones)

*Reiniciar progreso* borra los puntos, las partes leídas, los quizzes, los niveles y la racha (se mantienen el nombre, el personaje y las preferencias). Como no se puede deshacer:

- **Con una cuenta:** pide **la contraseña de la cuenta**. Si está mal, avisa y deja probar de nuevo; si está bien, borra. Se puede cancelar con *Cancelar*, con *Escape* o tocando afuera. El ojito muestra lo que se escribió.
- **Como invitado:** no hay contraseña, así que solo pregunta «¿Seguro…?».

La contraseña se compara con el hash guardado de la cuenta (`Login.verificarClave()`, en `js/login/login.controller.js`); el diálogo es `pedirClave()` de `js/nucleo/nucleo.dialogos.js` y sus textos están en `js/opciones/opciones.config.js`.

## Ranking

- **Solo cuentas reales:** se sacaron los jugadores inventados. Aparecen únicamente las cuentas creadas con *Crear cuenta*; el invitado puede ver el ranking pero no aparece en él.
- **Se mantiene entre sesiones:** cada vez que se guarda el progreso de una cuenta (al leer una parte, al terminar un quiz, al cambiar el nombre…), se anotan su nombre, su personaje y sus puntos en una tabla guardada en el navegador (`neolectura.ranking` en localStorage). Al cerrar y volver a abrir la app, siguen ahí. Las cuentas creadas antes de esta actualización se agregan solas con el progreso que ya tenían.
- **Pantalla:** la mascota te señala («¡Buen trabajo!») y dice en qué puesto estás. Tu fila tiene borde turquesa y dice *Tú*.
- **Importante:** como la app no tiene servidor, el ranking muestra las cuentas creadas **en ese dispositivo/navegador**. Para un ranking compartido entre todas las compus hay que guardar la tabla en un servidor (por ejemplo, Supabase o Firebase): alcanza con reemplazar `ranking.storage.js` por uno que tenga las mismas funciones (`leer`, `guardar`, `borrar`).

## Personajes

NeoLectura tiene cuatro personajes: 📘 **Librín**, 🎀 **Librina** (el libro rosa con moño lila), 📚 **Librón** y 👵 **Librona** (el libro violeta con el pelo canoso, la versión mujer de Librón). Cada uno es **una voz del audiolibro y una mascota**: el personaje que eliges en *Opciones → Personaje y voz* (o en el botón 🗣 del reproductor del cuento) es el que te lee los cuentos **y** el que aparece en las tarjetas de inicio, niveles, créditos y ranking, en la lectura y en los quizzes, con sus propias reacciones y su nombre de su color (Librín turquesa, Librina rosa, Librón rojo, Librona violeta). Si lo cambias desde el reproductor, la mascota cambia en el momento, con la misma cara. El inicio de sesión sigue con Librín, porque ahí todavía no hay un usuario elegido.

| Personaje | Voz | Notas |
|---|---|---|
| 📘 Librín | **Chico**: voz de hombre bien aguda (tono 1,6) y un poco rápida | Es el que se usa si no se eligió ninguno |
| 🎀 Librina | **Chica**: voz de mujer muy aguda (tono 1,8) y rápida, de nena | Dice "orgullosa" donde los varones dicen "orgulloso" |
| 📚 Librón | **Señor**: voz de hombre grave (tono 0,7) y tranquila | Como su `no-te-rindas` sonríe, al errar usa `nublado` |
| 👵 Librona | **Señora**: voz de mujer grave (tono 0,55) y lenta, de abuela | Dice "orgullosa". Su foto de perfil (la de la lista de voces) baja un poco, porque por el pelo tiene la cara más abajo que los demás |

Librín y Librina ya no se parecen porque se arman sobre voces distintas (de hombre y de mujer), además del tono. Para que un personaje suene más joven se le sube el `tono` y la `vel`; para que suene más mayor, se le bajan. Si un equipo tiene voces de un solo tipo (por ejemplo, solo de mujer), cada personaje usa su `tonoSinBase`, así los cuatro igual suenan distintos (de más agudo a más grave: Librina, Librín, Librona, Librón).

**Cómo agregar un personaje:**

1. Poner sus 21 reacciones en `img/<id>/` con **los mismos nombres** que las de `img/librin/` (`saludo.png`, `bien.png`… `triste.png`), todas de **513×508**, con el libro del mismo tamaño y en el mismo lugar que en las de Librín (así no "salta" al cambiar de personaje).
2. Agregar un renglón en `js/personajes/personajes.config.js` (copiando uno parecido y cambiando `id`, `nombre`, `genero`, `base` —`'f'` o `'m'`—, `tono`, `tonoSinBase`, `vel`, `det`, `saludo` y `color`). Si le falta alguna cara, se indica en `cambios` cuál usar en su lugar. Si en la foto de perfil redonda se le corta la cara, se corre con `foto` (como Librona).

Nada más: aparece solo en Opciones, en el panel del cuento y como mascota.

### Arreglos en las reacciones de Librina

Las reacciones vienen de dos hojas de 10 dibujos cada una, más la imagen base. Al recortarlas se les sacó el fondo y los globitos de texto (blancos y de colores; la nube de lluvia de `nublado` se mantiene), y se ubicaron con el libro del mismo ancho y los pies a la misma altura que Librín en cada reacción. Además se corrigió:

- **`pensando`**: le faltaba el brazo derecho; se le agregó el de la imagen base, pegado al borde de las páginas.
- **`animo`**: tenía una rayita rosa fuerte cruzando el guante y la esquina del libro; se borró.
- **Pedacitos sueltos** de los dibujos vecinos que quedaban en el borde de algunas (por ejemplo, una puntita verde en `aprender`).
- **Colores parejos:** en una de las hojas el rosa del libro y el lila del moño eran más claros; ahora todas usan los de la imagen base.
- **Textos:** las frases de los globitos estaban en masculino ("¡Qué orgulloso de vos!", "¡Muy bien echo!"); en la app, la mascota dice "orgullosa" cuando es Librina.

### Arreglos en las reacciones de Librona

Se recortaron igual que las de Librina (sin fondo ni globitos, el libro del mismo ancho que el de Librín y los pies a la misma altura; como el pelo la hace más alta, se achicó un poquito todo para que entre la cabeza). Además se corrigió:

- **Colores parejos:** cada hoja tenía otro violeta (una más rosado, otra más claro); ahora la tapa, los zapatos y los anteojos tienen el violeta de la imagen base.
- **Anteojos:** en una de las hojas tenían el armazón negro y finito; ahora son violetas con borde negro, como en la imagen base y en la otra hoja (aro, puente y patitas).
- **`pensando`**: la mano derecha estaba "flotando" al lado del libro, sin brazo; se le dibujó el brazo (sale de las páginas y baja hasta el guante, como en la imagen base).
- **`triste`**: las piernas eran un manchón de rayas negras y grises; se redibujó el final de la tapa con su borde y dos piernas hasta las zapatillas. También se recuperó el garabato de tristeza (Librina lo tiene).
- **`segui-asi`**: quedaba la colita de un globito arriba del pelo; se borró.
- **Globitos con el borde cortado:** algunos ("¡Muy bien!", "¡Increíble!") se colaban con el fondo y no se borraban; ahora se detectan.
- **Textos:** en las hojas había errores ("¡No te rendas!", "¡Muy bien echo!") y frases en masculino ("¡Qué orgulloso de vos!"); en la app no se usan las frases de los globitos, y la mascota dice "orgullosa".

## Mascota compañera

La mascota (Librín, Librina, Librón o Librona: el personaje que elegiste) acompaña la lectura y los quizzes con un globito. En las tarjetas de inicio, niveles y créditos aparece saludando, con un libro y festejando. Las frases son las mismas para todos los personajes (en `companero.config.js`).

**En la lectura** (debajo del texto):

| Momento | Cara | Qué dice |
|---|---|---|
| Al entrar a una parte | `pensando` | La pregunta para pensar de esa parte (`librin` en el archivo del cuento). En la última parte agrega que después viene el quiz |
| Empieza el audiolibro | `guino` | Que siga con la vista las palabras azules (unos segundos y vuelve a la pregunta) |
| Por la mitad | `vos-podes` | ¡Ya vas por la mitad! |
| Pausa / sigue | `ojos-cerrados` / `segui-asi` | Hacemos una pausa… / ¡Seguimos! |
| Termina | `muy-bien` | ¡Muy bien! + «¿Ya puedes responder?» con la pregunta de la parte |
| Toca una palabra subrayada | `aprender` | Qué significa (reemplaza la cajita de definición de antes) |
| La tocan | `excelente`, `genial`, `gran-trabajo`, `segui-asi` | Algo divertido |

**En el quiz** (debajo de las opciones): da ánimo antes de responder (`vamos` en la primera, `pensando` en las del medio, `vos-podes` en la última), festeja los aciertos con globo verde (`muy-bien`, `gran-trabajo`, `genial`, `excelente`, `increible`, van rotando) y en los errores dice cuál era la respuesta con globo rojo y **siempre con cara triste** (`no-te-rindas`, preocupado/a, o `nublado`; como el `no-te-rindas` de Librón sonríe, Librón usa `nublado` en su lugar). En el resultado: `increible` si respondió todo bien, `logrado` si aprobó, `orgullo` si terminó el último cuento del camino, `nublado` («Si te cuesta un poco más, está bien…») si no aprobó y `triste` («Hoy no te salió como querías… pero cada intento es una nueva oportunidad») si no acertó ninguna. En el ranking, la mascota te señala (`gran-trabajo`). Al terminar el quiz siempre está el botón **🏠 Volver al menú** (a la pantalla principal), además de *Siguiente nivel* / *Ver el cuento* o *Repasar* / *Reintentar*.

Para un cuento nuevo, alcanza con ponerle `librin:'…'` a cada parte (la pregunta la dice la mascota que esté elegida); si falta, dice una frase general.

## Audiolibro (lectura en voz alta)

En cada parte del cuento, debajo del título, hay un reproductor compacto:

| Botón | Qué hace |
|---|---|
| ⏮ | Reinicia la parte desde el principio y la lee de nuevo |
| ↺5 | Retrocede 5 segundos |
| ▶ Escuchar / ⏸ Pausar / ▶ Reanudar | Un solo botón para iniciar, pausar y reanudar (cambia según el momento). Al terminar dice **Otra vez** |
| 5↻ | Adelanta 5 segundos |
| 🔊 + barrita | Volumen. Tocar el parlante silencia / vuelve al volumen anterior |
| 🗣 Librina ▾ | Abre el panel con los **personajes** (Librín, Librina, Librón y Librona) y la **velocidad** (en el celular sube desde abajo) |

- Abajo de los botones se ve el avance (tiempo actual, barra y duración).
- El volumen es el mismo que el de **Opciones → Volumen de la voz** (versión grande, con porcentaje y botón **Probar**). Se guarda en el progreso de cada usuario (`S.vol`, de 0 a 1).
- El audio se corta solo al pasar de parte, al tocar «Volver», al usar el botón atrás del navegador y al cerrar sesión.
- En compu el reproductor ocupa una fila; en tablet, dos; en celular, tres (botones · avance · voz y volumen).

### Texto sincronizado

- Mientras suena, el texto se **pinta del azul de la app** (`#1B7DCB`; en modo oscuro, un celeste que se lee bien) a medida que se lee, y la palabra que se está diciendo queda **resaltada**.
- En pausa queda marcada la palabra desde donde va a seguir; con ⏮, ↺5 y 5↻ el pintado se mueve junto con el audio; al terminar queda todo pintado.
- Si el texto es largo (letra "Muy grande", celular), la pantalla **acompaña la lectura** sola. Si el usuario mueve la pantalla para mirar otra cosa, deja de acompañar hasta que toque un botón del reproductor.
- Las palabras del vocabulario siguen siendo botones con su definición.
- Con las voces que avisan por qué palabra van (las de Windows, las naturales de Edge, las de Mac/iPhone) el pintado es exacto. Con las que no avisan (las de Google en Chrome) se calcula por tiempo, contando una pausita en cada coma, y se vuelve a acomodar al empezar cada frase.

### Voces

- **Solo voces de personajes:** se elige entre **Librín, Librina, Librón y Librona** (ver «Personajes»). Ya no aparecen las voces sueltas del navegador (Elena, Tomás…).
- **Dónde se eligen:** en **Opciones → Personaje y voz** y en el botón 🗣 del reproductor de cada cuento. Es la misma elección (se guarda en `S.voz` y `S.ritmo` de cada usuario), así que se cambia en un lado y se ve en el otro.
- **Velocidad:** 🐢 **Lenta** (25 % más lenta), 🙂 **Normal** o 🐇 **Rápida** (30 % más rápida), para cualquier personaje. Se ajustan en `ritmos` de `audio.config.js`. Cuando no es Normal, el botón del reproductor muestra la tortuga o el conejo.
- **Cada personaje se arma sobre una voz del equipo** (de mujer o de hombre, según su `base`), cambiándole el tono y la velocidad. Se prefiere una voz **instalada** (las que necesitan internet a veces ignoran el tono) y de Argentina, Uruguay o Latinoamérica antes que de España (orden en `paises` de `audio.config.js`). El navegador no dice si una voz es de mujer o de hombre, así que se adivina por el nombre (Elena, Tomás, Sabina, Raúl…). Si el equipo no tiene voces en español, los personajes usan la voz que venga por defecto y Opciones lo avisa.
- **Cada voz aplica la velocidad a su manera** (algunas justo, otras más o menos, y algunas la ignoran). Por eso el motor **mide** lo rápido que habla cada personaje **en cada velocidad** (y sobre cada voz del equipo) mientras lee y cuando saluda, y lo guarda en el navegador (`neolectura.audio.medidas`): así el reloj, la barra, el texto azul y los saltos de 5 s van bien, desde la próxima vez desde el principio. Si se mide que la voz no cambia de velocidad en ese navegador, aparece un aviso debajo de los botones de velocidad.
- **Cambiar mientras suena:** el cuento sigue desde la misma palabra con el personaje o la velocidad nueva. Si está en pausa o sin empezar, el personaje saluda ("¡Hola! Soy Librina…") para que se escuche cómo es, sin perder por dónde iba.
- **Cuentas de versiones anteriores:** quien tenía elegida una voz del navegador pasa solo a **Librón** si era de hombre o a **Librín** si no; quien tenía el estilo o la voz *Gigante*, a Librón.

### Cómo funciona por dentro

La app usa la voz del navegador (Web Speech API), que no tiene barra de tiempo ni deja adelantar o retroceder. Por eso `audio.motor.js`:

1. Corta el texto en frases y las lee de a una (así Chrome no corta la voz a los ~15 segundos).
2. Guarda la posición como "letra por la que va" y la convierte a segundos con una velocidad estimada (las comas cuentan como unas letras más, por la pausita). Esa velocidad se ajusta sola midiendo cuánto tarda la voz real en cada frase. Si la voz avisa por qué palabra va (evento `boundary`), se usa ese dato, que es exacto.
3. Pausar = cortar la voz y recordar la palabra; reanudar = volver a hablar desde esa palabra (funciona igual en todos los navegadores).
4. Adelantar/retroceder = mover la posición 5 segundos (redondeando al comienzo de una palabra) y seguir hablando desde ahí.
5. Si se cambia el volumen, la voz o la velocidad mientras suena, sigue desde la misma palabra con el cambio aplicado.
6. Como cada voz habla a su ritmo y aplica la velocidad a su manera, lo rápido que habla se mide y se guarda **por personaje y por velocidad** (cada 3 s cuando la voz avisa por qué palabra va, y al terminar cada frase). Si todavía no hay medida para una velocidad, se calcula a partir de otra velocidad del mismo personaje.
7. Para pintar el texto, cada palabra va en un `<span data-i="…">` con la letra donde empieza; el controlador marca como `leido` las anteriores a la palabra actual y como `actual` la que se está diciendo.

> Como los tiempos son estimados, los 5 segundos pueden no ser exactos al primer salto; después de la primera frase la estimación se ajusta. Algunas voces (por ejemplo, en algunos Android) ignoran el volumen: en ese caso se usa el volumen del dispositivo.

> Es un prototipo sin servidor: las cuentas quedan guardadas en el navegador de este dispositivo. En una app real, el usuario y la contraseña se verifican en un servidor.

## Importante

Las cuentas nuevas (y el invitado nuevo) empiezan con **0 puntos** (`points` en `DEF`, `js/nucleo/nucleo.estado.js`). *Reiniciar progreso* también vuelve a 0. Las cuentas que ya existían conservan sus puntos.

Abrir `index.html` desde un servidor local/repo web es recomendable para probar el proyecto (también funciona abriéndolo directo).
