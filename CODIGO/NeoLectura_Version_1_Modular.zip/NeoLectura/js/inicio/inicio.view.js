/* =====================  INICIO · VISTA  =====================
   La pantalla principal: saludo, puntos y estrellas, la racha, el camino de lectura
   (los 4 cuentos, cada uno es un nivel) y los accesos a Ranking y Créditos.
   Los estilos están en css/inicio.css.                                              */
const InicioVista=(()=>{
  /* Las 3 estrellas según los puntos (también las usa el ranking) */
  function estrellas(){const n=starCount();return `<div class="stars" aria-label="${n} de 3 estrellas">${[0,1,2].map(i=>`<span class="${i<n?'on':''}">${ic('star',16,true)}</span>`).join('')}</div>`}

  /* Tarjeta de un cuento en el camino: cada cuento es un nivel y se desbloquea al aprobar el anterior */
  function tarjeta(s){
    const img=cover(s),nv=`<span class="nv">${Camino.etiqueta(s.id)}</span>`;
    const cap=`<div class="cap"><b>${ESC(s.title)}</b><i>${ESC(s.autor||s.genre)}</i></div>`;
    if(!unlocked(s.id,0)){
      const a=Camino.anterior(s.id);
      return `<article class="story" aria-disabled="true" aria-label="${ESC(s.title)}: bloqueado"><div class="cover"><img src="${img}" alt="">${nv}
        <div class="veil">${ic('lock',26)}<span>Aprueba «${ESC(a?a.title:'')}»</span></div>${cap}</div><div class="foot">Bloqueado</div></article>`;
    }
    const hecho=Camino.aprobado(s.id),st=started(s.id);
    const tot=s.levels.length*PARTS,leidas=s.levels.reduce((n,_,l)=>n+partsRead(s.id,l),0);
    const pie=hecho?'Completado ✓ · Repasar':!st?'¡A leer!':leidas<tot?`Continuar · ${leidas}/${tot} partes`:'Falta el quiz ⭐';
    return `<article class="story open${hecho?' hecho':''}" data-a="nav" data-to="levels:${s.id}" role="button" tabindex="0" aria-label="Abrir ${ESC(s.title)}">
      <div class="cover"><img src="${img}" alt="">${nv}${hecho?`<span class="badge ok">${ic('check',14)}</span>`:st?'':'<span class="badge">¡Nuevo!</span>'}${cap}</div>
      <div class="foot">${pie}</div></article>`;
  }

  function pantalla(){
    return `<header class="hdr home"><div><h1>NeoLectura</h1><div class="sub">Bienvenido, ${ESC(Filtro.mostrar(S.name))} ${S.avatar||'👋'}</div></div>
      <div class="acts">
        <button class="rbtn" data-a="nav" data-to="ranking" aria-label="Ranking">${ic('trophy',18)}</button>
        <button class="rbtn" data-a="nav" data-to="settings" aria-label="Opciones">${ic('gear',18)}</button>
        <button class="rbtn" data-a="logout" aria-label="Salir">${ic('logout',18)}</button>
      </div></header>
    <main>
      <section class="mcard">${MASCOTA_IMG('saludo')}<div><div class="mt">¡Elige un cuento!</div><div class="ms">Tienes <b>${fmt(S.points)} puntos</b></div>${estrellas()}</div>${RachaVista.indicador()}</section>
      <div class="sec"><h3>Camino de lectura</h3><span>${totalDone()} de ${STORIES.length} niveles completados</span></div>
      <div class="grid camino">${STORIES.map(tarjeta).join('')}</div>
      <div class="links">
        <button class="link" data-a="nav" data-to="ranking"><span style="color:#F2A900">${ic('trophy',24)}</span>Ranking</button>
        <button class="link" data-a="nav" data-to="credits"><span style="color:var(--teal)">${ic('book',24)}</span>Créditos</button>
      </div>
    </main>`;
  }

  Pantallas.registrar('home',{html:pantalla});
  return {pantalla,tarjeta,estrellas};
})();
