/* =====================  FILTRO DE NOMBRES · LISTAS  =====================
   Palabras que no se permiten en los nombres de usuario ni en el nombre que
   se muestra (Opciones y ranking). NeoLectura es para chicos de primaria:
   nada de malas palabras, insultos, temas fuertes ni datos personales.

   Cómo se escriben las palabras (para agregar o sacar una):
   - En minúscula y SIN tildes (la ñ sí se escribe: "coño").
   - "partes": se buscan en cualquier lugar del nombre, aunque esté pegado a
     otras palabras o separado con puntos ("elpelotudo", "m.i.e.r.d.a").
     Sirven para palabras que no aparecen dentro de palabras inocentes.
   - "enteras": solo cuentan si son una palabra completa ("culo" sí, pero
     "película" o "Vehículo" no). Sirven para palabras cortas que aparecen
     dentro de nombres comunes (pene → Penélope, verga → Vergara, coger → recoger).
   - "permitidas": palabras inocentes que contienen una de las "partes" y que
     no tienen que bloquearse (computadora contiene "puta", controlo contiene "trolo").
   - "reservados": nombres que podrían usarse para hacerse pasar por un adulto
     o por la app.
   El filtro también entiende trampas comunes: letras repetidas ("puuuta"),
   números en lugar de letras ("p0rn0", "1diota") y símbolos en el medio.
   El usuario nunca ve qué palabra se bloqueó (así no aprende a esquivarla).  */
const FILTRO_CFG={
  partes:[
    // Insultos y groserías (rioplatenses y generales)
    'pelotud','boludo','boluda','idiot','imbecil','estupid','tarado','tarada','mogolic','retrasad','subnormal',
    'gilipoll','pendej','cabron','malparid','malnacid','desgraciad','maldit','cretin','cornud','hijodeputa','hijadeputa',
    'hdp','hdlp','hdlgp','lpm','lpqtp','lpqlp','lcdtm','ctm','conchetumadre','conchatumadre','conchesumadre',
    'sorete','mierd','carajo','cagon','cagar','cagad','caguen','pajer','ojete','culiad','culiao','qliao','conchud',
    'puta','puto','putit','petera','petero','chupame','chupala','chupalo','chupenla','chupapij','huevon','guevon',
    'weon','webon','gueon','joder','jodet','jodid','cojon','chingad','chingar','culero','mamon','negrata',
    'trolo','trolaz','tortiller','maricon','villero','sudaca',
    // Partes íntimas del cuerpo y contenido sexual
    'porno','porn','sexo','sexy','sexual','xxx','vagina','vulva','clitor','pezon','testicul','escroto','prepucio',
    'penis','nalga','culon','tetona','tetudo','tetuda','pechugon','pitulin','garch','garompa','poronga','pijud',
    'vergud','bombacha','calzon','desnud','erotic','erotism','orgasm','masturb','eyacul','esperma','erecc','coito',
    'fornic','mamada','preservativo','viagra','prostitu','violad','violac','violar','abusador','pedofil','incest',
    'zoofil','kamasutra','onlyfans','hentai','nsfw','boobs','titties','dildo','blowjob','handjob',
    // Violencia, muerte y temas fuertes
    'asesin','suicid','autolesi','ahorcarm','terroris','masacr','genocid','degoll','descuartiz','tortur','secuestr',
    'cadaver','matate','matalo','matenlo','matart','matarl','muerete','nazi','hitler','kkk','esvastica','rapist',
    // Drogas y alcohol
    'droga','cocain','marihuan','mariguan','falopa','borrach','porrer','extasis','metanfet','cerveza','vodka',
    'whisky','fernet',
    // Insultos en inglés
    'fuck','shit','bitch','asshole','pussy','cunt','slut','whore','nigg','faggot','stfu','motherf','bastard',
    'retard','stupid'
  ],
  enteras:[
    // Palabras cortas que aparecen dentro de nombres o palabras inocentes
    // (por eso solo cuentan enteras: "pito" sí, pero "Felipito" o "Pitágoras" no)
    'culo','culos','culito','orto','ano','anal','poto','upite','pene','penes','pito','pitos','pitito','pitote',
    'teta','tetas','tetita','lolas','bubis','chichis','pija','verga','chota','choto','concha','cajeta','chucha',
    'polla','glande','semen','condon','tanga','nopor','coger','cojer','cogida','paja','pete',
    // De baño (en un nombre quedan feos)
    'caca','pis','pichi','pedo','pedos','popo','mear',
    // Insultos cortos
    'marica','trola','zorra','forro','forra','coño','garca','lacra','ortiva','pinche','tonto','tonta','bobo','boba',
    'inutil','mongo','mongolo','mongui','csm','ptm','qlo','alv','mrd','vrg',
    // Violencia y muerte
    'matar','morir','morite','muerto','muerta',
    // Drogas y alcohol
    'porro','faso','merca','lsd','fumon','birra',
    // En inglés
    'sex','dick','cock','fag','fck','fuk','wtf','kys','kill','killer','rape','nude','naked','tits','butt','booty',
    'horny','milf','cum','dumb','crap','piss','damn','loser','weed','blunt'
  ],
  permitidas:['comput','disput','diput','imput','reput','amput','deput','control','nazir','petrolo','therapist'],
  reservados:{
    partes:['admin','neolectura'],
    enteras:['moderador','moderadora','soporte','sistema','oficial','staff','root','profe','profesor','profesora',
             'maestro','maestra','seño','docente','director','directora']
  },
  // Datos personales: con tantos números juntos (o en total) podría ser un teléfono o un DNI
  maxNumeros:4,
  datosPersonales:['@','gmail','hotmail','outlook','yahoo','www','http','.com'],
  // Nombre que se muestra en lugar de uno no permitido (cuentas viejas en el ranking)
  reemplazo:'Lector',
  // Mensajes (no dicen qué palabra fue)
  msg:{
    palabra:'Ese nombre no está permitido. ¡Elige uno amable! 🙂',
    reservado:'Ese nombre está reservado. Elige otro.',
    datos:'No pongas números largos ni datos personales (teléfono, DNI o mail).',
    letras:'Tu nombre tiene que tener al menos 2 letras.'
  }
};
