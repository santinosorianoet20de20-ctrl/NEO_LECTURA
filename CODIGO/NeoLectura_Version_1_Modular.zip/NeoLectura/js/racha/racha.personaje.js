/* =====================  RACHA · PERSONAJE (FUEGUITO)  =====================
   El fuego de la racha dibujado directamente en la página (SVG en línea),
   para poder animar cada parte por separado. Es el mismo dibujo que
   img/racha/fuego.svg y fuego-apagado.svg (esas imágenes se siguen usando
   en los circulitos chicos del calendario, donde no hace falta animarlo).

   RachaPersonaje.html({estado, ancho, clase})
     estado: 'prendido' → contento: parpadea, se mueven las llamitas, le salen chispas
             'dormido'  → apagado: respira despacio y le salen "z"
             'festeja'  → racha completa: ojitos felices, boca abierta y salta de alegría
   Las animaciones están en css/racha.css («Fueguito animado»). Si el sistema
   tiene activado "reducir movimiento", no se mueve (regla general de css/nucleo.css). */
const RachaPersonaje=(()=>{
  let n=0; // cada dibujo usa ids propios para sus degradés (puede haber varios en la pantalla)

  /* Partes del dibujo (las mismas de img/racha/fuego.svg) */
  const P={
    izq:'M58 164C34 154 22 130 26 102C36 122 50 130 66 130Z',
    der:'M148 126C166 120 176 106 178 86C192 112 188 146 164 166Z',
    llama:'M116 8C100 30 104 48 120 68C142 96 168 114 168 152C168 198 138 226 100 226C62 226 32 198 32 152C32 112 60 98 78 74C92 56 100 34 116 8Z',
    adentro:'M102 82C116 116 144 132 144 168C144 198 124 214 100 214C76 214 56 198 56 168C56 136 88 122 102 82Z',
    brillo:'M58 146C58 124 68 110 82 94'
  };
  const COLOR={
    prendido:{ext:['#FFB13B','#ED823A','#E2532C'],int:['#FFE45C','#F7C900'],linea:'#1B1B1B',brillo:.55},
    dormido:{ext:['#DCE5EB','#C2D0DA','#A9BBC8'],int:['#F3F7FA','#D3DEE6'],linea:'#5F7686',brillo:.6}
  };

  /* La carita según el estado */
  function cara(estado,linea){
    if(estado==='dormido')return `<g class="rc-pj-ojos" stroke="${linea}" stroke-width="5" stroke-linecap="round" fill="none">
        <path d="M76 162Q83 168 90 162"/><path d="M110 162Q117 168 124 162"/></g>
      <path d="M93 184Q100 188 107 184" stroke="${linea}" stroke-width="5" stroke-linecap="round" fill="none"/>`;
    const mejillas='<g fill="#FF7A6B" opacity=".55"><ellipse cx="70" cy="178" rx="8" ry="5"/><ellipse cx="130" cy="178" rx="8" ry="5"/></g>';
    if(estado==='festeja')return `<g class="rc-pj-ojos" stroke="${linea}" stroke-width="6" stroke-linecap="round" fill="none">
        <path d="M75 162Q83 150 91 162"/><path d="M109 162Q117 150 125 162"/></g>${mejillas}
      <path d="M86 177Q100 177 114 177Q112 196 100 196Q88 196 86 177Z" fill="#7A2E2E" stroke="${linea}" stroke-width="4" stroke-linejoin="round"/>
      <path d="M93 189Q100 184 107 189Q104 194 100 194Q96 194 93 189Z" fill="#FF7A6B"/>`;
    return `<g class="rc-pj-ojos"><g fill="${linea}"><ellipse cx="83" cy="160" rx="7.5" ry="10"/><ellipse cx="117" cy="160" rx="7.5" ry="10"/></g>
        <g fill="#fff"><circle cx="85.5" cy="156" r="3"/><circle cx="119.5" cy="156" r="3"/></g></g>${mejillas}
      <path d="M88 180Q100 194 112 180" stroke="${linea}" stroke-width="5" stroke-linecap="round" fill="none"/>`;
  }

  function html({estado='prendido',ancho=48,clase=''}={}){
    const id='rcpj'+(++n),dormido=estado==='dormido',c=dormido?COLOR.dormido:COLOR.prendido;
    const stops=(l)=>l.map((col,i)=>`<stop offset="${l.length===1?0:i/(l.length-1)}" stop-color="${col}"/>`).join('');
    // Encendido: chispitas que suben desde la punta · Dormido: "z" que flotan
    const extra=dormido
      ?`<g class="rc-pj-z" fill="${c.linea}" font-family="Nunito, Arial, sans-serif" font-weight="900">
          <text x="140" y="56" font-size="22">z</text><text x="156" y="38" font-size="17">z</text><text x="168" y="22" font-size="13">z</text></g>`
      :`<g class="rc-pj-chispas" fill="#FFC81E"><circle cx="112" cy="20" r="5"/><circle cx="96" cy="40" r="4"/><circle cx="130" cy="44" r="3.5"/></g>`;
    return `<svg class="rc-fuego rc-pj rc-pj-${estado} ${clase}" viewBox="0 0 200 240" width="${ancho}" height="${Math.round(ancho*1.2)}" aria-hidden="true" focusable="false">
      <defs><linearGradient id="${id}e" x1="0" y1="0" x2="0" y2="1">${stops(c.ext)}</linearGradient>
        <linearGradient id="${id}i" x1="0" y1="0" x2="0" y2="1">${stops(c.int)}</linearGradient></defs>
      <ellipse class="rc-pj-sombra" cx="100" cy="230" rx="52" ry="7" fill="#0B2A4A" opacity=".14"/>
      <g class="rc-pj-cuerpo">
        <g stroke="${c.linea}" stroke-width="6" stroke-linejoin="round" stroke-linecap="round" fill="url(#${id}e)">
          <path class="rc-pj-izq" d="${P.izq}"/><path class="rc-pj-der" d="${P.der}"/><path d="${P.llama}"/>
        </g>
        <path class="rc-pj-adentro" d="${P.adentro}" fill="url(#${id}i)"/>
        <path d="${P.brillo}" stroke="#fff" stroke-opacity="${c.brillo}" stroke-width="7" stroke-linecap="round" fill="none"/>
        ${cara(estado,c.linea)}
      </g>
      ${extra}
    </svg>`;
  }

  return {html};
})();
