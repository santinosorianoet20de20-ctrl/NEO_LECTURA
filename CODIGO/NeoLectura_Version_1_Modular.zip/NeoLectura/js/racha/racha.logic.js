/* =====================  RACHA · LÓGICA  =====================
   Calcula la racha con la fecha local del dispositivo. Los datos se guardan
   dentro del progreso de cada usuario (S.racha), así cada lector tiene la suya.
   S.racha = {dias, ultimo:'AAAA-MM-DD', mejor, historial:['AAAA-MM-DD', …]}
   La fecha es siempre la del dispositivo (ya no hay botón para simular otro día). */
const Racha=(()=>{
  const C=RACHA_CFG;

  /* --- Fechas (siempre en hora local, no UTC) --- */
  const clave=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  const hoy=()=>clave(new Date());
  function sumarDias(k,n){const [y,m,d]=k.split('-').map(Number);return clave(new Date(y,m-1,d+n))}
  function diaSemana(k){const [y,m,d]=k.split('-').map(Number);return new Date(y,m-1,d).getDay()}

  /* Datos de la racha del usuario actual (los crea si no existen) */
  function datos(){
    if(!S.racha||typeof S.racha!=='object')S.racha={dias:0,ultimo:'',mejor:0,historial:[]};
    if(!Array.isArray(S.racha.historial))S.racha.historial=[];
    alDiaDeHoy(S.racha);
    return S.racha;
  }

  /* Hasta la versión de prueba había un botón "Día +1" para simular otros días: si quedaron
     días "del futuro" en la racha, se borran y la racha se vuelve a contar hasta hoy
     (los días seguidos que terminan en el último día real). Los puntos ganados se mantienen. */
  function alDiaDeHoy(r){
    const h=hoy();
    if(!(r.ultimo>h)&&!r.historial.some(d=>d>h))return;
    r.historial=r.historial.filter(d=>d<=h).sort();
    r.ultimo=r.historial[r.historial.length-1]||'';
    const seguidos=hasta=>{let n=0,d=hasta;while(d&&r.historial.includes(d)){n++;d=sumarDias(d,-1)}return n};
    r.dias=seguidos(r.ultimo);
    r.mejor=Math.max(r.dias,...r.historial.map(seguidos));
    if(typeof save==='function')save();
  }
  try{localStorage.removeItem('neolectura.prueba.dias')}catch(e){} // el día simulado que guardaba el botón de prueba

  /* Puntos extra que da un día de racha */
  const bonus=dias=>Math.min(dias*C.puntosPorDia,C.tope);

  /* Estado para mostrar:
     'hecha'     → hoy ya se aprobó un quiz
     'pendiente' → la racha sigue viva pero falta el quiz de hoy
     'apagada'   → se perdió (o nunca empezó) */
  function estado(){
    const r=datos(),h=hoy();
    if(r.ultimo===h)return {tipo:'hecha',dias:r.dias,mejor:r.mejor,hoyGana:0,mananaGana:bonus(r.dias+1)};
    if(r.ultimo===sumarDias(h,-1)&&r.dias>0)return {tipo:'pendiente',dias:r.dias,mejor:r.mejor,hoyGana:bonus(r.dias+1)};
    return {tipo:'apagada',dias:0,mejor:r.mejor,perdida:r.dias,hoyGana:bonus(1)};
  }

  /* Últimos 7 días (terminando hoy) para el calendario */
  function semana(){
    const r=datos(),h=hoy(),hechos=new Set(r.historial);
    return Array.from({length:7},(_,i)=>{
      const k=sumarDias(h,i-6),dw=diaSemana(k);
      return {clave:k,letra:C.dias[dw],nombre:C.diasLargos[dw],hecho:hechos.has(k),hoy:k===h};
    });
  }

  /* Se llama al aprobar un quiz. Si es el primero del día, suma un día de racha
     y devuelve el resultado; si hoy ya se había contado, devuelve null.
     NO suma los puntos: eso lo hace Quiz.terminar (js/quiz/quiz.logic.js) con "bonus". */
  function completarHoy(){
    const r=datos(),h=hoy();
    if(r.ultimo===h)return null;
    const seguia=r.ultimo===sumarDias(h,-1)&&r.dias>0;
    const anterior=r.dias;
    r.dias=seguia?r.dias+1:1;
    r.ultimo=h;
    if(!r.historial.includes(h))r.historial.push(h);
    if(r.historial.length>C.historialMax)r.historial=r.historial.slice(-C.historialMax);
    const record=r.dias>r.mejor;
    r.mejor=Math.max(r.mejor,r.dias);
    return {dias:r.dias,bonus:bonus(r.dias),record:record&&r.dias>1,nueva:r.dias===1,perdida:!seguia&&anterior>0?anterior:0};
  }

  function reiniciar(){S.racha=null}

  return {hoy,sumarDias,estado,semana,completarHoy,bonus,reiniciar};
})();
