/* =====================  NIVELES · CONTROLADOR  =====================
   Tocar la tarjeta de un nivel lleva a la primera parte sin leer
   (o al quiz, si ya se leyeron todas).                              */
Pantallas.accion('cont',d=>{
  const sid=d.s,l=+d.l;let p=-1;
  for(let j=0;j<PARTS;j++){if(!S.parts[kp(sid,l,j)]){p=j;break}}
  go(p<0?{s:'quiz',sid,l}:{s:'read',sid,l,p});
});
