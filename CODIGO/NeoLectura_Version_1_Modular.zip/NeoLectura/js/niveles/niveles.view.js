/* =====================  NIVELES · VISTA  =====================
   La pantalla de un cuento: sus 3 partes y el quiz (con lo que ya se leyó y el mejor
   resultado), y el cuento que sigue en el camino (bloqueado hasta aprobar este).
   Ruta: {s:'levels', sid}. Un cuento bloqueado no se abre.
   Los estilos están en css/niveles.css.                                            */
const NivelesVista=(()=>{
  function pantalla(r){
    const sid=r.sid,s=story(sid),sig=Camino.siguiente(sid);
    const lv=s.levels.map((L,i)=>{
      const et=Camino.etiqueta(sid,i);
      if(!unlocked(sid,i))return `<div class="lvl locked"><div class="lvl-top"><div class="num">${ic('lock',22)}</div><div class="t"><h4>${et}: ${ESC(L.name)}</h4><p>Bloqueado</p></div></div></div>`;
      const dn=!!S.done[kd(sid,i)],n=L.quiz.length,mejor=S.quiz[kd(sid,i)]||0;
      const steps=L.parts.map((p,j)=>{const r=!!S.parts[kp(sid,i,j)];
        return `<div class="step" data-a="nav" data-to="read:${sid}:${i}:${j}" role="button" tabindex="0" title="${ESC(p.t)}"><div class="circ ${r?'done':''}">${r?ic('check',18):j+1}</div><span class="lab">${ESC(p.t)}</span></div>`}).join('');
      return `<div class="lvl" data-a="cont" data-s="${sid}" data-l="${i}" role="button" tabindex="0">
        <div class="lvl-top"><div class="num">${s.nivel}</div><div class="t"><h4>${et}: ${ESC(L.name)}</h4><p>${dn?`Completado ✓ · Mejor quiz: ${mejor} de ${n}`:`Quiz de ${n} preguntas · Para aprobar: ${L.aprobar} correctas`}</p></div><span class="go">${ic('chev',22)}</span></div>
        <div class="steps">${steps}<div class="arrow">${ic('right',16)}</div>
        <div class="step q" data-a="nav" data-to="quiz:${sid}:${i}" role="button" tabindex="0"><div class="circ quiz ${dn?'done':''}">${ic('star',20,dn)}</div><span class="lab">Quiz</span></div></div></div>`;
    }).join('');
    // El nivel que sigue en el camino (bloqueado hasta aprobar este)
    const prox=!sig?'':unlocked(sig.id,0)
      ?`<div class="lvl prox" data-a="nav" data-to="levels:${sig.id}" role="button" tabindex="0"><div class="lvl-top"><div class="num">${sig.nivel}</div><div class="t"><h4>Sigue: ${Camino.etiqueta(sig.id)} · ${ESC(sig.title)}</h4><p>¡Ya está desbloqueado!</p></div><span class="go">${ic('chev',22)}</span></div></div>`
      :`<div class="lvl locked prox"><div class="lvl-top"><div class="num">${ic('lock',22)}</div><div class="t"><h4>Sigue: ${Camino.etiqueta(sig.id)} · ${ESC(sig.title)}</h4><p>Se desbloquea al aprobar el quiz de este cuento</p></div></div></div>`;
    return bar(s.title,'home')+`<main><div class="doc" style="max-width:none">
      <section class="mcard" style="min-height:102px;border-radius:24px">${MASCOTA_IMG('aprender')}<div><div class="mt">${Camino.etiqueta(sid)} · ${ESC(s.title)}</div><div class="ms">${ESC(s.autor)} · ${PARTS} partes + un quiz</div><div class="cnt">${sig?`Lee las ${PARTS} partes y aprueba el quiz para desbloquear el siguiente cuento.`:'¡Es el último nivel del camino!'}</div></div></section>
      ${lv}${prox}</div></main>`;
  }

  Pantallas.registrar('levels',{
    html:pantalla,
    entrar:r=>!!story(r.sid)&&unlocked(r.sid,0),               // cuento bloqueado: hay que aprobar el anterior
    permitida:r=>!!story(r.sid)&&unlocked(r.sid,0)
  });
  return {pantalla};
})();
