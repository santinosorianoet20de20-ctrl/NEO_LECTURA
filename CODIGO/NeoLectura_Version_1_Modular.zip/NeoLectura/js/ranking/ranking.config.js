/* =====================  RANKING · CONFIGURACIÓN  =====================
   El ranking muestra SOLO a las cuentas reales creadas en la app (no hay
   jugadores inventados y el invitado no aparece). Cada vez que se guarda el
   progreso de una cuenta, se anotan su nombre, su personaje y sus puntos en
   una tabla que queda guardada en el navegador (se mantiene al cerrar y
   volver a abrir la app).
   **Para cambiar los textos o cuántos se muestran, se cambia acá.**        */
const RANKING_CFG={
  clave:'neolectura.ranking', // dónde se guarda la tabla (localStorage)
  mostrar:50,                 // cuántos se muestran como máximo
  colores:['#F26B1D','#35BFC0','#1B7DCB','#8E63D4','#E0568A','#3BAA6B','#D99A00','#5C7CFA','#E06666'], // fondo de la inicial de cada uno

  textos:{
    titulo:'Ranking',
    bienYo:n=>`¡Buen trabajo, ${n}!`,
    puesto:(p,t)=>`Estás en el puesto <b>${p}</b> de ${t}`,
    invitadoTit:'Estás como invitado',
    invitadoDet:'Crea una cuenta para aparecer en el ranking con tus puntos.',
    vacioTit:'¡Todavía no hay nadie en el ranking!',
    vacioDet:'Lee un cuento y suma puntos para ser el primero.',
    tu:'Tú',
    pts:'pts',
    nota:'El ranking muestra las cuentas creadas en NeoLectura en este dispositivo.'
  }
};
