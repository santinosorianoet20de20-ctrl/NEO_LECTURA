/* =====================  CRÉDITOS · CONFIGURACIÓN  =====================
   El equipo y los textos de la pantalla Créditos.
   **Para cambiar un nombre, un rol o un texto, se cambia acá.**          */
const EQUIPO={
  nombre:'Equipo 3',
  integrantes:['Jaime Valentín','Galiano Katia','Soriano Santino'],
  roles:[
    ['Organización y documentación','Soriano Santino'],
    ['Diseño visual','Galiano Katia'],
    ['Programación y correcciones','Jaime Valentín']
  ]
};
const CREDITOS_CFG={
  titulo:'Créditos',
  app:'NeoLectura',
  subtitulo:'Plantilla de lectura dinámica',
  // Secciones de abajo del equipo: [ícono, título, texto] (íconos de js/nucleo/nucleo.utils.js)
  secciones:[
    ['book','Cuentos','Caperucita Roja, El gato con botas y Barba Azul, de Charles Perrault, y Hansel y Gretel, de los hermanos Grimm. Textos de dominio público.'],
    ['star','Ilustraciones','Dibujos simples de cada escena, hechos para este prototipo. Pronto llegan las versiones finales.'],
    ['vol','Lectura en voz alta','Usa la voz del navegador o del dispositivo, por lo que puede sonar distinto según el equipo.']
  ]
};
