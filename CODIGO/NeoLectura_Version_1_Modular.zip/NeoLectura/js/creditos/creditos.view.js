/* =====================  CRÉDITOS · VISTA  =====================
   La pantalla Créditos: el equipo con sus roles, y de dónde salen los cuentos,
   los dibujos y las voces. Ruta: {s:'credits'}. Estilos: css/creditos.css.   */
const CreditosVista=(()=>{
  const C=CREDITOS_CFG;
  function pantalla(){
    return bar(C.titulo,'home')+`<main><div class="doc">
      <section class="mcard">${MASCOTA_IMG('bien')}<div><div class="mt">${C.app}</div><div class="ms">${C.subtitulo}</div></div></section>
      <section class="set credit equipo"><h4><span style="color:var(--teal)">${ic('equipo',22)}</span>Equipo</h4>
        <p>${ESC(EQUIPO.nombre)}, conformado por: ${EQUIPO.integrantes.map(ESC).join('; ')}</p>
        <ul class="roles">${EQUIPO.roles.map(([rol,quien])=>`<li><span>${ESC(rol)}</span><b>${ESC(quien)}</b></li>`).join('')}</ul></section>
      ${C.secciones.map(([i,t,x])=>`<section class="set credit"><h4><span style="color:var(--teal)">${ic(i,22)}</span>${t}</h4><p>${x}</p></section>`).join('')}
    </div></main>`;
  }

  Pantallas.registrar('credits',{html:pantalla});
  return {pantalla};
})();
