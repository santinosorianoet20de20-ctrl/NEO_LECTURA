/* =====================  NÚCLEO · RUTAS (va último en index.html)  =====================
   - render()  dibuja la pantalla actual (R) en #app: sin sesión abierta, el inicio de
               sesión (js/login); si no, la pantalla anotada en Pantallas.
   - go(ruta)  va a otra pantalla: go('levels:caperucita-roja'), go('read:caperucita-roja:0:1'),
               go({s:'quiz',sid,l}). Corta el audio y guarda el paso en el historial del navegador.
   - Reparte los clics de los botones data-a="..." a la acción anotada (nucleo.pantallas.js).
   Las rutas en texto son "pantalla:cuento:nivel:parte".                                    */
const $app=document.getElementById('app');

/* Tamaño de letra y tema (claro / oscuro / automático) del usuario */
function applyPrefs(){
  const r=document.documentElement;
  r.style.setProperty('--fs',SIZES[S.size]||SIZES[0]);
  if(S.theme==='auto')r.removeAttribute('data-theme');else r.setAttribute('data-theme',S.theme);
}

function render(){
  applyPrefs();
  let h;
  if(!Login.activa())h=LoginVista.pantalla(); // sin sesión abierta → inicio de sesión (js/login)
  else{
    let p=Pantallas.buscar(R.s);
    if(!p||!p.permitida(R)){R={s:'home'};p=Pantallas.buscar('home')} // una pantalla que no existe o bloqueada → inicio
    h=p.html(R);
  }
  $app.innerHTML=h;
}

function parseTo(t){const a=t.split(':');return {s:a[0],sid:a[1],l:+a[2],p:+a[3]}}
function go(r){
  if(typeof r==='string')r=parseTo(r);
  const p=Pantallas.buscar(r.s);
  if(p&&p.entrar(r)===false)return; // por ejemplo, un cuento bloqueado
  R=r;
  Audiolibro.detener(); // al cambiar de pantalla se corta el audio (js/audio)
  try{history.pushState(r,'')}catch(e){}
  render();window.scrollTo(0,0);
}
window.addEventListener('popstate',e=>{
  R=e.state||{s:'home'};
  const p=Pantallas.buscar(R.s);
  if(p&&p.atras)R=p.atras(R); // por ejemplo, del quiz se vuelve al cuento
  Audiolibro.detener(); // el botón "atrás" del navegador también corta el audio
  render();
});

/* Clics: data-a="nav" va a otra pantalla; el resto, a la acción anotada por cada módulo */
document.addEventListener('click',e=>{
  const t=e.target.closest('[data-a]');if(!t)return;
  if(t.dataset.a==='nav'){go(t.dataset.to);return}
  Pantallas.hacer(t.dataset.a,t.dataset,t);
});
/* Las tarjetas que hacen de botón (role="button") también se abren con Enter o Espacio */
document.addEventListener('keydown',e=>{
  const t=e.target;
  if((e.key==='Enter'||e.key===' ')&&t.getAttribute&&t.getAttribute('role')==='button'){e.preventDefault();t.click()}
});

try{history.replaceState({s:'home'},'')}catch(e){}
render();
