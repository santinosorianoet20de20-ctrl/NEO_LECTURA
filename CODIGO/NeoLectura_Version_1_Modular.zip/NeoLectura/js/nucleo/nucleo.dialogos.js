/* =====================  NÚCLEO · AVISOS Y DIÁLOGOS  =====================
   - toast(texto)                → cartelito abajo que se va solo ("+50 puntos ⭐").
   - ask(mensaje, botón, fn)     → pregunta "¿Seguro?" con Cancelar y otro botón; fn corre si acepta.
   - pedirClave({...})           → pide una contraseña antes de hacer algo importante
                                   (lo usa Opciones → Reiniciar progreso).
   Los diálogos se cierran con Cancelar, con Escape o tocando afuera, y devuelven el foco
   al botón que los abrió. Los estilos están en css/nucleo.css («Avisos y diálogos»).     */
let tT;
function toast(t){
  let el=document.getElementById('toast');
  if(!el){el=document.createElement('div');el.id='toast';el.className='toast';el.setAttribute('role','status');document.body.appendChild(el)}
  el.textContent=t;el.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>el.classList.remove('show'),2000);
}

/* Arma el fondo oscuro con la caja, y se encarga de cerrarlo */
function dialogo(html){
  const volver=document.activeElement;
  const m=document.createElement('div');m.className='modal';m.innerHTML=html;
  function cerrar(){m.remove();document.removeEventListener('keydown',tecla,true);if(volver&&volver.isConnected&&volver.focus)volver.focus({preventScroll:true})}
  function tecla(e){if(e.key==='Escape'){e.preventDefault();cerrar()}}
  document.addEventListener('keydown',tecla,true);
  m.addEventListener('click',e=>{const b=e.target.closest('[data-m]');if(e.target===m||(b&&b.dataset.m==='no'))cerrar()});
  document.body.appendChild(m);
  return {m,cerrar};
}

function ask(msg,label,fn){
  const {m,cerrar}=dialogo(`<div class="mbox" role="dialog" aria-modal="true"><p>${msg}</p><div class="mrow"><button class="btn ghost" data-m="no">Cancelar</button><button class="btn pri" data-m="yes">${label}</button></div></div>`);
  m.querySelector('[data-m="yes"]').addEventListener('click',()=>{cerrar();fn()});
  m.querySelector('[data-m="yes"]').focus();
}

/* Pide una contraseña.
   o = {titulo, mensaje, boton, verificar: async clave => true/false, alAceptar: fn}
   Si la contraseña no es la correcta, avisa y deja probar otra vez (no se cierra). */
function pedirClave(o){
  const T={vacia:'Escribe tu contraseña.',mal:'Esa no es tu contraseña. Prueba otra vez.',ver:'Mostrar contraseña',ocultar:'Ocultar contraseña',...(o.textos||{})};
  const {m,cerrar}=dialogo(`<form class="mbox mclave" role="dialog" aria-modal="true" aria-labelledby="mc-t" novalidate>
      <h3 id="mc-t">${o.titulo}</h3><p>${o.mensaje}</p>
      <div class="mc-campo"><label class="vh" for="mc-clave">Contraseña</label>
        <input id="mc-clave" type="password" autocomplete="current-password" maxlength="40" placeholder="Contraseña" aria-describedby="mc-err">
        <button type="button" class="mc-ojo" data-m="ojo" aria-label="${T.ver}" aria-pressed="false">${ic('eye',18)}</button></div>
      <p class="mc-err" id="mc-err" role="alert"></p>
      <div class="mrow"><button type="button" class="btn ghost" data-m="no">Cancelar</button><button type="submit" class="btn danger" data-m="yes">${o.boton}</button></div>
    </form>`);
  const f=m.querySelector('form'),inp=m.querySelector('#mc-clave'),err=m.querySelector('#mc-err'),ok=m.querySelector('[data-m="yes"]'),ojo=m.querySelector('[data-m="ojo"]');
  const avisar=t=>{err.textContent=t;f.classList.toggle('mal',!!t);if(t)inp.setAttribute('aria-invalid','true');else inp.removeAttribute('aria-invalid')};
  ojo.addEventListener('mousedown',e=>e.preventDefault()); // no le saca el foco al campo
  ojo.addEventListener('click',()=>{
    const ver=inp.type==='password';inp.type=ver?'text':'password';
    ojo.setAttribute('aria-pressed',ver);ojo.setAttribute('aria-label',ver?T.ocultar:T.ver);ojo.innerHTML=ic(ver?'eyeoff':'eye',18);
  });
  inp.addEventListener('input',()=>{if(err.textContent)avisar('')});
  f.addEventListener('submit',async e=>{
    e.preventDefault();
    if(ok.disabled)return;
    if(!inp.value){avisar(T.vacia);inp.focus();return}
    ok.disabled=true;
    let bien=false;try{bien=await o.verificar(inp.value)}catch(x){bien=false}
    ok.disabled=false;
    if(!bien){
      avisar(T.mal);inp.select();
      f.classList.remove('sacude');void f.offsetWidth;f.classList.add('sacude');
      return;
    }
    cerrar();o.alAceptar();
  });
  inp.focus();
}
