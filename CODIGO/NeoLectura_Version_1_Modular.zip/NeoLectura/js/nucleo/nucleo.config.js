/* =====================  NÚCLEO · CONFIGURACIÓN  =====================
   Valores generales de la app. **Para cambiar cuántos puntos da cada cosa,
   cuántas partes tiene cada nivel o los tamaños de letra, se cambia acá.**
   (Los puntos de la racha están en js/racha/racha.config.js.)            */

/* Tamaños de letra del cuento (Opciones → Tamaño de letra) */
const SIZES=['1.0625rem','1.3rem','1.6rem'],SIZE_NAMES=['Normal','Grande','Muy grande'];

/* Partes que tiene cada nivel (cada cuento se divide en 3) */
const PARTS=3;

/* Puntos */
const PUNTOS={
  parte:50,                  // leer una parte (la primera vez)
  respuesta:100,             // cada respuesta correcta del quiz (solo las que superan tu mejor resultado)
  nivel:150,                 // bono por aprobar un nivel por primera vez
  estrellas:[200,600,1200]   // puntos para tener 1, 2 y 3 estrellas
};
