/* =====================  NÚCLEO · ESTADO  =====================
   El progreso del usuario que tiene la sesión abierta (S) y en qué pantalla está (R).
   - S se guarda en el navegador (localStorage) con save(): cada cuenta tiene el suyo
     ("neolectura.v1:<usuario>"; el invitado usa "neolectura.v1").
   - R = la pantalla actual: {s:'home'}, {s:'levels',sid}, {s:'read',sid,l,p}, {s:'quiz',sid,l}…
   - Q = el quiz que se está respondiendo (lo maneja js/quiz/quiz.logic.js).
   Abajo están las preguntas sobre el progreso (¿se leyó esta parte?, ¿está desbloqueado?…). */
const KEY_BASE='neolectura.v1';
let KEY=KEY_BASE; // cambia según quién inicia sesión (ver useProfile)
// Las cuentas nuevas (y el invitado) empiezan con 0 puntos.
// Audiolibro: vol = volumen (0 a 1) · voz = personaje elegido ('personaje:librina'…; '' = el primero, Librín) · ritmo = 'lenta', 'normal' o 'rapida'
const DEF={name:'Valentín',points:0,parts:{},quiz:{},done:{},size:0,voice:true,vol:1,voz:'',ritmo:'normal',theme:'auto'};
function load(){try{const r=localStorage.getItem(KEY);return r?JSON.parse(r):null}catch(e){return null}}
function save(){
  try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}
  if(typeof Ranking!=='undefined')Ranking.anotar(); // anota los puntos de la cuenta en el ranking (js/ranking)
}
// Copia nueva de los valores por defecto (para que dos usuarios no compartan los mismos objetos)
const blank=()=>Object.assign({},DEF,{parts:{},quiz:{},done:{}});
let S=Object.assign(blank(),load()||{});
let R={s:'home'},Q=null;

/* Carga el progreso de un usuario (null = invitado, usa la clave de siempre).
   Devuelve true si ese usuario ya tenía datos guardados. Lo usa js/login. */
function useProfile(user){
  KEY=user?KEY_BASE+':'+user:KEY_BASE;
  const d=load();
  S=Object.assign(blank(),d||{});
  return !!d;
}

/* Borra el progreso (puntos, partes leídas, quizzes, niveles y racha). Se mantienen el
   nombre, el personaje y las preferencias. Lo usa Opciones → Reiniciar progreso. */
function reiniciarProgreso(){
  S.points=DEF.points;S.parts={};S.quiz={};S.done={};
  if(typeof Racha!=='undefined')Racha.reiniciar();
  save();
}

/* ---------- Preguntas sobre el progreso ---------- */
const story=id=>STORIES.find(s=>s.id===id);
const kd=(sid,l)=>sid+':'+l, kp=(sid,l,p)=>sid+':'+l+':'+p; // claves de "nivel aprobado" y "parte leída"
const doneCount=sid=>story(sid).levels.filter((_,i)=>S.done[kd(sid,i)]).length;
const totalDone=()=>STORIES.filter(s=>s.open).reduce((a,s)=>a+doneCount(s.id),0);
/* Un nivel se puede leer si se aprobó el anterior. El primer nivel de cada cuento
   depende del cuento anterior del camino (js/cuentos/cuentos.camino.js) */
const unlocked=(sid,l)=>l>0?!!S.done[kd(sid,l-1)]:Camino.desbloqueado(sid);
const partsRead=(sid,l)=>{let n=0;for(let p=0;p<PARTS;p++)if(S.parts[kp(sid,l,p)])n++;return n};
const starCount=()=>PUNTOS.estrellas.filter(x=>S.points>=x).length;
const started=sid=>Object.keys(S.parts).some(k=>k.indexOf(sid+':')===0);
