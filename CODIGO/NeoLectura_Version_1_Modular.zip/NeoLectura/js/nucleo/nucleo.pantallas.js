/* =====================  NÚCLEO · PANTALLAS Y ACCIONES  =====================
   Cada pantalla vive en su propia carpeta (js/inicio, js/niveles, js/lectura, js/quiz,
   js/ranking, js/opciones, js/creditos) y se anota acá con:

     Pantallas.registrar('levels', {
       html:      r => '...',        // el HTML de la pantalla (r = la ruta: {s, sid, l, p})
       entrar:    r => true/false,   // (opcional) antes de ir: false = no se puede entrar
       permitida: r => true/false,   // (opcional) al dibujar: false = se va al inicio
       atras:     r => otraRuta      // (opcional) a dónde va con el botón "atrás" del navegador
     });

   Los botones con data-a="algo" hacen la acción anotada con
     Pantallas.accion('algo', (datos, boton) => { ... });     // datos = boton.dataset
   (data-a="nav" con data-to="..." va a otra pantalla: eso lo hace nucleo.router.js).
   Así, para agregar una pantalla nueva no hace falta tocar el núcleo.            */
const Pantallas=(()=>{
  const lista={},acciones={};
  function registrar(id,o){
    lista[id]=Object.assign({entrar:()=>true,permitida:()=>true,atras:null},o);
  }
  const buscar=id=>lista[id]||null;
  function accion(nombre,fn){acciones[nombre]=fn}
  function hacer(nombre,datos,el){
    if(!acciones[nombre])return false;
    acciones[nombre](datos,el);return true;
  }
  return {registrar,buscar,accion,hacer,ids:()=>Object.keys(lista),acciones:()=>Object.keys(acciones)};
})();

/* Encabezado azul con el botón "Volver" (lo usan todas las pantallas menos el inicio) */
const bar=(title,back)=>`<header class="hdr bar"><button class="back" data-a="nav" data-to="${back}">${ic('back',16)} Volver</button><h2>${ESC(title)}</h2><span></span></header>`;
