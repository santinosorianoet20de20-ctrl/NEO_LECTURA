/* =====================  OPCIONES · CONTROLADOR  =====================
   - Tamaño de letra, lectura en voz alta y tema: se guardan y se ve el cambio enseguida.
   - Tu nombre: solo se guarda si es un nombre permitido (js/filtro); si no, se avisa debajo.
   - Reiniciar progreso: pide la contraseña de la cuenta (el invitado no tiene: solo confirma). */
const Opciones=(()=>{
  const T=OPCIONES_CFG.textos;

  Pantallas.accion('size',d=>{S.size=+d.i;save();render()});
  Pantallas.accion('voice',()=>{S.voice=!S.voice;save();render()});
  Pantallas.accion('theme',d=>{S.theme=d.v;save();render()});

  /* ---------- Reiniciar progreso ---------- */
  function borrar(){reiniciarProgreso();toast(T.hecho);render()}
  Pantallas.accion('reset',()=>{
    if(!Login.usuario()){ask(T.invitadoMsg,T.reiniciar,borrar);return} // invitado: no tiene contraseña
    pedirClave({titulo:T.claveTitulo,mensaje:T.claveMsg,boton:T.claveBoton,verificar:Login.verificarClave,alAceptar:borrar});
  });

  /* ---------- Tu nombre ---------- */
  const nombreLimpio=v=>String(v||'').trim().replace(/\s+/g,' ');
  function avisoNombre(input,err){
    const m=document.getElementById('setname-msg');
    if(m){m.textContent=err||'';m.hidden=!err}
    if(err)input.setAttribute('aria-invalid','true');else input.removeAttribute('aria-invalid');
  }
  document.addEventListener('input',e=>{
    if(e.target.id!=='setname')return;
    const v=nombreLimpio(e.target.value),err=LoginValidar.nombre(v);
    avisoNombre(e.target,err);
    if(!err&&v!==S.name){S.name=v;save()}
  });
  // Al salir del campo con un nombre no permitido, vuelve el último que estaba bien
  document.addEventListener('focusout',e=>{
    if(e.target.id!=='setname'||!LoginValidar.nombre(nombreLimpio(e.target.value)))return;
    e.target.value=Filtro.mostrar(S.name);avisoNombre(e.target,'');
  });

  return {borrar};
})();
