/* =====================  OPCIONES · CONFIGURACIÓN  =====================
   Textos de la pantalla de Opciones. **Para cambiar un texto, se cambia acá.**
   (Los tamaños de letra están en js/nucleo/nucleo.config.js; las voces y la
   velocidad, en js/audio y js/personajes.)                                 */
const OPCIONES_CFG={
  temas:[['auto','Automático'],['light','Claro'],['dark','Oscuro']],
  textos:{
    titulo:'Opciones',
    subtitulo:'Ajusta NeoLectura a tu gusto',
    nombre:'Tu nombre',
    nombreDet:'Aparece en la pantalla principal y en el ranking. Para entrar sigues usando tu usuario.',
    letra:'Tamaño de letra',
    letraDet:'Cambia el tamaño del texto de los cuentos.',
    letraPrueba:'Así se verá el texto del cuento.',
    voz:'Lectura en voz alta',
    vozDet:'Muestra el reproductor de audio en cada parte del cuento.',
    tema:'Tema',
    temaDet:'El modo Claro es el diseño original.',
    progreso:'Progreso',
    progresoDet:'Borra tus puntos, niveles y racha para empezar de nuevo. Para hacerlo te vamos a pedir tu contraseña.',
    progresoDetInvitado:'Borra tus puntos, niveles y racha para empezar de nuevo.',
    reiniciar:'Reiniciar progreso',
    // Diálogo de la contraseña
    claveTitulo:'¿Borrar tu progreso?',
    claveMsg:'Se borran tus puntos, niveles y racha, y no se pueden recuperar. Para confirmar, escribe tu contraseña.',
    claveBoton:'Borrar progreso',
    // El invitado no tiene contraseña: solo confirma
    invitadoMsg:'¿Seguro que quieres borrar tus puntos, niveles y racha? No se pueden recuperar.',
    hecho:'Progreso reiniciado'
  }
};
