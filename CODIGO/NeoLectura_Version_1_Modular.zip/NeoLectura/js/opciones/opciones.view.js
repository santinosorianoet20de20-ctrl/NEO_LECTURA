/* =====================  OPCIONES · VISTA  =====================
   La pantalla de Opciones: nombre, tamaño de letra, lectura en voz alta (con el
   personaje y la velocidad, de js/audio), tema y reiniciar el progreso.
   Ruta: {s:'settings'}. Los estilos están en css/opciones.css.               */
const OpcionesVista=(()=>{
  const C=OPCIONES_CFG,T=C.textos;
  function pantalla(){
    const invitado=!Login.usuario();
    return bar(T.titulo,'home')+`<main><div class="doc">
      <section class="mcard"><span style="color:var(--blue)">${ic('gear',44)}</span><div><div class="mt">${T.titulo}</div><div class="ms">${T.subtitulo}</div></div></section>
      <section class="set"><h4>${T.nombre}</h4><p>${T.nombreDet}</p><input id="setname" class="inp" maxlength="14" value="${ESC(Filtro.mostrar(S.name))}" autocomplete="off" aria-label="${T.nombre}" aria-describedby="setname-msg"><p class="set-err" id="setname-msg" aria-live="polite" hidden></p></section>
      <section class="set"><h4>${T.letra}</h4><p>${T.letraDet}</p>
        <div class="chips">${SIZE_NAMES.map((n,i)=>`<button class="chip ${S.size===i?'on':''}" data-a="size" data-i="${i}">${n}</button>`).join('')}</div>
        <p class="prev" style="font-size:var(--fs)">${T.letraPrueba}</p></section>
      <section class="set two"><div><h4>${T.voz}</h4><p>${T.vozDet}</p></div>
        <button class="sw ${S.voice?'on':''}" data-a="voice" role="switch" aria-checked="${S.voice}" aria-label="${T.voz}"></button></section>
      ${canSpeak&&S.voice?AudioVista.opcionesVoz()+AudioVista.opciones():''}
      <section class="set"><h4>${T.tema}</h4><p>${T.temaDet}</p>
        <div class="chips">${C.temas.map(([v,n])=>`<button class="chip ${S.theme===v?'on':''}" data-a="theme" data-v="${v}">${n}</button>`).join('')}</div></section>
      <section class="set"><h4>${T.progreso}</h4><p>${invitado?T.progresoDetInvitado:T.progresoDet}</p><button class="btn danger" data-a="reset" style="margin-top:12px">${T.reiniciar}</button></section>
    </div></main>`;
  }

  Pantallas.registrar('settings',{html:pantalla});
  return {pantalla};
})();
