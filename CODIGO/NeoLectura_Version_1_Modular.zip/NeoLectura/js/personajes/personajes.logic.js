/* =====================  PERSONAJES · MASCOTA  =====================
   La mascota es el personaje cuya voz eligió el usuario (en Opciones o en el reproductor):
   Librín, Librina, Librón o Librona (los datos están en personajes.config.js).
   Si no eligió ninguno (o eligió uno que ya no existe), es el primero de la lista (Librín).
   - MASCOTA()                    → el personaje de ahora.
   - MASCOTA_RUTA('triste')       → la imagen de esa reacción (con sus "cambios" de cara).
   - MASCOTA_IMG('saludo', 88)    → la imagen chica de las tarjetas (inicio, niveles, créditos, ranking).
   - CON_GENERO('orgullos{o}')    → "orgulloso" o "orgullosa" según el personaje.
   Las reacciones (una imagen por reacción, todas de 513×508) están listadas en
   js/companero/companero.config.js.                                                       */
const MASCOTAS=Object.fromEntries(PERSONAJES.map(p=>[p.id,p]));
const MASCOTA=()=>{
  const v=typeof S!=='undefined'?String(S.voz||''):'';
  return (v.indexOf('personaje:')===0&&PERSONAJE(v.slice(10)))||PERSONAJES[0];
};
const MASCOTA_RUTA=r=>{const m=MASCOTA();return m.carpeta+(m.cambios[r]||r)+'.png'};
const MASCOTA_IMG=(reaccion='saludo',ancho=88)=>`<img class="librin-mini" src="${MASCOTA_RUTA(reaccion)}" alt="" width="${ancho}" height="${Math.round(ancho*508/513)}" draggable="false">`;
const CON_GENERO=t=>String(t).replace(/\{o\}/g,MASCOTA().genero==='f'?'a':'o');
