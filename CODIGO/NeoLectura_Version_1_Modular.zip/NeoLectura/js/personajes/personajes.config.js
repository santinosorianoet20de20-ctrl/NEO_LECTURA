/* =====================  PERSONAJES  =====================
   Los personajes de NeoLectura. Cada uno es, a la vez:
   - una VOZ del audiolibro (se elige en Opciones o en el reproductor del cuento), y
   - la MASCOTA que acompaña la lectura, el quiz y las tarjetas: el personaje cuya
     voz elegiste es el que aparece (lo decide MASCOTA() de personajes.logic.js).

   **Para agregar un personaje nuevo:**
   1. Crear la carpeta img/<id>/ con sus 21 reacciones: los mismos nombres de archivo
      que img/librin/ (saludo.png, bien.png, triste.png…), todas de 513×508 y con el
      libro del mismo tamaño y en el mismo lugar que en las de Librín.
   2. Agregar un renglón abajo, copiando uno parecido.
   Con eso ya aparece en Opciones, en el panel de voces del cuento y como mascota.

   Qué es cada dato:
   - id:      nombre de la carpeta de imágenes (img/<id>/). No cambiarlo después de publicar:
              es lo que queda guardado en la cuenta de cada usuario.
   - nombre:  como se muestra (con tildes).
   - genero:  'm' o 'f'. Sirve para los textos que cambian: "orgulloso" / "orgullosa"
              (en los textos se escribe "orgullos{o}", ver js/companero/companero.config.js).
   - emoji:   por si la imagen no carga.
   - base:    sobre qué voz del equipo se arma su voz: 'f' = de mujer, 'm' = de hombre.
   - tono:    1 = normal (0 a 2). Más alto = más aguda; más bajo = más grave. Algunas voces ignoran el tono.
   - tonoSinBase: el tono a usar si el equipo NO tiene una voz de ese tipo (por ejemplo, un equipo
              que solo tiene voces de mujer): así los cuatro personajes igual suenan distintos.
   - vel:     velocidad propia (1 = normal). Se multiplica por la velocidad elegida (Lenta / Normal / Rápida).
   - det:     cómo suena (se lee debajo del nombre, en la lista de voces).
   - saludo:  lo que dice al elegirlo o al tocar "Probar".
   - color:   color de su nombre en el globito [modo claro, modo oscuro] (mejor si combina con su tapa).
   - cambios: si le falta una cara con cierto sentimiento, cuál usa en su lugar ({'cara':'otra'}).
   - antes:   ids viejos que tuvo (para las cuentas que lo eligieron con ese nombre).
   - foto:    (opcional) dónde cae la cara en la foto de perfil redonda de la lista de voces:
              {x:'-42%', y:'-22%'} es lo normal; y más negativo = la foto baja (para ver más abajo la cara).
   Se muestran en este orden. El primero es el que se usa si no se eligió ninguno.

   Las voces: Librín es un chico y Librina una chica (agudas y rápidas, sobre voces distintas: de hombre
   y de mujer, así no suenan iguales), y Librón es un señor y Librona una señora (graves y lentos).
   Para que suene más joven: más tono y más velocidad. Más mayor: menos tono y menos velocidad.      */
const PERSONAJES=[
  // Chico: voz de hombre bien aguda y un poco rápida
  {id:'librin', nombre:'Librín', genero:'m', emoji:'📘',
   base:'m', tono:1.6, tonoSinBase:1.15, vel:1.08, det:'Voz de chico, alegre',
   saludo:'¡Hola, hola! Soy Librín. ¡Vamos a leer juntos!',
   color:['#12787A','#7EE3E3']},

  // Chica: voz de mujer muy aguda y rápida (de nena)
  {id:'librina', nombre:'Librina', genero:'f', emoji:'🎀',
   base:'f', tono:1.8, tonoSinBase:2, vel:1.12, det:'Voz de chica, dulce',
   saludo:'¡Hola! Soy Librina. ¡Qué lindo que vengas a leer conmigo!',
   color:['#B4236A','#FF9CCB']},

  // Señor: voz de hombre grave y tranquila.
  // No tiene cara preocupada (su 'no-te-rindas' sonríe): al errar en el quiz pone la de la nube
  {id:'libron', nombre:'Librón', genero:'m', emoji:'📚',
   base:'m', tono:.7, tonoSinBase:.3, vel:.88, det:'Voz de señor, tranquila',
   saludo:'Hola, soy Librón. Ponte cómodo, que empieza el cuento.',
   color:['#B3261E','#FF9A8F'], cambios:{'no-te-rindas':'nublado'}, antes:['gigante']},

  // Señora: voz de mujer grave y lenta (de abuela).
  // Su cara está más abajo que la de los demás (por el pelo): la foto de perfil baja un poco
  {id:'librona', nombre:'Librona', genero:'f', emoji:'👵',
   base:'f', tono:.55, tonoSinBase:1, vel:.8, det:'Voz de señora, pausada',
   saludo:'¡Hola, tesoro! Soy Librona. Acomódate, que te leo un cuento.',
   color:['#6E2AA8','#CFA6FF'], foto:{x:'-40%',y:'-43%'}}
];
/* Datos que se completan solos (no hace falta escribirlos arriba) */
PERSONAJES.forEach(p=>{
  p.carpeta=p.carpeta||`img/${p.id}/`;
  p.img=p.carpeta+'saludo.png';
  p.cambios=p.cambios||{};
  p.antes=p.antes||[];
});
/* Busca un personaje por su id (o por un id viejo). null si no existe. */
const PERSONAJE=id=>PERSONAJES.find(p=>p.id===id)||PERSONAJES.find(p=>p.antes.includes(id))||null;
