/* =====================  QUIZ · CONTROLADOR  =====================
   - Tocar una opción: se marca si está bien o mal (y la mascota reacciona).
   - "Siguiente" / "Ver resultado": pasa de pregunta o termina el quiz. Si con este
     quiz se completó la racha del día, después de las estrellas aparece el aviso (js/racha). */
Pantallas.accion('pick',d=>{
  if(!Q||Q.pick!=null)return;
  Quiz.responder(+d.i);render();
});

Pantallas.accion('qnext',()=>{
  if(!Q)return;
  Quiz.siguiente();
  render();window.scrollTo(0,0);
  // después de las estrellas (se guarda antes: si reintenta rápido, Q ya es otro)
  if(Q.end&&Q.res.racha){const rc=Q.res.racha;setTimeout(()=>RachaControl.avisar(rc),900)}
});
