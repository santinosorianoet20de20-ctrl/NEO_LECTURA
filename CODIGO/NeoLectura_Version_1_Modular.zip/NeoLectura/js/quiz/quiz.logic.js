/* =====================  QUIZ · LÓGICA  =====================
   El quiz que se está respondiendo está en Q (js/nucleo/nucleo.estado.js):
   Q = {sid, l, i: pregunta actual, score: correctas, pick: opción elegida (null = sin responder),
        end: terminó, res: resultado}
   Puntos (PUNTOS en nucleo.config.js): cada correcta que supera tu mejor resultado, el bono por
   aprobar el nivel la primera vez, y el de la racha si es el primer quiz aprobado del día. */
const Quiz=(()=>{
  const nivel=()=>story(Q.sid).levels[Q.l];

  /* Empieza un quiz. Devuelve false si todavía no se puede (con el motivo para avisar) */
  function empezar(r){
    if(!unlocked(r.sid,r.l))return {ok:false};
    if(partsRead(r.sid,r.l)<PARTS)return {ok:false,motivo:'partes'};
    Q={sid:r.sid,l:r.l,i:0,score:0,pick:null,end:false};
    return {ok:true};
  }

  /* Elige una opción de la pregunta actual (una sola vez por pregunta) */
  function responder(k){
    if(!Q||Q.pick!=null)return;
    Q.pick=k;if(k===nivel().quiz[Q.i].a)Q.score++;
  }

  /* Pasa a la pregunta siguiente, o termina */
  function siguiente(){
    if(Q.i+1<nivel().quiz.length){Q.i++;Q.pick=null}
    else terminar();
  }

  function terminar(){
    const s=story(Q.sid),L=nivel(),n=L.quiz.length,k=kd(Q.sid,Q.l);
    const prev=S.quiz[k]||0,delta=Math.max(0,Q.score-prev)*PUNTOS.respuesta;
    // Cada cuento dice cuántas correctas hacen falta (más difícil en los niveles más largos)
    const pass=Q.score>=(L.aprobar||Math.ceil(n/2)),nuevo=pass&&!S.done[k],bonus=nuevo?PUNTOS.nivel:0;
    S.quiz[k]=Math.max(prev,Q.score);
    if(pass)S.done[k]=true;
    // Si es la primera vez que se aprueba el último nivel del cuento, se desbloquea el cuento que sigue
    const abre=nuevo&&Q.l===s.levels.length-1?Camino.siguiente(Q.sid):null;
    const racha=pass?Racha.completarHoy():null; // primer quiz aprobado del día → +1 día de racha (js/racha)
    S.points+=delta+bonus+(racha?racha.bonus:0);save();
    Q.end=true;Q.res={delta,bonus,pass,racha,abre};
  }

  return {empezar,responder,siguiente,terminar};
})();
