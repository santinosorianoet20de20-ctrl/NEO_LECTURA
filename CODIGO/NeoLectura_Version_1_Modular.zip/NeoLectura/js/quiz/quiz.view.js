/* =====================  QUIZ · VISTA  =====================
   La pantalla del quiz: una pregunta por vez (con la parte de la que es), las opciones
   A, B, C…, la mascota que reacciona (js/companero) y, al final, las estrellas, los puntos
   ganados y los botones para seguir.
   Ruta: {s:'quiz', sid, l}. Solo se entra si ya se leyeron las 3 partes del nivel.
   Los estilos están en css/quiz.css.                                                  */
const QuizVista=(()=>{
  function resultado(head,s,L,n){
    const r=Q.res,sig=Q.l<s.levels.length-1?null:Camino.siguiente(Q.sid),lastLv=Q.l===s.levels.length-1&&!sig;
    const msg=[`Acertaste ${Q.score} de ${n}.`];
    if(!r.pass)msg.push(`Para aprobar necesitas ${L.aprobar} correctas.`);
    if(r.delta)msg.push(`Ganaste +${fmt(r.delta)} puntos.`);
    if(r.bonus)msg.push(`Bono por completar el nivel: +${r.bonus}.`);
    if(r.racha)msg.push(`🔥 Racha de ${r.racha.dias} ${r.racha.dias===1?'día':'días'}: +${r.racha.bonus} puntos.`);
    const abre=r.abre?`<p class="res-abre">🔓 ¡Desbloqueaste el ${Camino.etiqueta(r.abre.id)}: <b>${ESC(r.abre.title)}</b>!</p>`:'';
    // "Repasa…" y "¡Terminaste…!" los dice la mascota (js/companero)
    // "Volver al menú" está siempre (va a la pantalla principal, con todos los cuentos)
    const menu=pri=>`<button class="btn ${pri?'pri':'ghost'}" data-a="nav" data-to="home">${ic('casa',18)} Volver al menú</button>`;
    const destino=sig?`read:${sig.id}:0:0`:`read:${Q.sid}:${Q.l+1}:0`;
    const btns=r.pass
      ?(lastLv?`<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Ver el cuento</button>${menu(true)}`
              :`${menu()}<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Ver el cuento</button><button class="btn pri" data-a="nav" data-to="${destino}">Siguiente nivel ${ic('right',16)}</button>`)
      :`${menu()}<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Repasar</button><button class="btn pri" data-a="nav" data-to="quiz:${Q.sid}:${Q.l}">Reintentar</button>`;
    const tam=n<=5?48:n<=8?36:30; // con más preguntas, estrellas más chicas
    return head+`<main><div class="doc"><div class="paper"><div class="in center" style="padding-top:28px">
      <div class="bigstars">${Array.from({length:n},(_,i)=>`<span class="${i<Q.score?'on':''}">${ic('star',tam,true)}</span>`).join('')}</div>
      <h2>${r.pass?'¡Nivel completado!':'¡Casi lo logras!'}</h2>
      ${CompaneroVista.quizResultado(r.pass,Q.score===n,lastLv,Q.score===0)}
      ${abre}<p class="res-txt">${msg.join(' ')}</p><div class="res-btns">${btns}</div></div></div></div></main>`;
  }

  function pantalla(){
    const s=story(Q.sid),L=s.levels[Q.l],n=L.quiz.length;
    const head=bar('Quiz · '+Camino.etiqueta(Q.sid,Q.l),'levels:'+Q.sid);
    if(Q.end)return resultado(head,s,L,n);
    const q=L.quiz[Q.i],pk=Q.pick;
    const opts=q.o.map((t,k)=>{let c='opt';if(pk!=null){if(k===q.a)c+=' ok';else if(k===pk)c+=' bad'}
      return `<button class="${c}" data-a="pick" data-i="${k}" ${pk!=null?'disabled':''}><span class="k">${'ABCDEF'[k]}</span>${ESC(t)}</button>`}).join('');
    // La mascota da ánimo antes de responder y reacciona a la respuesta (js/companero)
    const fb=pk==null?CompaneroVista.quizPregunta(Q.i,n,L.name):CompaneroVista.quizRespuesta(pk===q.a,Q.i,n,Q.score,q.o[q.a]);
    return head+`<main><div class="doc"><div class="paper"><div class="in">
      <div class="meta">Pregunta ${Q.i+1} de ${n}${q.parte?` · Sobre la parte ${q.parte}`:''}</div>
      <div class="pbar"><i style="width:${(Q.i+(pk!=null?1:0))/n*100}%"></i></div>
      <div class="qq">${ESC(q.q)}</div>${opts}${fb}
      ${pk!=null?`<div class="nav"><span></span><button class="btn pri" data-a="qnext">${Q.i+1<n?'Siguiente':'Ver resultado'} ${ic('right',16)}</button></div>`:''}
      </div></div></div></main>`;
  }

  Pantallas.registrar('quiz',{
    html:pantalla,
    entrar:r=>{
      const e=Quiz.empezar(r);
      if(e.motivo==='partes')toast(`Primero lee las ${PARTS} partes del nivel 📖`);
      return e.ok;
    },
    permitida:()=>!!Q,
    atras:r=>({s:'levels',sid:r.sid}) // con el "atrás" del navegador no se vuelve a un quiz a medias
  });
  return {pantalla};
})();
