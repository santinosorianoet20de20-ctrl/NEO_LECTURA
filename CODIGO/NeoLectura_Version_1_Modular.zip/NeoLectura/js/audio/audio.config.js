/* =====================  AUDIOLIBRO · CONFIGURACIÓN  =====================
   Reproductor de la pantalla de lectura: Escuchar / Pausar / Reanudar,
   Reiniciar, retroceder y adelantar unos segundos, volumen, voz y velocidad.
   Mientras suena, el texto se va pintando de azul palabra por palabra.
   Usa la voz del navegador (Web Speech API), así que no hacen falta
   archivos de audio: cualquier cuento nuevo ya se puede escuchar.
   Las voces son solo las de los personajes (Librín, Librina, Librón, Librona…):
   **cómo suena cada uno se cambia en js/personajes/personajes.config.js**.
   Acá se cambian los saltos, las velocidades y los textos del reproductor. */
const AUDIO_CFG={
  salto:5,              // segundos que retroceden / adelantan los botones
  velocidad:.9,         // velocidad de la voz (1 = normal). Era la que ya usaba la app
  idioma:'es-AR',       // idioma pedido a la voz si no se encuentra una en español
  volumenInicial:1,     // volumen de las cuentas nuevas (0 a 1)

  /* Personajes: voces propias armadas sobre una voz del equipo, cambiándole el tono.
     Están en js/personajes/personajes.config.js (son los mismos que la mascota). */
  personajes:PERSONAJES,

  /* Velocidad de lectura (sirve para cualquier personaje). Se muestran en este orden.
     "ritmoPorDefecto" es la de las cuentas nuevas (y la que se usa si se borra la elegida). */
  ritmos:[
    {id:'lenta', nombre:'Lenta', emoji:'🐢',vel:.75}, // 25% más lenta (con 20% casi no se notaba en algunas voces)
    {id:'normal',nombre:'Normal',emoji:'🙂',vel:1},
    {id:'rapida',nombre:'Rápida',emoji:'🐇',vel:1.3}  // 30% más rápida
  ],
  ritmoPorDefecto:'normal',

  /* Países en el orden en que se prefieren las voces sobre las que se arman los personajes
     (los que no están van antes de España) */
  paises:['ar','uy','419','mx','us','co','cl','pe','py','bo','ve','ec','cr','pa','gt','hn','sv','ni','do','cu','pr','gq','es'],

  /* Cosas técnicas (no hace falta tocarlas) */
  letrasPorSegundo:15,  // estimación inicial a velocidad 1; después se ajusta sola con la voz real
  medidas:'neolectura.audio.medidas', // donde se guarda (en el navegador) lo rápido que habla cada voz en cada velocidad
  pesoPausa:3,          // una coma "dura" como 3 letras más (la voz hace una pausita)
  pausas:/[,;:—–]/,     // signos donde la voz hace esa pausita
  maxLetras:160,        // las frases más largas se cortan en dos (Chrome corta algunas voces a los ~15 s)
  pausaCancelar:60,     // ms entre cancelar la voz y volver a hablar (evita que Chrome se trabe)
  esperaVolumen:350,    // ms que espera después de mover el volumen para aplicarlo a la voz
  cadaMs:100,           // cada cuánto se actualizan la barra y el texto pintado mientras suena
  ticsSinVoz:12,        // 12 × 100 ms sin voz → la frase se da por terminada (por si el navegador no avisa)

  textos:{
    titulo:'Audiolibro',
    escuchar:'Escuchar',
    pausar:'Pausar',
    reanudar:'Reanudar',
    otraVez:'Otra vez',
    reiniciar:'Reiniciar desde el principio',
    atras:n=>`Retroceder ${n} segundos`,
    adelante:n=>`Adelantar ${n} segundos`,
    avance:'Avance del audio',
    tiempo:(a,b)=>`${a} de ${b}`,
    volumen:'Volumen',
    silenciar:'Silenciar',
    activar:'Activar sonido',
    probar:'Probar',
    error:'No se pudo reproducir el audio 😕',

    /* Personajes y velocidad */
    elegirVoz:n=>`Elegir voz (ahora: ${n})`,
    panelTitulo:'Voz del audiolibro',
    personaje:'Personaje',
    personajes:'Personajes',
    velocidad:'Velocidad',
    sinVoces:'Este equipo no tiene voces en español instaladas, así que los personajes usan la voz que venga por defecto.',
    cerrar:'Cerrar',
    sinVelocidad:'En este navegador, esta voz no cambia de velocidad. Prueba con otro personaje o abre NeoLectura en otro navegador (Chrome o Edge).',
    saludo:'¡Hola! Así voy a leer los cuentos.',
    opcionesTitulo:'Personaje y voz',
    opcionesDet:'Elige quién te lee los cuentos. Tu personaje también te acompaña en la lectura y en los quizzes, y lo puedes cambiar en cualquier cuento.',
    opcionesVel:'Sirve para todos los personajes.'
  }
};
