/* =====================  AUDIOLIBRO · VOCES  =====================
   Las voces que se pueden elegir son solo las de los PERSONAJES (Librín, Librina,
   Librón, Librona…, en js/personajes/personajes.config.js). Cada personaje se arma sobre
   una voz en español de este equipo (de mujer o de hombre, según su "base"),
   cambiándole el tono y la velocidad.

   Las voces del equipo NO vienen con NeoLectura: las pone el navegador o el sistema.
   Por eso se arma la lista de las que hay, se adivina si son de mujer o de hombre
   por el nombre (Elena, Tomás…) y se elige la mejor para cada personaje:
   una instalada (las de internet a veces ignoran el tono) del país preferido.
   Esa lista ya no se muestra: es solo para elegir la voz de base.

   Se guarda en cada usuario: S.voz ('personaje:librin', 'personaje:librina'…;
   '' = el primer personaje) y S.ritmo ('lenta', 'normal' o 'rapida').        */
const AudioVoces=(()=>{
  const C=AUDIO_CFG;
  const ss=canSpeak?window.speechSynthesis:null;
  let lista=[];          // voces en español, ordenadas de mejor a peor: {id, nombre, pais, genero, natural, local, v}
  let cargadas=false;    // el navegador ya devolvió alguna voz (de cualquier idioma)
  let firma='';          // para saber si la lista cambió de verdad
  const oyentes=[];

  const PAISES={ar:'Argentina',bo:'Bolivia',cl:'Chile',co:'Colombia',cr:'Costa Rica',cu:'Cuba',do:'República Dominicana',
    ec:'Ecuador',es:'España',gq:'Guinea Ecuatorial',gt:'Guatemala',hn:'Honduras',mx:'México',ni:'Nicaragua',pa:'Panamá',
    pe:'Perú',pr:'Puerto Rico',py:'Paraguay',sv:'El Salvador',us:'Estados Unidos',uy:'Uruguay',ve:'Venezuela','419':'Latinoamérica'};

  /* Nombres de voces conocidas (Windows, Edge, Mac, iPhone…) para saber si son de mujer o de hombre */
  const MUJERES=new Set(('elena sofia catalina salome maria belkys ramona andrea elvira ximena teresa marta karla dalia yolanda '+
    'margarita camila karina tania lorena paloma valentina paola helena laura sabina monica paulina angelica francisca soledad '+
    'marisol isabela isabel carmen lucia beatriz candela carlota larissa marina nuria renata abril estrella irene laia lia triana '+
    'vera flo sandy shelley abuela grandma esperanza ana rosa luciana victoria julia sara susana penelope lupe mia jimena alba '+
    'elsa ines lola silvia raquel gabriela daniela fernanda mariana natalia patricia').split(' '));
  const HOMBRES=new Set(('tomas marcelo lorenzo gonzalo juan manuel emilio luis alvaro javier andres carlos jorge federico '+
    'roberto alex victor mario rodrigo alonso mateo sebastian pablo raul diego cecilio gerardo liberto luciano pelayo yago arnau '+
    'dario elias nil saul teo eddy reed rocko abuelo grandpa enrique miguel jose antonio felipe hector ricardo santiago martin '+
    'jaime ivan oscar hugo daniel eduardo fernando francisco gabriel ignacio joaquin julio lucas marcos nicolas rafael sergio '+
    'jordi alberto esteban guillermo xavier jesus ruben ramon').split(' '));
  /* Los nombres de Microsoft vienen sin tilde: "Tomas" → "Tomás" */
  const TILDES={tomas:'Tomás',salome:'Salomé',alvaro:'Álvaro',sebastian:'Sebastián',andres:'Andrés',ramon:'Ramón',raul:'Raúl',
    victor:'Víctor',maria:'María',sofia:'Sofía',lucia:'Lucía',angelica:'Angélica',monica:'Mónica',dario:'Darío',elias:'Elías',
    saul:'Saúl',ines:'Inés',nicolas:'Nicolás',martin:'Martín',joaquin:'Joaquín',hector:'Héctor',ivan:'Iván',oscar:'Óscar',
    jose:'José',ruben:'Rubén',jesus:'Jesús',belen:'Belén'};

  const sinTildes=s=>String(s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase();
  const region=lang=>(String(lang||'').replace(/_/g,'-').split('-')[1]||'').toLowerCase();
  const esEspanol=lang=>/^es([-_]|$)/i.test(String(lang||''));
  function ordenPais(r){const i=C.paises.indexOf(r);return i<0?C.paises.length-1.5:i} // los que no están, antes de España

  /* "Microsoft Elena Online (Natural) - Spanish (Argentina)" → "Elena" */
  function nombreCorto(v){
    const n=String(v.name||'').trim();
    const ms=n.match(/^Microsoft\s+(.+?)(?:\s+Online)?(?:\s+\(Natural\))?\s+-\s/i);
    if(ms)return ms[1].trim();
    if(/^Google\b/i.test(n))return 'Google';
    const limpio=n.replace(/\s*\(.*$/,'').replace(/\s+-\s+.*$/,'').trim();
    // Nombres técnicos (los de Android, por ejemplo "es-us-x-esc-local") no sirven para mostrar
    if(!limpio||limpio.length>22||/^[a-z]{2,3}[-_][a-z0-9]{2,4}\b/i.test(limpio)||/[-_]x[-_]/i.test(limpio))return '';
    return limpio;
  }
  const conTilde=n=>{const k=sinTildes(n);return TILDES[k]||n};

  /* 'f' (mujer), 'm' (hombre) o '' (no se sabe) */
  function genero(corto,completo){
    const c=sinTildes(completo);
    if(/\b(female|mujer|femenin)/.test(c))return 'f';
    if(/\b(male|hombre|masculin)/.test(c))return 'm';
    if(/^google\b/.test(c))return 'f'; // las voces de Google en español son de mujer
    const p=sinTildes(corto).split(/\s+/)[0];
    return MUJERES.has(p)?'f':HOMBRES.has(p)?'m':'';
  }

  function refrescar(){
    if(!ss)return;
    let todas=[];try{todas=ss.getVoices()||[]}catch(e){}
    if(todas.length)cargadas=true;
    const vistas={},nueva=[];
    for(const v of todas){
      if(!esEspanol(v.lang))continue;
      const id=v.voiceURI||v.name;if(!id||vistas[id])continue;vistas[id]=1;
      const r=region(v.lang),corto=nombreCorto(v);
      nueva.push({id,nombre:conTilde(corto),pais:PAISES[r]||'Español',orden:ordenPais(r),genero:genero(corto,v.name),
        natural:/natural|neural|premium|enhanced|mejorad|wavenet/i.test(v.name),local:!!v.localService,v});
    }
    // De mejor a peor: país preferido → natural (suena mejor) → instalada (anda sin internet y avisa por qué palabra va) → nombre
    nueva.sort((a,b)=>a.orden-b.orden||(b.natural-a.natural)||(b.local-a.local)||(a.nombre||'~').localeCompare(b.nombre||'~','es'));
    // Las voces sin nombre lindo se numeran por país: "Voz 1 · México"
    const cuenta={};
    nueva.forEach(x=>{if(!x.nombre){cuenta[x.pais]=(cuenta[x.pais]||0)+1;x.nombre='Voz '+cuenta[x.pais]}});
    lista=nueva;
    const f=lista.map(x=>x.id).join('|')+(cargadas?'+':'');
    if(f!==firma){firma=f;oyentes.forEach(fn=>fn())}
  }

  /* ---------- Personajes ---------- */
  /* La voz de base. Las de internet a veces ignoran el tono, así que se prefiere una instalada:
     1) instalada de ese género · 2) instalada sin género conocido · 3) de ese género · 4) cualquiera instalada · 5) la primera */
  function vozBase(g){
    const pasos=[x=>x.local&&x.genero===g, x=>x.local&&!x.genero, x=>x.genero===g, x=>x.local, ()=>true];
    for(const f of pasos){const v=lista.find(f);if(v)return v}
    return null;
  }
  function personaje(pid){
    const p=PERSONAJE(pid);if(!p)return null;
    const b=vozBase(p.base);
    // Si el equipo no tiene voz del tipo que pide (por ejemplo, Librín pide una de hombre y solo hay de mujer),
    // usa su "tonoSinBase", así igual no suena como otro personaje
    const otra=!!b&&!!b.genero&&b.genero!==p.base&&p.tonoSinBase!=null;
    return {id:'personaje:'+p.id,nombre:p.nombre,personaje:p,genero:p.base,pais:'',v:b?b.v:null,base:b,tono:otra?p.tonoSinBase:p.tono};
  }
  const personajes=()=>C.personajes.map(p=>personaje(p.id));

  /* ---------- Elegida ---------- */
  /* Cuentas de versiones anteriores:
     - estilos Librín/Gigante/Lenta → personaje y velocidad (Gigante ahora se llama Librón);
     - una voz del equipo (antes se podían elegir) → el personaje que más se le parece:
       Librón si era de hombre, Librín si no;
     - un personaje con un id viejo o que ya no existe → el id nuevo, o el primero. */
  function migrar(){
    if(S.estilo!==undefined){
      if(S.estilo==='librin')S.voz='personaje:librin';
      if(S.estilo==='gigante')S.voz='personaje:libron';
      if(S.estilo==='lenta')S.ritmo='lenta';
      delete S.estilo;save();
    }
    const v=String(S.voz||'');
    if(!v)return;
    if(v.indexOf('personaje:')===0){
      const p=PERSONAJE(v.slice(10)),nuevo=p?'personaje:'+p.id:'';
      if(nuevo!==v){S.voz=nuevo;save()}
      return;
    }
    if(!cargadas&&!lista.length)return; // todavía no se sabe si esa voz era de mujer o de hombre
    const x=lista.find(y=>y.id===v);
    S.voz='personaje:'+(x&&x.genero==='m'&&PERSONAJE('libron')?'libron':C.personajes[0].id);save();
  }
  function buscar(id){
    if(!id||id.indexOf('personaje:')!==0)return null;
    return personaje(id.slice(10));
  }
  /* El personaje de ahora: el elegido, o el primero */
  function actual(){
    migrar();
    if(!lista.length)refrescar();
    return buscar(S.voz)||personaje(C.personajes[0].id);
  }
  function ritmo(){
    migrar();
    return C.ritmos.find(r=>r.id===S.ritmo)||C.ritmos.find(r=>r.id===C.ritmoPorDefecto)||C.ritmos[0];
  }

  if(ss){
    refrescar();
    if(ss.addEventListener)ss.addEventListener('voiceschanged',refrescar);else ss.onvoiceschanged=refrescar;
    setTimeout(()=>{cargadas=true;refrescar()},2500); // por si el navegador nunca avisa que cargó las voces
  }

  return {
    lista:()=>lista, cargadas:()=>cargadas,
    buscar, actual, ritmo, personajes, refrescar,
    alCambiar:fn=>{oyentes.push(fn)}
  };
})();
