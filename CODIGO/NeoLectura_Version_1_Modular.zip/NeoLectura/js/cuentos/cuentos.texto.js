/* =====================  CUENTOS · TEXTO  =====================
   Cómo se escribe el texto de las partes y cómo se muestra:
   - {palabra|definición} marca una palabra del vocabulario (la explica la mascota).
     Los cuentos la arman sola a partir de "palabras" (ver cuentos.registro.js).
   - Una línea en blanco ("\n\n") separa párrafos; un "\n" solo es un salto de línea
     (los versos de las moralejas).
   Funciones:
   - plain(t)     → el texto sin marcas (para leer en voz alta).
   - vocab(t)     → el HTML con las palabras del vocabulario como botones.
   - PARRAFOS(h)  → al HTML ya armado le pone los párrafos y los saltos de línea.        */

/* También pega la palabra del vocabulario con el signo que la sigue, así no queda un "." solo al principio de una línea. */
const PARRAFOS=h=>h
  .replace(/(<button class="vocab"[^>]*>(?:(?!<\/button>)[\s\S])*<\/button>)((?:<span class="w[^"]*" data-i="\d+">)?[.,;:!?»…)]+(?:<\/span>)?)/g,'<span class="nw">$1$2</span>')
  .replace(/\s*\n\n\s*/g,'<span class="pp" aria-hidden="true"></span>').replace(/\n/g,'<br>');
const plain=t=>t.replace(/\{([^|}]+)\|[^}]+\}/g,'$1');
const vocab=t=>PARRAFOS(t.replace(/\{([^|}]+)\|([^}]+)\}/g,(m,w,d)=>`<button class="vocab" data-a="def" data-w="${ESC(w)}" data-d="${ESC(d)}">${w}</button>`));
