/* =====================  LECTURA · VISTA  =====================
   La pantalla de una parte del cuento: el dibujo de la escena, el reproductor del
   audiolibro (js/audio), el texto con las palabras del vocabulario, la mascota
   compañera (js/companero) y los botones Anterior / Siguiente (o Ir al Quiz).
   Ruta: {s:'read', sid, l, p}. Solo se abre si el nivel está desbloqueado.
   Los estilos están en css/lectura.css.                                          */
const LecturaVista=(()=>{
  function pantalla(r){
    const s=story(r.sid),L=s.levels[r.l],P=L.parts[r.p];
    const last=r.p===PARTS-1;
    // El dibujo de la escena de esta parte (img/escenas/<cuento>/parte-N; ver js/cuentos/cuentos.camino.js)
    return bar(s.title,'levels:'+r.sid)+`<main><div class="doc"><article class="paper">
      <div class="banner escena"><img src="${P.img||cover(s)}" alt=""></div>
      <div class="in"><div class="meta">${Camino.etiqueta(r.sid,r.l)}: ${ESC(L.name)} · Parte ${r.p+1} de ${PARTS}</div>
      <h2>${ESC(P.t)}</h2>
      ${canSpeak&&S.voice?AudioVista.reproductor(kp(r.sid,r.l,r.p),plain(P.x))+`
      <p class="txt" data-audio-texto>${AudioVista.textoSincronizado(P.x)}</p>`:`<p class="txt">${vocab(P.x)}</p>`}
      ${P.x.indexOf('{')>-1?`<p class="hint">Toca las palabras subrayadas y <span data-cp-nombre>${MASCOTA().nombre}</span> te cuenta qué significan.</p>`:''}
      ${CompaneroVista.lectura(P,r.p,last)}
      <div class="tools"><span></span>
        <div class="dots" aria-hidden="true">${Array.from({length:PARTS},(_,i)=>`<i class="${i===r.p?'on':''}"></i>`).join('')}</div></div>
      <div class="nav">${r.p>0?`<button class="btn ghost" data-a="nav" data-to="read:${r.sid}:${r.l}:${r.p-1}">${ic('back',16)} Anterior</button>`:'<span></span>'}
        <button class="btn ${last?'gold':'pri'}" data-a="next">${last?'Ir al Quiz '+ic('star',18,true):'Siguiente '+ic('right',16)}</button></div>
      </div></article></div></main>`;
  }

  Pantallas.registrar('read',{
    html:pantalla,
    entrar:r=>unlocked(r.sid,r.l),
    permitida:r=>!!story(r.sid)&&!!story(r.sid).levels[r.l]&&unlocked(r.sid,r.l)
  });
  return {pantalla};
})();
