/* =====================  LECTURA · CONTROLADOR  =====================
   - "Siguiente" / "Ir al Quiz": marca la parte como leída (+puntos la primera vez)
     y pasa a la parte que sigue, o al quiz si era la última.
   - Tocar una palabra subrayada: la explica la mascota (js/companero).          */
const Lectura=(()=>{
  /* Marca una parte como leída. La primera vez suma puntos (PUNTOS.parte, en nucleo.config.js) */
  function marcarLeida(sid,l,p){
    const k=kp(sid,l,p);
    if(S.parts[k])return false;
    S.parts[k]=true;S.points+=PUNTOS.parte;save();toast(`+${PUNTOS.parte} puntos ⭐`);
    return true;
  }

  Pantallas.accion('next',()=>{
    marcarLeida(R.sid,R.l,R.p);
    go(R.p<PARTS-1?{s:'read',sid:R.sid,l:R.l,p:R.p+1}:{s:'quiz',sid:R.sid,l:R.l});
  });

  Pantallas.accion('def',d=>{
    if(Companero.definir(d.w,d.d))return; // la explica la mascota (js/companero)
    const b=document.getElementById('def');if(!b)return;
    b.hidden=false;b.innerHTML='<b>'+ESC(d.w)+':</b> '+ESC(d.d);
  });

  return {marcarLeida};
})();
