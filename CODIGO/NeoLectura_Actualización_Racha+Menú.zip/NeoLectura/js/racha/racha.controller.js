/* =====================  RACHA · CONTROLADOR  =====================
   Abre/cierra el detalle de la racha y muestra el aviso de racha completa.
   Las ventanas se agregan al <body> (no a #app), así render() no las borra. */
const RachaControl=(()=>{
  let anterior=null; // elemento que tenía el foco antes de abrir la ventana

  function abrir(html){
    cerrar(true);
    anterior=document.activeElement;
    const tmp=document.createElement('div');tmp.innerHTML=html;
    const m=tmp.firstElementChild;document.body.appendChild(m);
    document.body.classList.add('rc-abierto');
    requestAnimationFrame(()=>m.classList.add('ver'));
    const b=m.querySelector('.rc-btn');if(b)b.focus({preventScroll:true});
    return m;
  }

  function cerrar(rapido){
    const m=document.querySelector('[data-racha-modal]');if(!m)return;
    document.body.classList.remove('rc-abierto');
    if(rapido){m.remove();return}
    m.classList.remove('ver');m.classList.add('chau');
    setTimeout(()=>m.remove(),260);
    if(anterior&&document.body.contains(anterior))anterior.focus({preventScroll:true});
  }

  function detalle(){abrir(RachaVista.detalle())}

  /* Aviso de racha completa: el número sube, se prende el fuego de hoy y salen chispas */
  function avisar(res){
    if(!res)return;
    const m=abrir(RachaVista.aviso(res));
    const n=m.querySelector('.rc-cuenta');
    setTimeout(()=>{if(n){n.textContent=n.dataset.a;n.classList.add('sube')}},650);
    chispas(m.querySelector('.rc-chispas'));
  }

  function chispas(box){
    if(!box)return;
    const colores=['#F7C900','#ED823A','#FFB13B','#E64D49'];
    for(let i=0;i<16;i++){
      const s=document.createElement('i');
      s.style.cssText=`--x:${(Math.random()*160-80).toFixed(0)}px;--y:${(-60-Math.random()*90).toFixed(0)}px;--c:${colores[i%colores.length]};--t:${(.3+Math.random()*.9).toFixed(2)}s;--s:${(5+Math.random()*7).toFixed(0)}px`;
      box.appendChild(s);
    }
  }

  /* Eventos */
  document.addEventListener('click',e=>{
    const t=e.target.closest('[data-racha]');
    if(t){if(t.dataset.racha==='abrir')detalle();else if(t.dataset.racha==='cerrar')cerrar();return}
    if(e.target.matches&&e.target.matches('[data-racha-modal]'))cerrar(); // clic afuera de la ventana
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&document.querySelector('[data-racha-modal]'))cerrar();
  });

  return {avisar,detalle,cerrar};
})();
