/* =====================  RACHA · CONFIGURACIÓN  =====================
   Racha diaria de lectura (como la de Duolingo):
   - Aprobar el primer quiz del día suma 1 día de racha.
   - Si un día no se aprueba ningún quiz, la racha se apaga y vuelve a empezar.
   - Cada día de racha da puntos extra: día 1 = +5, día 2 = +10, día 3 = +15…
     hasta un tope, para que no desbalancee el sistema de puntos
     (como referencia: leer una parte da +50 y cada respuesta correcta +100). */
const RACHA_CFG={
  puntosPorDia:5,   // puntos extra por cada día de racha
  tope:100,         // máximo de puntos extra por día (se llega al día 20)
  historialMax:60,  // cuántos días se recuerdan para el calendario

  img:{encendido:'img/racha/fuego.svg',apagado:'img/racha/fuego-apagado.svg'},

  dias:['D','L','M','M','J','V','S'], // iniciales de domingo a sábado
  diasLargos:['domingo','lunes','martes','miércoles','jueves','viernes','sábado'],

  textos:{
    unidad:n=>n===1?'día de racha':'días de racha',
    hecha:'¡Hoy ya leíste! ✓',
    pendiente:'¡Aprueba un quiz hoy!',
    apagada:'¡Empieza tu racha hoy!',
    detHecha:'¡Muy bien! Tu racha de hoy está completa. Vuelve mañana para seguir sumando.',
    detPendiente:'Aprueba un quiz hoy para que tu racha no se apague. 🔥',
    detApagada:'Tu racha se apagó. ¡Aprueba un quiz hoy y empieza una nueva!',
    detNueva:'Aprueba un quiz hoy para encender tu primera racha. 🔥',
    comoFunciona:'Aprueba al menos un quiz por día. Cada día de racha te da 5 puntos extra más que el anterior (día 1: +5, día 2: +10, día 3: +15…).',
    avisoTitulo:'¡Racha completa!',
    avisoNueva:'¡Encendiste tu racha! Vuelve mañana para que siga creciendo.',
    avisoSigue:n=>`¡Llevas ${n} días seguidos leyendo! Vuelve mañana para el día ${n+1}.`,
    avisoReinicio:n=>`Tu racha anterior era de ${n} ${n===1?'día':'días'}. ¡Esta vez llega más lejos!`,
    record:'¡Nuevo récord!',
    boton:'¡Genial!'
  }
};
