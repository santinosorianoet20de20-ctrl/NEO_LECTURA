/* =====================  LOGIN · CONFIGURACIÓN  =====================
   Todo lo que se puede cambiar del inicio de sesión sin tocar la lógica:
   textos, frases de Librín, sus imágenes, avatares y reglas.
   Colores tomados de la paleta del Sistema de Diseño (Sprint 7).        */
const LOGIN_CFG={
  /* Librín: cada estado muestra una imagen de img/librin/ (todas del mismo tamaño) */
  librin:{
    carpeta:'img/librin/',ancho:513,alto:508,
    estados:{
      idle:'saludo',        // esperando: saluda
      look:'aprender',      // mientras escribes el usuario o el nombre
      hide:'ojos-cerrados', // contraseña oculta: cierra los ojos
      peek:'guino',         // contraseña visible: guiña un ojo
      sad:'vamos',          // error: te da ánimo
      happy:'logrado'       // entraste: salta de alegría
    },
    divertidas:['bien','excelente','guino','increible','orgullo'], // al tocarlo o cuando espera
    todas:['saludo','aprender','ojos-cerrados','guino','vamos','animo','logrado','bien','excelente','increible','orgullo']
  },

  /* Personajes para elegir al crear la cuenta (fondo y borde de la paleta) */
  avatares:[
    {id:'leon',    emoji:'🦁', nombre:'León',       bg:'#FEF4EC', ring:'#ED823A'},
    {id:'raton',   emoji:'🐭', nombre:'Ratón',      bg:'#D5E0E5', ring:'#387CC6'},
    {id:'cerdito', emoji:'🐷', nombre:'Cerdito',    bg:'#FCE3E2', ring:'#E64D49'},
    {id:'lobo',    emoji:'🐺', nombre:'Lobo',       bg:'#DCF0F5', ring:'#387CC6'},
    {id:'astro',   emoji:'🧑‍🚀', nombre:'Astronauta', bg:'#DCF0F5', ring:'#58C7C8'},
    {id:'hada',    emoji:'🧚', nombre:'Hada',       bg:'#FEF8E2', ring:'#DFAA21'},
    {id:'buho',    emoji:'🦉', nombre:'Búho',       bg:'#FEF4EC', ring:'#704010'},
    {id:'tortuga', emoji:'🐢', nombre:'Tortuga',    bg:'#DFFCE7', ring:'#3AA75B'}
  ],

  /* Reglas de los campos */
  reglas:{usuarioMin:3,usuarioMax:14,usuarioRegex:/^[a-z0-9._]+$/i,claveMin:4,claveMax:32,nombreMin:2,nombreMax:14},

  /* Textos fijos de la pantalla */
  textos:{
    titulo:'NeoLectura',
    lema:'¡Aprender leyendo es más divertido!',
    librinAria:'Librín, la mascota de NeoLectura. Tócalo para que te dé un consejo',
    invitado:'Invitado'
  },

  /* Mensajes debajo de cada campo */
  msg:{
    usuarioVacio:'Escribe tu usuario.',
    usuarioEspacios:'El usuario no puede tener espacios.',
    usuarioCorto:'El usuario debe tener al menos 3 caracteres.',
    usuarioRaro:'Usa solo letras, números, punto (.) o guion bajo (_).',
    claveVacia:'Escribe tu contraseña.',
    claveCorta:'La contraseña debe tener al menos 4 caracteres.',
    nombreVacio:'Escribe tu nombre.',
    nombreCorto:'Tu nombre debe tener al menos 2 letras.',
    nombreRaro:'Usa solo letras y espacios.',
    noExiste:'No encontré ese usuario. <button type="button" class="lg-link" data-login="ir-crear">Crear una cuenta</button>',
    claveMal:'La contraseña no es correcta.',
    existe:'Ese usuario ya existe. ¡Prueba con otro!',
    libre:'¡Ese usuario está libre!',
    noGuardo:'No pude guardar la cuenta en este navegador.'
  },

  /* Lo que dice Librín en el globito (frases cortas) */
  frases:{
    hola:'¡Hola! 👋',
    deNuevo:n=>`¡Hola, ${n}! 👋`,
    usuario:'Escribe tu usuario ✏️',
    clave:'¡No miro! 🙈',
    espiar:'¡Solo un poquito! 😉',
    claveNueva:'Mezcla letras y números 🔐',
    fuerte:'¡Excelente contraseña! ⭐',
    nombre:'¿Cómo te llamas? 😊',
    hola2:n=>`¡Hola, ${n}! 😊`,
    libre:'¡Muy bien! 👍',
    crear:'¡Vamos a crear tu cuenta! 📚',
    volver:'¡Qué bueno verte! 👋',
    avatar:(n,e)=>`¡${n}! ¡Increíble! ${e}`,
    olvide:'Pídele ayuda a tu docente 🧑‍🏫',
    noExiste:'No encuentro ese usuario 🤔',
    claveMal:'¡No te rindas! Prueba otra vez 💪',
    ayuda:'Pídele ayuda a tu docente 🧑‍🏫',
    revisar:'Revisa los campos en rojo 👆',
    exito:n=>`¡Lo lograste, ${n}! 🎉`,
    creada:n=>`¡Cuenta creada, ${n}! 🎉`,
    invitado:'¡A leer! 🎉',
    cosquillas:'¡Jajaja! ¡Cosquillas! 🤭'
  },

  /* Consejos que da Librín cuando lo tocan */
  tips:[
    '¡Leer todos los días te hace un súper lector! ⭐',
    'Toca las palabras subrayadas para saber qué significan 📖',
    'Al final de cada nivel hay un quiz 🏆',
    'Puedes escuchar los cuentos 🎧'
  ],

  /* Texto del medidor de contraseña (0 a 3 estrellas) */
  fuerza:['Mínimo 4 caracteres','Está bien','¡Buena contraseña!','¡Súper segura!'],

  /* Cada cuántos segundos Librín hace una reacción si nadie lo usa (0 = nunca) */
  reaccionSola:14,

  /* Burbujas que suben por el fondo */
  decor:{burbujas:10}
};

/* Devuelve el avatar por su id (o el primero si no existe) */
const LOGIN_AVATAR=id=>LOGIN_CFG.avatares.find(a=>a.id===id)||LOGIN_CFG.avatares[0];
