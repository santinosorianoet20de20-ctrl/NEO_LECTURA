/* =====================  LOGIN · LIBRÍN (MASCOTA)  =====================
   Librín con las imágenes de img/librin/ (una por reacción).
   - estado(mood): cambia la imagen según el estado (ver LOGIN_CFG.librin).
   - reaccion(nombre): muestra una reacción un ratito y vuelve.
   - mirarA / mirarTexto: se inclina hacia el puntero o hacia lo que escribes.
   Los movimientos (saltar, rebotar, inclinarse) están en css/login.css.   */
const Librin=(()=>{
  const CFG=LOGIN_CFG.librin;
  const INCL=7; // inclinación máxima en grados
  let tEstado=0,turno=0;
  const el=()=>document.querySelector('.librin');
  const ruta=n=>CFG.carpeta+n+'.png';

  // Precarga de todas las imágenes para que el cambio sea instantáneo
  CFG.todas.forEach(n=>{const i=new Image();i.src=ruta(n)});

  function html(){
    return `<span class="lb-sombra" aria-hidden="true"></span>
      <span class="lb-cuerpo"><img class="lb-img" src="${ruta(CFG.estados.idle)}" data-s="${CFG.estados.idle}" alt="" width="${CFG.ancho}" height="${CFG.alto}" draggable="false"></span>`;
  }

  /* Cambia la imagen con un pequeño "pop" */
  function sprite(nombre){
    const l=el();if(!l)return;
    const img=l.querySelector('.lb-img');
    if(!img||img.dataset.s===nombre)return;
    img.src=ruta(nombre);img.dataset.s=nombre;
    l.classList.remove('pop');void l.offsetWidth;l.classList.add('pop');
  }

  /* Cambia el estado. Si se pasa "ms", vuelve solo al estado "luego"
     (texto o función que lo calcula en ese momento). "img" fuerza una imagen. */
  function estado(mood,ms,luego,img){
    const l=el();if(!l)return;
    clearTimeout(tEstado);const yo=++turno;
    l.dataset.mood=mood;
    sprite(img||CFG.estados[mood]||CFG.estados.idle);
    if(ms)tEstado=setTimeout(()=>{
      if(yo!==turno)return;
      estado(typeof luego==='function'?luego():(luego||'idle'));
    },ms);
  }
  const animo=()=>{const l=el();return l?l.dataset.mood:''};

  /* Reacción corta (por ejemplo 'bien' o 'increible') y vuelve a lo que estaba */
  function reaccion(nombre,ms,luego){estado('cheer',ms||1500,luego||'idle',nombre)}

  /* Reinicia una animación de una sola vez (boing, giggle) */
  function animar(clase){const l=el();if(!l)return;l.classList.remove(clase);void l.offsetWidth;l.classList.add(clase)}

  /* Se inclina hacia un punto de la pantalla */
  function mirarA(x,y){
    const l=el();if(!l)return;
    const r=l.getBoundingClientRect();
    const dx=x-(r.left+r.width/2),dy=y-(r.top+r.height/2);
    const g=Math.max(-INCL,Math.min(INCL,dx/45));
    l.style.setProperty('--tilt',g.toFixed(2)+'deg');
    l.style.setProperty('--lean',(Math.max(-1,Math.min(1,dx/300))*6).toFixed(1)+'px');
    l.style.setProperty('--alto',(dy<0?-2:0)+'px');
  }
  function centrar(){const l=el();if(l){l.style.setProperty('--tilt','0deg');l.style.setProperty('--lean','0px');l.style.setProperty('--alto','0px')}}

  /* Se inclina hacia el final del texto escrito en un campo */
  let ctx=null;
  function mirarTexto(input){
    if(!input)return;
    const r=input.getBoundingClientRect(),cs=getComputedStyle(input);
    if(!ctx)ctx=document.createElement('canvas').getContext('2d');
    ctx.font=cs.fontWeight+' '+cs.fontSize+' '+cs.fontFamily;
    const txt=input.type==='password'?'•'.repeat(input.value.length):input.value;
    const ancho=Math.min(ctx.measureText(txt).width,r.width-parseFloat(cs.paddingRight||0));
    mirarA(r.left+parseFloat(cs.paddingLeft||0)+ancho,r.top+r.height/2);
  }

  /* Cambia el texto del globito con una animación */
  function decir(t){
    const b=document.getElementById('lg-bubble');if(!b||b.dataset.t===t)return;
    b.dataset.t=t;b.textContent=t;
    b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop');
  }

  /* Al terminar una animación de una sola vez, se quita su clase */
  document.addEventListener('animationend',e=>{
    const l=e.target.closest&&e.target.closest('.librin');if(!l)return;
    if(e.animationName==='lb-boing')l.classList.remove('boing');
    if(e.animationName==='lb-giggle')l.classList.remove('giggle');
  });

  return {html,estado,reaccion,animo,animar,mirarA,mirarTexto,centrar,decir};
})();
