/* =====================  LOGIN · VALIDACIONES  =====================
   Cada función devuelve '' si el dato está bien, o el mensaje de error. */
const LoginValidar=(()=>{
  const REG=LOGIN_CFG.reglas,M=LOGIN_CFG.msg;

  function usuario(v){
    v=String(v||'').trim();
    if(!v)return M.usuarioVacio;
    if(/\s/.test(v))return M.usuarioEspacios;
    if(v.length<REG.usuarioMin)return M.usuarioCorto;
    if(!REG.usuarioRegex.test(v))return M.usuarioRaro;
    return '';
  }
  function clave(v){
    v=String(v||'');
    if(!v)return M.claveVacia;
    if(v.length<REG.claveMin)return M.claveCorta;
    return '';
  }
  function nombre(v){
    v=String(v||'').trim();
    if(!v)return M.nombreVacio;
    if(v.length<REG.nombreMin)return M.nombreCorto;
    if(!/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ' -]+$/.test(v))return M.nombreRaro;
    return '';
  }
  /* Fuerza de la contraseña de 0 a 3 (se muestra como estrellas) */
  function fuerza(c){
    c=String(c||'');
    if(c.length<REG.claveMin)return 0;
    const letras=/[a-zñ]/i.test(c),numeros=/\d/.test(c),extra=/[A-ZÑ]/.test(c)||/[^a-z0-9ñ]/i.test(c);
    if(c.length>=8&&letras&&numeros&&extra)return 3;
    if(c.length>=6&&letras&&numeros)return 2;
    return 1;
  }
  return {usuario,clave,nombre,fuerza};
})();
