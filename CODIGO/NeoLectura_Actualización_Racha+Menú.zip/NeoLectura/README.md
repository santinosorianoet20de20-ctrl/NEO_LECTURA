# NeoLectura — versión modular

Esta versión separa el código original por responsabilidades, manteniendo el contenido y la lógica originales.
Desde esta actualización incluye el **inicio de sesión** (degradé azul–turquesa, tarjeta de vidrio esmerilado) con Librín reaccionando a lo que hace el usuario.

## Estructura

- `index.html` — estructura HTML mínima y carga de archivos.
- `css/styles.css` — estilos originales de la app.
- `css/login.css` — estilos del inicio de sesión (fondo, tarjeta, botones y animaciones de Librín).
- `css/racha.css` — estilos de la racha diaria (indicador, detalle y aviso).
- `img/racha/` — fuego de racha (`fuego.svg` encendido y `fuego-apagado.svg`).
- `img/librin/` — reacciones de Librín (PNG con fondo transparente, todas del mismo tamaño para que no "salte" al cambiar).
- `js/utils.js` — utilidades, iconos y mascota.
- `js/illustrations.js` — ilustraciones SVG y generación de portadas.
- `js/data/stories.js` — cuentos, niveles, partes y preguntas.
- `js/data/config.js` — ranking inicial, tamaños de letra y cantidad de partes.
- `js/state.js` — estado, localStorage y funciones relacionadas con el progreso (ahora con un progreso por usuario).
- `js/screens.js` — pantallas/interfaz.
- `js/login/` — módulo de inicio de sesión:
  - `login.config.js` — textos, frases de Librín, qué imagen usa en cada momento, avatares y reglas. **Para cambiar un texto o una reacción, se cambia acá.**
  - `login.storage.js` — cuentas (localStorage), sesión (sessionStorage) y hash de contraseñas.
  - `login.validation.js` — validación de usuario, contraseña y nombre, y fuerza de la contraseña.
  - `login.mascot.js` — Librín: cambia de imagen según el estado, se inclina hacia el puntero y muestra el globito.
  - `login.view.js` — HTML de la pantalla de inicio de sesión.
  - `login.controller.js` — eventos, reacciones de Librín y conexión con la app (entrar / salir).
- `js/racha/` — módulo de racha diaria:
  - `racha.config.js` — puntos por día, tope, imágenes y textos. **Para cambiar cuántos puntos da la racha, se cambia acá.**
  - `racha.logic.js` — fechas, estado de la racha (hecha / pendiente / apagada) y suma del día.
  - `racha.view.js` — HTML del indicador, del detalle y del aviso de racha completa.
  - `racha.controller.js` — abre y cierra las ventanas, animación del aviso.
- `js/navigation.js` — navegación, eventos y lógica de interacción.

## Inicio de sesión

- Aparece apenas se abre la app. La sesión dura mientras la pestaña esté abierta (si se recarga, sigue adentro; si se vuelve a abrir la app, pide iniciar sesión otra vez).
- **Iniciar Sesión**: usuario, contraseña (con botón para verla), "Recordarme" y "¿Olvidaste tu contraseña?". Botones **Entrar 🚀** y **Crear cuenta ✨**.
- **Crear Cuenta**: nombre, usuario (avisa si ya existe), contraseña con medidor de 1 a 3 estrellas y personaje (avatar).
- **o entra como invitado**: usa el progreso guardado de siempre (`neolectura.v1`), así no se pierde lo que ya estaba.
- Cada usuario tiene su propio progreso guardado en `neolectura.v1:<usuario>`.
- Respeta el tema Claro/Oscuro/Automático de Opciones y la opción de "reducir movimiento" del sistema.

### Reacciones de Librín

| Momento | Imagen |
|---|---|
| Esperando (se mece saludando) | `saludo.png` |
| Escribe el usuario o el nombre | `aprender.png` |
| Escribe la contraseña (no mira) | `ojos-cerrados.png` |
| Muestra la contraseña (espía) | `guino.png` |
| Error en un campo | `vamos.png` |
| Contraseña incorrecta | `animo.png` |
| Usuario libre / volver a iniciar sesión | `bien.png` |
| Contraseña súper segura | `excelente.png` |
| Elige personaje / abre Crear cuenta | `increible.png` |
| Cosquillas (tocarlo 4 veces rápido) | `orgullo.png` |
| Entró a la app (salta) | `logrado.png` |

Además se inclina hacia el puntero, da consejos si lo tocan y, si nadie lo usa por un rato, hace una reacción solo (`reaccionSola` en `login.config.js`).

## Racha diaria de lectura

- Se suma **1 día de racha al aprobar el primer quiz del día** (aprobar = la mitad de las respuestas o más). Los demás quizzes de ese día no suman otro día.
- Si pasa un día entero sin aprobar un quiz, la racha se apaga y vuelve a empezar desde 1.
- **Puntos extra**: cada día de racha da 5 puntos más que el anterior (día 1: +5, día 2: +10, día 3: +15…), con un tope de +100 por día (desde el día 20). Para comparar: leer una parte da +50 y cada respuesta correcta +100, así que la racha no desbalancea el sistema.
- **Indicador** en la tarjeta del menú principal: fuego encendido (hoy ya leíste), fuego dormido con "!" (falta el quiz de hoy) o apagado (racha en 0), con los últimos 7 días. Al tocarlo se abre el detalle (semana, récord y cuántos puntos se ganan hoy).
- **Aviso de racha completa**: aparece al aprobar el primer quiz del día, con el fuego, el número de días, la semana, los puntos ganados y "¡Nuevo récord!" si corresponde.
- Usa la fecha del dispositivo y se guarda en el progreso de cada usuario (`S.racha`). "Reiniciar progreso" en Opciones también reinicia la racha.

> Es un prototipo sin servidor: las cuentas quedan guardadas en el navegador de este dispositivo. En una app real, el usuario y la contraseña se verifican en un servidor.

## Importante

Las cuentas nuevas empiezan con los puntos de `DEF` en `js/state.js` (1.250, igual que antes). Si se quiere que empiecen en 0, se cambia `points` en `DEF`.

Abrir `index.html` desde un servidor local/repo web es recomendable para probar el proyecto (también funciona abriéndolo directo).
