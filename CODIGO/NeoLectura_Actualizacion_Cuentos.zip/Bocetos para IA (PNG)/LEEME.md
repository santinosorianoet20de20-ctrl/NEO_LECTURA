# Dibujos de las escenas

Cada cuento tiene **4 dibujos**: la portada (para la tarjeta del camino de lectura) y una escena por cada una de sus 3 partes.
Están hechos simples, con formas planas, para que sirvan de **boceto**: se le pueden pasar a otra inteligencia artificial (o a un ilustrador) para hacer la versión final.

## Cómo reemplazarlos por la versión final

1. Guardar cada imagen nueva con **el mismo nombre** en la misma carpeta (`img/escenas/<cuento>/portada`, `parte-1`, `parte-2`, `parte-3`).
2. Si las nuevas no son SVG (por ejemplo PNG o WebP), cambiar el formato en un solo lugar: `formato:'svg'` → `formato:'png'` en `CAMINO_CFG` (`js/cuentos/cuentos.camino.js`).
3. Si una sola imagen tiene otro nombre o formato, se puede poner su ruta en el cuento: `imagen:'ruta'` en esa parte, o `portada:'ruta'` en el cuento (`js/cuentos/<cuento>.js`).

## Medidas

| Dibujo | Proporción | Tamaño de los bocetos | Tamaño recomendado para la versión final |
|---|---|---|---|
| Portada | 3:4 (vertical) | 300 × 400 | 900 × 1200 |
| Escena de cada parte | 12:5 (apaisada) | 960 × 400 | 1920 × 800 |

En la lectura la escena se ve entera en la computadora y un poco recortada arriba y abajo en el celular: conviene dejar lo importante en el centro.

## Estilo (para pedirle a la otra IA)

> Ilustración infantil para una app de lectura de primaria. Estilo plano y amable, colores cálidos y saturados, contornos suaves, sin texto ni letras en la imagen. Personajes simpáticos (sin escenas de miedo explícito ni sangre). Mantener la misma composición, los mismos personajes y los mismos colores que el boceto que adjunto.

Para cada dibujo: adjuntar el boceto (`.svg`, o una captura en PNG) + el texto de estilo + la descripción de la escena que está abajo. Los personajes tienen que verse **iguales en todas las escenas** del mismo cuento.

## Nivel 1 · Caperucita Roja (Charles Perrault)

**Personajes**

- **Caperucita Roja**: niña de unos 8 años, pelo castaño, capa roja con capucha (siempre puesta), vestido azul con delantal blanco, medias blancas y zapatos marrones. Lleva una canasta de mimbre con un paño blanco.
- **El lobo**: lobo gris con panza gris clara, ojos amarillos, orejas puntiagudas y sonrisa pícara (no aterrador: es un cuento para chicos).
- **La casa de la abuela**: casita de paredes crema y techo rojo, con chimenea.

| Archivo | Qué muestra |
|---|---|
| `caperucita-roja/portada.svg` | Caperucita Roja camina por el bosque con su canasta mientras un lobo la espía detrás de un árbol. |
| `caperucita-roja/parte-1.svg` | **Parte 1 · Un encargo para la abuela.** Un bosque con un camino de tierra. Caperucita Roja (una niña con capa roja con capucha y una canasta) habla con un lobo gris que le sonríe. Entre los árboles se ven dos leñadores con hachas y, a lo lejos, un molino. |
| `caperucita-roja/parte-2.svg` | **Parte 2 · El camino más corto.** Un camino que se divide en dos. Por el camino corto corre el lobo hacia una casita; por el largo, Caperucita junta flores entre mariposas y avellanos. |
| `caperucita-roja/parte-3.svg` | **Parte 3 · ¡Qué dientes tan grandes!.** El cuarto de la abuela. El lobo está acostado en la cama con gorro de dormir y la frazada hasta el hocico; Caperucita, al lado de la cama, lo mira sorprendida. En una repisa están la torta y el tarrito de mantequilla. |

## Nivel 2 · El gato con botas (Charles Perrault)

**Personajes**

- **El gato**: gato naranja con panza crema y ojos verdes, camina en dos patas. Sombrero violeta oscuro de ala ancha con cinta dorada y pluma roja, botas altas marrones y una bolsa de tela colgada.
- **El rey**: hombre mayor con barba blanca, corona dorada, capa roja con cuello blanco de armiño y cetro.
- **El marqués (el amo)**: joven de pelo castaño.

| Archivo | Qué muestra |
|---|---|
| `el-gato-con-botas/portada.svg` | El gato con botas, de pie y orgulloso, con sombrero de pluma, botas altas y una bolsa al hombro; atrás, un castillo sobre una colina. |
| `el-gato-con-botas/parte-1.svg` | **Parte 1 · Una herencia muy pobre.** El salón del rey. El gato con botas altas, sombrero con pluma y una bolsa colgada del cuello hace una reverencia y le ofrece un conejo al rey, que está sentado en su trono con corona y capa roja. |
| `el-gato-con-botas/parte-2.svg` | **Parte 2 · El marqués de Carabás.** Un río al lado de un camino. El amo del gato asoma la cabeza desde el agua, el gato con botas grita pidiendo ayuda y se acerca la carroza dorada del rey. Detrás de una piedra grande se ve la ropa escondida. |
| `el-gato-con-botas/parte-3.svg` | **Parte 3 · El ogro del castillo.** Frente a un castillo con puente levadizo, el gato con botas salta hacia un ratoncito que corre por el piso. Al lado quedaron el gran sombrero y la capa del ogro, vacíos. |

## Nivel 3 · Barba Azul (Charles Perrault)

**Personajes**

- **Barba Azul**: hombre alto y elegante, pelo oscuro, barba azul grande, ceño fruncido, saco violeta con botones dorados y cuello blanco.
- **La esposa**: joven de pelo castaño recogido en rodete, vestido rosa largo.
- **La hermana Ana**: joven rubia con vestido verde.
- **Los hermanos**: dos jinetes a caballo con espadas; uno de azul con casco (el dragón) y otro de rojo con sombrero de pluma (el mosquetero).
- **La llavecita**: llave dorada chica con una mancha roja que no se va (sin mostrar sangre de forma explícita).

| Archivo | Qué muestra |
|---|---|
| `barba-azul/portada.svg` | Un castillo oscuro con una torre bajo un cielo violeta; en primer plano, una llavecita dorada con una pequeña mancha roja. |
| `barba-azul/parte-1.svg` | **Parte 1 · Las llaves de Barba Azul.** Un salón elegante con cortinas y espejos dorados. Barba Azul (un hombre alto con barba azul y ropa elegante) le entrega a su esposa un aro con muchas llaves; una llavecita dorada se destaca y brilla. |
| `barba-azul/parte-2.svg` | **Parte 2 · La llavecita manchada.** Un pasillo oscuro, iluminado por una vela, con una puertita cerrada al fondo. La esposa, nerviosa, mira la llavecita dorada que tiene en la mano: tiene una mancha roja que no se va. |
| `barba-azul/parte-3.svg` | **Parte 3 · Ana, hermana mía.** Lo alto de una torre de piedra. La hermana Ana agita un pañuelo; abajo se ven el sol, la hierba verde, una nube de polvo y dos jinetes con espadas que se acercan galopando. |

## Nivel 4 · Hansel y Gretel (Hermanos Grimm)

**Personajes**

- **Hansel**: niño de unos 9 años, pelo castaño despeinado, camisa verde, pantalón corto marrón con tiradores, medias blancas.
- **Gretel**: niña de unos 8 años, rubia con dos trenzas y moños celestes, vestido rojo con delantal blanco.
- **La casita de dulce**: paredes de pan con galletitas, techo de pastel rosa con glaseado blanco y confites de colores, ventanas de azúcar, chimenea de chocolate y chupetines al costado.
- **El pato**: pato blanco grande con pico naranja.

| Archivo | Qué muestra |
|---|---|
| `hansel-y-gretel/portada.svg` | Hansel y Gretel, tomados de la mano, miran asombrados una casita de pan, pastel y caramelos en medio del bosque. |
| `hansel-y-gretel/parte-1.svg` | **Parte 1 · Los guijarros blancos.** Un bosque de noche con luna llena. Hansel y Gretel caminan de la mano por un sendero marcado con piedritas blancas que brillan como monedas. |
| `hansel-y-gretel/parte-2.svg` | **Parte 2 · La casita de pan.** En un claro del bosque, una casita hecha de pan con techo de pastel y ventanas de azúcar. Un pajarito blanco está posado en el techo. Hansel muerde un pedazo del techo y Gretel come una ventana. |
| `hansel-y-gretel/parte-3.svg` | **Parte 3 · Gretel salva a su hermano.** Un río ancho. Un pato blanco grande cruza nadando con Gretel sobre el lomo; en la orilla espera Hansel con los bolsillos llenos de perlas. Del otro lado, a lo lejos, se ve la casa del padre. |

Las descripciones también están en el archivo de cada cuento (`js/cuentos/<cuento>.js`, campos `dibujo` y `dibujoPortada`). Si se cambia una, conviene cambiarla en los dos lugares.
