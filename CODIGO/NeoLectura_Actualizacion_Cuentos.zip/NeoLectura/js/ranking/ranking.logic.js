/* =====================  RANKING · LÓGICA  =====================
   - anotar(): se llama cada vez que se guarda el progreso (save, en state.js).
     Si el que está usando la app es una cuenta real, actualiza su fila.
     El invitado no se anota.
   - lista(): las filas ordenadas por puntos (solo de cuentas que existen).
     Las cuentas creadas antes de que existiera el ranking se suman solas,
     leyendo el progreso que ya tenían guardado.                           */
const Ranking=(()=>{
  const C=RANKING_CFG;

  /* Usuario de la cuenta que está usando la app (null = invitado).
     Sale de la clave del progreso: "neolectura.v1:<usuario>" (ver state.js). */
  const usuarioActual=()=>KEY.indexOf(KEY_BASE+':')===0?KEY.slice(KEY_BASE.length+1):null;

  function fila(usuario,s){
    return {usuario,nombre:String(s.name||usuario),avatar:s.avatar||'',puntos:Math.max(0,+s.points||0),actualizado:Date.now()};
  }

  /* Anota los puntos de la cuenta actual */
  function anotar(){
    const u=usuarioActual();if(!u)return;
    const t=RankingFuente.leer(),f=fila(u,S),antes=t[u];
    if(antes&&antes.nombre===f.nombre&&antes.avatar===f.avatar&&antes.puntos===f.puntos)return; // sin cambios
    RankingFuente.guardar(f);
  }

  /* Cuentas que existen (las de login). Si falta alguna en la tabla pero tiene
     progreso guardado de antes, se agrega. Las filas de cuentas que ya no existen no se muestran. */
  function lista(){
    const cuentas=typeof LoginStorage!=='undefined'?LoginStorage.cuentas():[];
    const t=RankingFuente.leer();
    for(const c of cuentas){
      if(t[c.usuario])continue;
      let s=null;try{s=JSON.parse(localStorage.getItem(KEY_BASE+':'+c.usuario)||'null')}catch(e){}
      if(s){t[c.usuario]=fila(c.usuario,Object.assign({name:c.nombre},s));RankingFuente.guardar(t[c.usuario])}
    }
    const existen=new Set(cuentas.map(c=>c.usuario)),yo=usuarioActual();
    return Object.values(t)
      .filter(f=>existen.has(f.usuario))
      .sort((a,b)=>b.puntos-a.puntos||a.actualizado-b.actualizado||a.nombre.localeCompare(b.nombre,'es'))
      .slice(0,C.mostrar)
      .map((f,i)=>Object.assign({},f,{puesto:i+1,yo:f.usuario===yo}));
  }

  return {anotar,lista,usuarioActual};
})();
