/* =====================  RANKING · FUENTE DE DATOS  =====================
   Lee y guarda la tabla del ranking: { usuario: {usuario, nombre, avatar, puntos, actualizado} }.
   Hoy la tabla está en localStorage (se mantiene entre sesiones, en este
   dispositivo). Todo el resto del ranking usa solo estas tres funciones, así
   que para tener un ranking compartido entre todos los dispositivos alcanza
   con reemplazar este archivo por uno que hable con un servidor (por ejemplo
   Supabase o Firebase) y mantenga las mismas funciones.                    */
const RankingFuente=(()=>{
  const K=RANKING_CFG.clave;
  const st=()=>{try{return window.localStorage}catch(e){return null}};

  function leer(){
    try{const t=JSON.parse(st().getItem(K)||'{}');return t&&typeof t==='object'&&!Array.isArray(t)?t:{}}
    catch(e){return {}}
  }
  function escribir(t){try{st().setItem(K,JSON.stringify(t))}catch(e){}}

  /* Guarda (o actualiza) la fila de una cuenta */
  function guardar(entrada){
    const t=leer();t[entrada.usuario]=entrada;escribir(t);
  }
  /* Saca una cuenta de la tabla */
  function borrar(usuario){
    const t=leer();if(t[usuario]){delete t[usuario];escribir(t)}
  }

  return {leer,guardar,borrar};
})();
