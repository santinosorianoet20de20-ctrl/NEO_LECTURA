/* =====================  LIBRÍN COMPAÑERO · VISTA  =====================
   HTML de la mascota (Librín, o Librón si se eligió su voz) con su globito,
   para la lectura y para el quiz.
   Todo empieza con "cp-" (compañero) para no chocar con el Librín del inicio
   de sesión (que usa "lb-").                                             */
const CompaneroVista=(()=>{
  const C=COMP_CFG;
  const REACCIONES=['saludo','bien','excelente','guino','vamos','orgullo','increible','animo','ojos-cerrados','aprender','logrado',
    'muy-bien','segui-asi','mejorar','vos-podes','nublado','no-te-rindas','gran-trabajo','pensando','genial','triste'];
  const ruta=r=>MASCOTA_RUTA(r); // con los cambios de cara de cada mascota (js/utils.js)
  // Precarga de las reacciones de la mascota que se está usando, para que el cambio de cara sea instantáneo
  const precargadas={};
  function precargar(){
    const m=MASCOTA();if(precargadas[m.id])return;
    precargadas[m.id]=true;REACCIONES.forEach(r=>{const i=new Image();i.src=ruta(r)});
  }

  /* Librín + globo. "tocable": se lo puede tocar (en la lectura).
     "tipo": 'ok' / 'mal' tiñe el globo (aciertos y errores del quiz). */
  function caja(reaccion,html,{tipo='',tocable=false,datos=''}={}){
    precargar();
    const m=MASCOTA();
    const img=`<img src="${ruta(reaccion)}" data-r="${reaccion}" alt="" width="513" height="508" draggable="false">`;
    return `<div class="cp cp-${m.id}${tipo?' cp-'+tipo:''}" data-cp data-mascota="${m.id}" ${datos}>
      ${tocable?`<button class="cp-yo" data-cp-toque aria-label="Tocar a ${m.nombre}">${img}</button>`:`<span class="cp-yo" aria-hidden="true">${img}</span>`}
      <div class="cp-globo" role="status" aria-live="polite"><span class="cp-quien" data-cp-nombre>${m.nombre}</span><p class="cp-txt">${html}</p></div>
    </div>`;
  }

  /* ---------- Lectura ---------- */
  /* p = número de parte (0, 1, 2) · ultima = es la última parte antes del quiz */
  function lectura(P,p,ultima){
    const L=C.lectura;
    const pregunta=P.lb?ESC(P.lb):L.generico[Math.min(p,L.generico.length-1)];
    const base=pregunta+(ultima?`<small>${L.antesDelQuiz}</small>`:'');
    const datos=`data-cp-lectura data-base="${ESC(base)}" data-pregunta="${ESC(P.lb?pregunta:'')}" data-ultima="${ultima?1:''}"`;
    return caja(L.pregunta,base,{tocable:true,datos});
  }

  /* ---------- Quiz ---------- */
  /* Antes de responder: ánimo según la pregunta */
  function quizPregunta(i,n,nivel){
    const Q=C.quiz,[r,t]=i===0?Q.primera:i===n-1?Q.ultima:Q.otra;
    return caja(r,typeof t==='function'?t(ESC(nivel)):t);
  }
  /* Después de responder: festeja o consuela (va rotando para no repetir siempre lo mismo) */
  function quizRespuesta(acerto,i,n,puntaje,correcta){
    const Q=C.quiz;
    if(acerto){const [r,t]=Q.bien[(i+puntaje)%Q.bien.length];return caja(r,t,{tipo:'ok'})}
    const [r,f]=i===n-1?Q.mal[0]:Q.mal[i%Q.mal.length];
    return caja(r,f(ESC(correcta)),{tipo:'mal'});
  }
  /* Resultado del nivel (ninguna = no acertó ninguna pregunta) */
  function quizResultado(aprobo,perfecto,ultimoNivel,ninguna){
    const Q=C.quiz,[r,t]=!aprobo?(ninguna?Q.ninguna:Q.desaprobado):ultimoNivel?Q.cuento:perfecto?Q.perfecto:Q.aprobado;
    return caja(r,t,{tipo:aprobo?'ok':''});
  }

  return {caja,lectura,quizPregunta,quizRespuesta,quizResultado,ruta,precargar};
})();
