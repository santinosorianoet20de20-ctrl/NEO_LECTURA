/* =====================  LIBRÍN COMPAÑERO · CONFIGURACIÓN  =====================
   Librín acompaña la lectura y los quizzes: aparece con un globito, dice
   comentarios y cambia de reacción (imágenes de img/librin/).
   Si el usuario eligió la voz de Librón, aparece Librón en su lugar (img/libron/),
   con las mismas reacciones: lo decide MASCOTA() de js/utils.js.
   - En la lectura dice la pregunta "librin" de cada parte (está en el archivo de cada cuento, js/cuentos/)
     y reacciona al audiolibro: cuando empieza, por la mitad, en pausa y al final.
     También explica las palabras del vocabulario.
   - En el quiz da ánimo, festeja los aciertos, consuela los errores y comenta el resultado.
   **Para cambiar lo que dice Librín o qué cara pone, se cambia acá.**
   Reacciones (img/librin/ e img/libron/ tienen las mismas):
   saludo, bien, excelente, guino, vamos, orgullo, increible, animo, ojos-cerrados (feliz, aplaudiendo),
   aprender (con un libro), logrado (saltando), muy-bien (dos pulgares), segui-asi (guiño y pulgar),
   mejorar (manos juntas), vos-podes (dedo arriba), nublado (triste, con nube), no-te-rindas (puño),
   gran-trabajo (te señala), pensando (mano en el mentón), genial (brazos arriba), triste (llorando).
   Si a una mascota le falta una cara con el mismo sentimiento, usa otra: "cambios" en MASCOTAS (js/utils.js). */
const COMP_CFG={
  temporal:5000,   // ms que dura un comentario de paso antes de volver a la pregunta de la parte

  lectura:{
    pregunta:'pensando',   // cara mientras muestra la pregunta de la parte (mano en el mentón)
    // Si una parte no tiene "lb", dice una de estas según la parte (1, 2 o 3)
    generico:['¡Empieza una parte nueva! ¿Qué crees que va a pasar?','¿Te acuerdas de lo que pasó en la parte anterior?','¡Última parte del nivel! Lee con atención.'],
    antesDelQuiz:'Después de esta parte viene el quiz ⭐',
    empieza:['guino','¡A escuchar! Sigue con la vista las palabras que se pintan de azul 👀'],
    sigue:['segui-asi','¡Seguimos!'],
    otraVez:['guino','¡Otra vez! Así te sale cada vez mejor.'],
    mitad:['vos-podes','¡Ya vas por la mitad! 💪'],
    pausa:['ojos-cerrados','Hacemos una pausa. Cuando quieras, seguimos 😌'],
    fin:['muy-bien','¡Muy bien! Llegaste al final de esta parte 🎉'],
    finPregunta:'¿Ya puedes responder?',
    palabra:'aprender',    // cara cuando explica una palabra del vocabulario
    // Al tocar a Librín
    toques:[['excelente','¡Jeje, me haces cosquillas!'],['genial','¡Me encanta leer contigo!'],['gran-trabajo','¡Qué bien estás leyendo!'],['segui-asi','¡Sigue así!']]
  },

  quiz:{
    primera:['vamos',n=>`¡Vamos con la primera pregunta! Piensa en lo que leíste en «${n}».`],
    otra:['pensando','¡Otra más! Piensa bien y lee todas las opciones antes de elegir.'],
    ultima:['vos-podes','¡Última pregunta! Tú puedes 💪'],
    // Al acertar (van rotando)
    bien:[['muy-bien','¡Muy bien! 🎉'],['gran-trabajo','¡Estás haciendo un gran trabajo!'],['genial','¡Genial! ¡Qué orgulloso estoy de ti!'],['excelente','¡Excelente trabajo!'],['increible','¡Increíble! ¡Esa era!']],
    // Al errar: siempre una cara triste (Librín preocupado o con su nube; Librón, con su nube)
    mal:[['no-te-rindas',r=>`¡Casi! La respuesta correcta era: <b>${r}</b>. ¡No te rindas!`],
         ['nublado',r=>`Esta vez no. Era: <b>${r}</b>. ¡Ya vas a mejorar con la que sigue!`]],
    // Resultado
    perfecto:['increible','¡Increíble! ¡Respondiste todo bien!'],
    aprobado:['logrado','¡Lo lograste! Sabía que podías 😄'],
    cuento:['orgullo','¡Terminaste todos los cuentos del camino! Estoy muy orgulloso de ti.'],   // al aprobar el último nivel
    // No aprobado: con alguna bien, Librín consuela; sin ninguna, está triste pero da ánimo
    desaprobado:['nublado','Si te cuesta un poco más, está bien: todos aprendemos a nuestro tiempo. Repasa las partes y vuelve a intentarlo.'],
    ninguna:['triste','Hoy no te salió como querías… pero cada intento es una nueva oportunidad. ¡Repasa y vuelve a intentarlo!']
  }
};
