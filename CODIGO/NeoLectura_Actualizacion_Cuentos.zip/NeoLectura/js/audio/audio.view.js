/* =====================  AUDIOLIBRO · VISTA  =====================
   HTML del reproductor de la pantalla de lectura, del panel para elegir voz
   y de las tarjetas de Opciones (voz y volumen).
   El reproductor se arma con el estado actual del motor, así que si la
   pantalla se vuelve a dibujar, sigue mostrando lo mismo que estaba sonando. */
const AudioVista=(()=>{
  const C=AUDIO_CFG,T=C.textos;
  const num=`<text x="12" y="15.8" text-anchor="middle" font-size="${String(C.salto).length>1?8:10}" font-weight="900" fill="currentColor" stroke="none">${C.salto}</text>`;
  Object.assign(ICON,{ // íconos del reproductor (se suman a los de utils.js)
    play:'<polygon points="7 4 20 12 7 20 7 4"/>',
    pausa:'<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
    otraVez:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
    inicio:'<polygon points="19 20 9 12 19 4 19 20"/><line x1="5" x2="5" y1="19" y2="5"/>',
    atras:'<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.5"/><path d="M3.5 3.5v5h5"/>'+num,
    adelante:'<path d="M20.5 12a8.5 8.5 0 1 1-2.6-6.1l2.6 2.6"/><path d="M20.5 3.5v5h-5"/>'+num,
    volBajo:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>',
    mudo:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="22" x2="16" y1="9" y2="15"/><line x1="16" x2="22" y1="9" y2="15"/>',
    voz:'<path d="M8.8 20v-4.1l1.9.2a2.3 2.3 0 0 0 2.164-2.1V8.3A5.37 5.37 0 0 0 2 8.25c0 2.8.656 3.054 1 4.55a5.77 5.77 0 0 1 .029 2.758L2 20"/><path d="M19.8 17.8a7.5 7.5 0 0 0 .003-10.603"/><path d="M17 15a3.5 3.5 0 0 0-.025-4.975"/>',
    abajo:'<path d="m6 9 6 6 6-6"/>'
  });
  if(!ICON.x)ICON.x='<path d="M18 6 6 18"/><path d="m6 6 12 12"/>';

  const mmss=s=>{s=Math.max(0,Math.floor(s+.001));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
  const vol=()=>typeof S.vol==='number'?S.vol:C.volumenInicial;
  const iconoVol=v=>v<=0?'mudo':v<.5?'volBajo':'vol';
  const COLORES=typeof AVC!=='undefined'?AVC:['#F26B1D','#35BFC0','#1B7DCB','#8E63D4','#E0568A','#3BAA6B'];
  const color=s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return COLORES[h%COLORES.length]};

  /* Contenido del botón principal según el estado */
  function principal(estado){
    const [icono,txt,relleno]={
      listo:['play',T.escuchar,true],
      sonando:['pausa',T.pausar,true],
      pausa:['play',T.reanudar,true],
      fin:['otraVez',T.otraVez,false]
    }[estado]||['play',T.escuchar,true];
    return {html:`${ic(icono,18,relleno)}<span>${txt}</span>`,txt};
  }

  /* Botón de silenciar + barrita de volumen. "grande" = versión de Opciones */
  function volumen(grande){
    const v=Math.round(vol()*100),mudo=v===0;
    return `<div class="ap-vol${grande?' grande':''}">
      <button class="ap-b ap-mudo" data-audio="mudo" aria-label="${mudo?T.activar:T.silenciar}" title="${mudo?T.activar:T.silenciar}">${ic(iconoVol(v/100),grande?22:18)}</button>
      <input class="ap-rango" type="range" min="0" max="100" step="5" value="${v}" data-audio-vol aria-label="${T.volumen}" aria-valuetext="${v}%" style="--v:${v}%">
      ${grande?`<output class="ap-pct" data-audio-pct>${v}%</output>`:''}
    </div>`;
  }

  /* ---------- Voces ---------- */
  /* Botón del reproductor que abre el panel de voces: "🗣 Elena 🐢 ▾" */
  function botonVoz(){
    const x=AudioVoces.actual(),r=AudioVoces.ritmo(),n=x?x.nombre:T.panelTitulo;
    const lbl=T.elegirVoz(n+(x&&x.pais?', '+x.pais:'')+(r.id!=='normal'?', velocidad '+r.nombre:''));
    return {lbl,html:`${ic('voz',18)}<span class="ap-vozn">${ESC(n)}</span>${r.id!=='normal'?`<span class="ap-voze" aria-hidden="true">${r.emoji}</span>`:''}${ic('abajo',14)}`};
  }

  /* Una opción de la lista. Los personajes muestran su imagen o su emoji y cómo suenan */
  function fila(x,sel,grande){
    const p=x.personaje;
    const av=p?(p.img?`<img src="${p.img}" alt="" draggable="false">`:p.emoji):ESC(x.nombre.charAt(0).toUpperCase());
    const det=p?ESC(p.det):ESC(x.pais)+(x.natural?`<i class="ap-tag">${T.natural}</i>`:'')+(grande&&!x.local?`<i class="ap-tag web">${T.online}</i>`:'');
    return `<button class="ap-op" role="radio" aria-checked="${sel}" tabindex="${sel?0:-1}" data-audio="voz" data-id="${ESC(x.id)}">
      <span class="ap-av${p?' pj':''}" style="${p?'':'background:'+color(x.id)}" aria-hidden="true">${av}</span>
      <span class="ap-op-t"><b>${ESC(x.nombre)}</b><small>${det}</small></span>
      <span class="ap-radio" aria-hidden="true"></span></button>`;
  }

  /* Voces agrupadas (Mujeres · Hombres · Personajes).
     enCuento = las principales del panel (2 + 2 + Librín y Librón); si no, la lista de Opciones (5 + 5 + personajes) */
  function listaVoces(enCuento){
    const G=enCuento?AudioVoces.cuento():AudioVoces.opciones(),act=AudioVoces.actual();
    let h=AudioVoces.faltante()?`<p class="ap-aviso">${T.faltante}</p>`:'';
    if(!AudioVoces.lista().length)return h+`<p class="ap-vacio">${AudioVoces.cargadas()?T.sinVoces:T.buscando}</p>`;
    const falta=!enCuento&&AudioVoces.faltaGenero();
    if(falta)h+=`<p class="ap-nota">${T.sinGenero(falta)}</p>`;
    for(const g of G){
      h+=`<div class="ap-col ap-col-${g.id}" role="presentation"><div class="ap-grupo">${g.titulo}</div>${g.items.map(x=>fila(x,!!act&&act.id===x.id,!enCuento)).join('')}</div>`;
    }
    return h;
  }

  /* Chips de velocidad (Normal / Lenta) */
  function ritmos(){
    const r=AudioVoces.ritmo();
    return C.ritmos.map(s=>`<button class="chip ap-est${s.id===r.id?' on':''}" role="radio" aria-checked="${s.id===r.id}" tabindex="${s.id===r.id?0:-1}" data-audio="ritmo" data-id="${s.id}"><span aria-hidden="true">${s.emoji}</span> ${s.nombre}</button>`).join('');
  }

  /* Panel desplegable del reproductor (se agrega al <body>, así no lo corta la tarjeta del cuento) */
  function panel(){
    return `<div class="ap-panel" data-audio-panel role="dialog" aria-label="${T.panelTitulo}">
      <div class="ap-panel-top"><b>${T.panelTitulo}</b><button class="ap-b" data-audio="cerrar" aria-label="${T.cerrar}" title="${T.cerrar}">${ic('x',18)}</button></div>
      <div class="ap-voces" role="radiogroup" aria-label="Voces" data-audio-voces data-cuento>${listaVoces(true)}</div>
      <div class="ap-sub">${T.velocidad}</div>
      <div class="chips ap-estilos" role="radiogroup" aria-label="${T.velocidad}" data-audio-ritmos>${ritmos()}</div>
      <button class="ap-mas-link" data-a="nav" data-to="settings">${T.masEnOpciones} ${ic('right',14)}</button>
    </div>`;
  }

  /* ---------- Texto sincronizado ----------
     Arma el texto del cuento con cada palabra en un <span data-i="…"> (la letra donde
     empieza en el texto que lee la voz), así el controlador la puede pintar mientras se lee.
     Las palabras del vocabulario {palabra|definición} siguen siendo botones, como en vocab(). */
  function textoSincronizado(raw){
    const re=/\{([^|}]+)\|([^}]+)\}/g;let h='',i=0,base=0,m;
    const pal=Audiolibro.palabra(); // si se vuelve a dibujar a mitad de la lectura, sale ya pintado
    const clase=n=>!pal?'w':n<pal.ini?'w leido':n<pal.fin?'w actual':'w';
    const envolver=(t,b)=>t.replace(/\S+/g,(w,k)=>`<span class="${clase(b+k)}" data-i="${b+k}">${ESC(w)}</span>`);
    while((m=re.exec(raw))){
      const antes=raw.slice(i,m.index);
      h+=envolver(antes,base);base+=antes.length;
      h+=`<button class="vocab" data-a="def" data-w="${ESC(m[1])}" data-d="${ESC(m[2])}">${envolver(m[1],base)}</button>`;
      base+=m[1].length;i=m.index+m[0].length;
    }
    return PARRAFOS(h+envolver(raw.slice(i),base)); // los saltos de párrafo son espacios: no cambian las posiciones
  }

  /* ---------- Reproductor de la pantalla de lectura ---------- */
  function reproductor(clave,texto){
    Audiolibro.preparar(clave,texto);
    const i=Audiolibro.info(),p=principal(i.estado),ya=mmss(i.seg),tot=mmss(i.total),bv=botonVoz();
    return `<section class="ap${i.estado==='sonando'?' sonando':''}" data-audio-player aria-label="${T.titulo}">
      <div class="ap-ctrl">
        <button class="ap-b" data-audio="reiniciar" aria-label="${T.reiniciar}" title="${T.reiniciar}"${i.estado==='listo'?' disabled':''}>${ic('inicio',18,true)}</button>
        <button class="ap-b" data-audio="atras" aria-label="${T.atras(C.salto)}" title="${T.atras(C.salto)}"${i.puedeAtras?'':' disabled'}>${ic('atras',24)}</button>
        <button class="ap-play" data-audio="tocar" data-e="${i.estado}" aria-label="${p.txt}">${p.html}</button>
        <button class="ap-b" data-audio="adelante" aria-label="${T.adelante(C.salto)}" title="${T.adelante(C.salto)}"${i.puedeAdelante?'':' disabled'}>${ic('adelante',24)}</button>
      </div>
      <div class="ap-prog">
        <span class="ap-t" data-audio-ya>${ya}</span>
        <div class="ap-bar" role="progressbar" aria-label="${T.avance}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(i.pct)}" aria-valuetext="${T.tiempo(ya,tot)}"><i style="width:${i.pct}%"></i></div>
        <span class="ap-t" data-audio-tot>${tot}</span>
      </div>
      ${volumen(false)}
      <button class="ap-vozbtn" data-audio="panel" aria-haspopup="dialog" aria-expanded="false" aria-label="${ESC(bv.lbl)}" title="${ESC(bv.lbl)}">${bv.html}</button>
    </section>`;
  }

  /* ---------- Opciones ---------- */
  function opcionesVoz(){
    return `<section class="set"><h4>Voz del audiolibro</h4><p>Toca una voz para escucharla y elegirla. En cada cuento aparecen las principales, con Librín y Librón.</p>
      <div class="ap-voces grande" role="radiogroup" aria-label="Voces" data-audio-voces>${listaVoces(false)}</div>
      <h4 class="ap-h">${T.velocidad} de lectura</h4><p>Sirve para cualquier voz.</p>
      <div class="chips" role="radiogroup" aria-label="${T.velocidad}" data-audio-ritmos>${ritmos()}</div>
      <details class="ap-mas"><summary>${T.masVoces}</summary><p>${T.masVocesDet}</p></details></section>`;
  }
  function opciones(){
    return `<section class="set"><h4>Volumen de la voz</h4><p>También puedes cambiarlo mientras escuchas un cuento.</p>
      <div class="ap-opc">${volumen(true)}<button class="btn ghost ap-probar" data-audio="probar">${ic('vol',18)} ${T.probar}</button></div></section>`;
  }

  return {reproductor,opciones,opcionesVoz,principal,mmss,iconoVol,botonVoz,listaVoces,ritmos,panel,textoSincronizado};
})();
