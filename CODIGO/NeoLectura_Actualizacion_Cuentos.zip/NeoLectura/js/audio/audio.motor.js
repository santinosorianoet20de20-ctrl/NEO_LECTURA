/* =====================  AUDIOLIBRO · MOTOR  =====================
   Lee el cuento con la voz del navegador (Web Speech API).

   El problema: la API solo sabe "hablar" y "cancelar". No tiene barra de
   tiempo, no deja adelantar ni retroceder y no cambia el volumen mientras
   habla. Por eso el motor hace esto:
   - Corta el texto en frases y las lee de a una. Así Chrome no corta la voz
     a los ~15 segundos (le pasa con algunas voces si el texto es largo).
   - Guarda la posición como "la letra por la que va" y la pasa a segundos
     con una velocidad estimada (letras por segundo). Las comas cuentan como
     unas letras más, porque la voz hace una pausita. Esa velocidad se ajusta
     sola midiendo cuánto tarda la voz de verdad en cada frase.
   - Si el navegador avisa por qué palabra va (evento "boundary"), se usa ese
     dato y el texto se pinta exacto; si no, se calcula con el reloj.
   - Pausar = cancelar y recordar la palabra. Reanudar = volver a hablar
     desde esa palabra. Funciona igual en todos los navegadores
     (speechSynthesis.pause() falla en Chrome de Android).
   - Retroceder / adelantar = mover la posición unos segundos y volver a hablar.
   - Cambiar el volumen, la voz o la velocidad mientras suena = seguir desde la
     misma palabra con el cambio aplicado. Si no está sonando, la voz nueva
     saluda con una frase corta (sin perder por dónde iba el cuento).
   Las voces se eligen en audio.voces.js.
   Estados: 'listo' (sin empezar) · 'sonando' · 'pausa' · 'fin'.            */
const Audiolibro=(()=>{
  const C=AUDIO_CFG,T=C.textos;
  const ss=canSpeak?window.speechSynthesis:null;

  let clave='',texto='';   // qué parte del cuento está cargada y su texto
  let frases=[];           // [{ini,fin}] dónde empieza y termina cada frase
  let palabras=[];         // dónde empieza cada palabra (para no cortar palabras a la mitad)
  let V=[0];               // V[i] = "largo de lectura" hasta la letra i (cada letra 1, las comas un poco más)
  let estado='listo';
  let pos=0;               // letra por la que va (cuando no está sonando)
  const calib={};          // letras por segundo de cada voz a velocidad 1 (se mide mientras habla)
  let turno=0;             // sube cada vez que se cancela: los eventos de voces viejas se ignoran
  let actual=null;         // frase que está sonando: {u, ini, fin, t0, ancla, tAncla, exacto}
  let prueba=null,tReloj=0,tVol=0,quieto=0;
  let oyente=()=>{};       // la vista se anota acá para enterarse de los cambios
  const escuchas=[];       // otros módulos (Librín compañero) que quieren saber qué pasa: empieza, pausa, mitad, fin
  let mitadDicha=false;
  const emitir=(ev,datos)=>escuchas.forEach(fn=>{try{fn(ev,datos||{})}catch(e){}});

  /* ---------- Voz ---------- */
  const idVoz=()=>{const x=AudioVoces.actual();return x?x.id:'*'};
  /* Velocidad final = la de la app × la elegida (Normal/Lenta) × la del personaje */
  const vel=()=>{const x=AudioVoces.actual();return C.velocidad*AudioVoces.ritmo().vel*(x&&x.personaje?x.personaje.vel:1)};
  /* Letras por segundo con la voz y la velocidad de ahora (cada voz habla a su ritmo) */
  const lps=()=>(calib[idVoz()]||C.letrasPorSegundo)*vel();

  function crearVoz(t){
    const x=AudioVoces.actual();
    const u=new SpeechSynthesisUtterance(t);
    u.lang=x&&x.v?x.v.lang:C.idioma;if(x&&x.v)u.voice=x.v;
    u.rate=vel();u.pitch=x&&x.personaje?x.personaje.tono:1;
    u.volume=typeof S.vol==='number'?Math.max(0,Math.min(1,S.vol)):C.volumenInicial;
    return u;
  }

  /* ---------- Texto ---------- */
  function cortarFrases(t){
    const res=[],re=/[.!?…]+["'»”)\]]*\s+/g;let ini=0,m;
    while((m=re.exec(t))){const fin=m.index+m[0].length;res.push({ini,fin});ini=fin}
    if(ini<t.length)res.push({ini,fin:t.length});
    // Las frases muy largas se parten en la coma (o el espacio) más cercana a la mitad
    const partir=f=>{
      if(f.fin-f.ini<=C.maxLetras)return [f];
      const medio=(f.ini+f.fin)/2,trozo=t.slice(f.ini,f.fin);let corte=-1,dist=1e9;
      trozo.replace(/[,;:]\s+/g,(x,i)=>{const c=f.ini+i+x.length;if(Math.abs(c-medio)<dist){dist=Math.abs(c-medio);corte=c}});
      if(corte<0)trozo.replace(/\s+/g,(x,i)=>{const c=f.ini+i+x.length;if(Math.abs(c-medio)<dist){dist=Math.abs(c-medio);corte=c}});
      if(corte<=f.ini||corte>=f.fin)return [f];
      return partir({ini:f.ini,fin:corte}).concat(partir({ini:corte,fin:f.fin}));
    };
    return res.reduce((a,f)=>a.concat(partir(f)),[]);
  }
  function armarLargos(t){
    V=[0];
    for(let i=0;i<t.length;i++)V.push(V[i]+1+(C.pausas.test(t[i])?C.pesoPausa:0));
  }
  /* La letra a la que se llega con cierto "largo de lectura" (búsqueda binaria en V) */
  function letraDe(v){
    let lo=0,hi=texto.length;
    while(lo<hi){const m=(lo+hi+1)>>1;if(V[m]<=v)lo=m;else hi=m-1}
    return lo;
  }
  /* Comienzo de la palabra en la que cae la letra p */
  function inicioPalabra(p){
    let r=0;
    for(const w of palabras){if(w<=p)r=w;else break}
    return r;
  }
  function finPalabra(i){
    while(i<texto.length&&!/\s/.test(texto[i]))i++;
    return i;
  }

  /* ---------- Posición ---------- */
  function posicion(){
    if(estado!=='sonando'||!actual||!actual.t0)return pos;
    const seg=(performance.now()-actual.tAncla)/1000;
    return Math.min(letraDe(V[actual.ancla]+seg*lps()),actual.fin);
  }
  /* Letra para pintar el texto: si la voz avisa por qué palabra va, esa; si no, la estimada */
  function letraLeida(){
    if(estado==='sonando'&&actual&&actual.exacto)return actual.ancla;
    return posicion();
  }
  /* Ajusta las letras por segundo de la voz con lo que tardó una frase de verdad */
  function calibrar(a,seg){
    const largo=V[a.fin]-V[a.ini];
    if(largo<20||seg<.4)return;
    const medida=largo/seg/vel(),k=idVoz(); // se guarda "a velocidad 1" para que sirva con cualquier velocidad
    if(medida>4&&medida<40)calib[k]=(calib[k]||C.letrasPorSegundo)*.6+medida*.4;
  }

  /* ---------- Reproducción ---------- */
  function cortar(){
    turno++;actual=null;quieto=0;clearTimeout(tVol);
    let habia=false;
    if(ss&&(ss.speaking||ss.pending)){habia=true;try{ss.cancel()}catch(e){}}
    return habia;
  }
  function sonarDesde(p){
    const habia=cortar(),n=turno,antes=estado;
    if(p===0)mitadDicha=false;
    pos=p;estado='sonando';avisar();
    if(antes!=='sonando')emitir('suena',{antes,desdeCero:p===0});
    const ir=()=>{if(n===turno)hablar(p,n)};
    // La primera vez se habla en el mismo clic (Safari de iPhone lo exige);
    // si se acaba de cancelar otra voz, se espera un instante.
    if(habia)setTimeout(ir,C.pausaCancelar);else ir();
  }
  function hablar(p,n){
    if(n!==turno||estado!=='sonando')return;
    let k=frases.findIndex(f=>p<f.fin);
    while(k>-1&&k<frases.length&&!texto.slice(Math.max(p,frases[k].ini),frases[k].fin).trim()){p=frases[k].fin;k++} // trozos vacíos
    if(k<0||k>=frases.length){terminar();return}
    const f=frases[k],ini=Math.max(p,f.ini);
    const u=crearVoz(texto.slice(ini,f.fin));
    const a={u,ini,fin:f.fin,t0:0,ancla:ini,tAncla:0,exacto:false};
    actual=a;pos=ini;quieto=0; // se guarda la voz en "actual" para que Chrome no la borre a mitad de camino
    const vigente=()=>n===turno&&actual===a;
    u.onstart=()=>{if(!vigente())return;a.t0=a.tAncla=performance.now();avisar()};
    u.onboundary=e=>{
      if(!vigente()||!a.t0||(e.name&&e.name!=='word'))return;
      a.ancla=Math.min(ini+e.charIndex,a.fin);a.tAncla=performance.now();a.exacto=true;
      oyente('palabra'); // pinta la palabra nueva enseguida
    };
    u.onend=()=>{if(vigente())finFrase(a,n)};
    u.onerror=e=>{if(vigente())fallo(e&&e.error)};
    try{ss.speak(u)}catch(e){fallo('synthesis-failed')}
  }
  function finFrase(a,n){
    if(a.t0)calibrar(a,(performance.now()-a.t0)/1000);
    actual=null;pos=a.fin;
    hablar(a.fin,n);
  }
  function terminar(){cortar();pos=texto.length;estado='fin';avisar();emitir('fin')}
  function fallo(tipo){
    pos=inicioPalabra(letraLeida());cortar();
    estado=pos>0?'pausa':'listo';avisar();
    if(tipo!=='interrupted'&&tipo!=='canceled'&&typeof toast==='function')toast(T.error);
  }

  /* Reloj: mueve la barra, pinta el texto y vigila que la voz no se haya quedado muda sin avisar */
  function reloj(on){
    if(on&&!tReloj)tReloj=setInterval(tic,C.cadaMs);
    else if(!on&&tReloj){clearInterval(tReloj);tReloj=0}
  }
  function tic(){
    if(estado!=='sonando'){reloj(false);return}
    if(actual&&actual.t0&&!ss.speaking&&!ss.pending){
      if(++quieto>=C.ticsSinVoz)finFrase(actual,turno);
    }else quieto=0;
    if(!mitadDicha&&V[posicion()]>=V[texto.length]/2){mitadDicha=true;emitir('mitad')}
    oyente();
  }
  function avisar(){reloj(estado==='sonando');oyente()}

  /* ---------- Lo que usan los botones ---------- */
  /* Carga una parte del cuento. Si es la misma que ya estaba, no la reinicia. */
  function preparar(k,t){
    if(k===clave&&t===texto)return;
    cortar();reloj(false);
    clave=k;texto=t;frases=cortarFrases(t);armarLargos(t);
    palabras=[];t.replace(/\S+/g,(w,i)=>{palabras.push(i)});
    pos=0;estado='listo';mitadDicha=false;
  }
  /* Botón principal: Escuchar → Pausar → Reanudar (y "Otra vez" al terminar) */
  function tocar(){
    if(!ss||!texto)return;
    if(estado==='sonando')pausar();
    else sonarDesde(estado==='fin'?0:pos);
  }
  function pausar(){
    if(estado!=='sonando')return;
    pos=inicioPalabra(letraLeida());cortar();
    estado='pausa';avisar();emitir('pausa');
  }
  function reiniciar(){if(ss&&texto)sonarDesde(0)}
  /* Mueve la posición "seg" segundos (negativo = retroceder) */
  function saltar(seg){
    if(!ss||!texto)return;
    const v=V[letraLeida()]+seg*lps();
    if(v>=V[texto.length]-1){if(estado!=='fin')terminar();return}
    const d=inicioPalabra(letraDe(Math.max(0,v)));
    if(estado==='sonando')sonarDesde(d);
    else{pos=d;estado=d>0?'pausa':'listo';avisar()}
  }
  /* Sigue desde la palabra actual (para aplicar volumen, voz o velocidad nuevos) */
  const seguirAqui=()=>{if(estado==='sonando')sonarDesde(inicioPalabra(letraLeida()))};

  /* Volumen de 0 a 1. Si está sonando, se aplica desde la palabra actual */
  function volumen(v){
    S.vol=Math.max(0,Math.min(1,v));save();
    if(estado!=='sonando')return;
    clearTimeout(tVol);
    tVol=setTimeout(seguirAqui,C.esperaVolumen);
  }
  /* Voz (o personaje) y velocidad. Si está sonando se nota enseguida;
     si no, la voz saluda para que se escuche cómo es. */
  function cambiarVoz(id){
    S.voz=id||'';save();
    if(estado==='sonando')seguirAqui();else saludo();
  }
  function cambiarRitmo(id){
    if(!C.ritmos.some(r=>r.id===id))return;
    S.ritmo=id;save();
    if(estado==='sonando')seguirAqui();else saludo();
  }
  /* Frase corta con la voz de ahora (botón "Probar" y al elegir una voz).
     No toca por dónde iba el cuento. */
  function saludo(){
    if(!ss||estado==='sonando')return;
    const x=AudioVoces.actual();
    const t=x&&x.personaje?x.personaje.saludo:AudioVoces.conNombre(x)?T.saludoNombre(x.nombre):T.saludo;
    const habia=ss.speaking||ss.pending;
    if(habia){try{ss.cancel()}catch(e){}}
    const n=++turno; // así ninguna voz anterior del cuento puede seguir
    const ir=()=>{if(n!==turno)return;prueba=crearVoz(t);try{ss.speak(prueba)}catch(e){}};
    if(habia)setTimeout(ir,C.pausaCancelar);else ir();
  }
  /* Corta todo (al cambiar de pantalla, volver o cerrar sesión) */
  function detener(){
    cortar();reloj(false);
    clave='';texto='';frases=[];palabras=[];V=[0];pos=0;estado='listo';
    oyente('detener'); // avisa que se sale de la pantalla (la vista cierra el panel de voces)
  }
  function info(){
    const p=posicion(),L=texto.length,r=lps();
    return {
      estado,
      seg:V[p]/r, total:V[L]/r,
      pct:L?Math.min(100,V[p]/V[L]*100):0,
      puedeAtras:p>0,
      puedeAdelante:estado!=='fin'&&L>0
    };
  }
  /* Palabra que se está leyendo, para pintar el texto: {ini, fin} (letras).
     null = todavía no empezó. Al terminar, ini = fin = largo del texto (todo leído). */
  function palabra(){
    if(!texto||estado==='listo')return null;
    if(estado==='fin')return {ini:texto.length,fin:texto.length};
    const ini=inicioPalabra(letraLeida());
    return {ini,fin:finPalabra(ini)};
  }

  /* ---------- Arranque ---------- */
  if(ss){
    try{ss.cancel()}catch(e){} // Chrome a veces sigue hablando después de recargar la página
    window.addEventListener('pagehide',()=>{try{ss.cancel()}catch(e){}});
  }

  return {
    disponible:!!ss,
    preparar,tocar,pausar,reiniciar,saltar,volumen,cambiarVoz,cambiarRitmo,detener,info,palabra,
    probar:saludo,
    alCambiar:fn=>{oyente=fn||(()=>{})},
    alEvento:fn=>{escuchas.push(fn)} // 'suena' {antes, desdeCero} · 'pausa' · 'mitad' · 'fin'
  };
})();
