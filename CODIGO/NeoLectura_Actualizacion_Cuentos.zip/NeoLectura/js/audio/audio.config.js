/* =====================  AUDIOLIBRO · CONFIGURACIÓN  =====================
   Reproductor de la pantalla de lectura: Escuchar / Pausar / Reanudar,
   Reiniciar, retroceder y adelantar unos segundos, volumen, voz y velocidad.
   Mientras suena, el texto se va pintando de azul palabra por palabra.
   Usa la voz del navegador (Web Speech API), así que no hacen falta
   archivos de audio: cualquier cuento nuevo ya se puede escuchar.
   **Para cambiar cuántos segundos salta, cuántas voces se muestran o
   cómo suenan Librín y Librón, se cambia acá.** */
const AUDIO_CFG={
  salto:5,              // segundos que retroceden / adelantan los botones
  velocidad:.9,         // velocidad de la voz (1 = normal). Era la que ya usaba la app
  idioma:'es-AR',       // idioma pedido a la voz si no se encuentra una en español
  volumenInicial:1,     // volumen de las cuentas nuevas (0 a 1)

  /* Cuántas voces se muestran */
  vocesOpciones:5,      // en Opciones: hasta 5 de mujer y 5 de hombre (+ los personajes)
  vocesCuento:2,        // en el cuento: 2 de mujer y 2 de hombre (+ los personajes de abajo)
  personajesCuento:['librin','libron'], // los personajes que aparecen en el cuento, para cambiar entre Librín y Librón ahí mismo

  /* Personajes: voces propias armadas sobre una voz del equipo, cambiándole el tono.
     base: 'f' = sobre una voz de mujer, 'm' = sobre una de hombre.
     tono: 1 = normal (0 a 2) · vel: se multiplica por "velocidad" de arriba.
     Algunas voces ignoran el tono (con esas solo cambia la velocidad). */
  personajes:[
    {id:'librin', nombre:'Librín', emoji:'📘',img:'img/librin/saludo.png',base:'f',tono:1.65,vel:1.05,
     det:'Aguda y divertida',saludo:'¡Hola, hola! Soy Librín. ¡Vamos a leer juntos!'},
    {id:'libron', nombre:'Librón', emoji:'📚',img:'img/libron/saludo.png',base:'m',tono:.7,vel:.88,
     det:'Grave y tranquila',saludo:'Hola, soy Librón. Ponte cómodo, que empieza el cuento.'}
  ],

  /* Velocidad de lectura (sirve para cualquier voz) */
  ritmos:[
    {id:'normal',nombre:'Normal',emoji:'🙂',vel:1},
    {id:'lenta', nombre:'Lenta', emoji:'🐢',vel:.8}
  ],

  /* Países en el orden en que se prefieren sus voces (los que no están van antes de España) */
  paises:['ar','uy','419','mx','us','co','cl','pe','py','bo','ve','ec','cr','pa','gt','hn','sv','ni','do','cu','pr','gq','es'],

  /* Cosas técnicas (no hace falta tocarlas) */
  letrasPorSegundo:15,  // estimación inicial a velocidad 1; después se ajusta sola con la voz real
  pesoPausa:3,          // una coma "dura" como 3 letras más (la voz hace una pausita)
  pausas:/[,;:—–]/,     // signos donde la voz hace esa pausita
  maxLetras:160,        // las frases más largas se cortan en dos (Chrome corta algunas voces a los ~15 s)
  pausaCancelar:60,     // ms entre cancelar la voz y volver a hablar (evita que Chrome se trabe)
  esperaVolumen:350,    // ms que espera después de mover el volumen para aplicarlo a la voz
  cadaMs:100,           // cada cuánto se actualizan la barra y el texto pintado mientras suena
  ticsSinVoz:12,        // 12 × 100 ms sin voz → la frase se da por terminada (por si el navegador no avisa)

  textos:{
    titulo:'Audiolibro',
    escuchar:'Escuchar',
    pausar:'Pausar',
    reanudar:'Reanudar',
    otraVez:'Otra vez',
    reiniciar:'Reiniciar desde el principio',
    atras:n=>`Retroceder ${n} segundos`,
    adelante:n=>`Adelantar ${n} segundos`,
    avance:'Avance del audio',
    tiempo:(a,b)=>`${a} de ${b}`,
    volumen:'Volumen',
    silenciar:'Silenciar',
    activar:'Activar sonido',
    probar:'Probar',
    error:'No se pudo reproducir el audio 😕',

    /* Voces */
    elegirVoz:n=>`Elegir voz (ahora: ${n})`,
    panelTitulo:'Voz del audiolibro',
    mujeres:'Mujeres',
    hombres:'Hombres',
    otras:'Otras voces',
    personaje:'Personaje',
    personajes:'Personajes',
    velocidad:'Velocidad',
    natural:'Natural',
    online:'Necesita internet',
    buscando:'Buscando voces…',
    sinVoces:'Este equipo no tiene voces en español instaladas. Se usa la voz que venga por defecto.',
    faltante:'La voz que elegiste no está en este equipo, así que se usa otra.',
    sinGenero:g=>`Este equipo no tiene voces de ${g} en español.`,
    cerrar:'Cerrar',
    masEnOpciones:'Más voces en Opciones',
    saludoNombre:n=>`¡Hola! Soy ${n}. Así voy a leer los cuentos.`,
    saludo:'¡Hola! Así voy a leer los cuentos.',
    masVoces:'¿Quieres más voces?',
    masVocesDet:'Las voces vienen del navegador y del equipo, no de NeoLectura. Microsoft Edge trae muchas voces naturales en español (también de Argentina). En Windows se pueden agregar desde Configuración → Hora e idioma → Voz, y en el celular desde los ajustes de "Texto a voz".'
  }
};
