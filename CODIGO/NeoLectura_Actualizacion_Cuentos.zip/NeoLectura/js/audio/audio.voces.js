/* =====================  AUDIOLIBRO · VOCES  =====================
   Arma la lista de voces en español que tiene este equipo, con nombres
   fáciles de leer ("Elena · Argentina"), las separa en mujeres y hombres,
   y suma los personajes (Librín y Librón), que son voces propias armadas
   sobre una voz del equipo con otro tono.

   Las voces NO vienen con NeoLectura: las pone el navegador o el sistema.
   Por eso la lista cambia según el equipo (Edge trae muchas voces
   "naturales"; Chrome trae las de Google y las del sistema; el celular,
   las de su motor de texto a voz). El navegador tampoco dice si una voz es
   de mujer o de hombre: se adivina por el nombre (Elena, Tomás…).

   Se guarda en cada usuario: S.voz (id de la voz, 'personaje:librin'…,
   o '' = la primera de la lista) y S.ritmo ('normal' o 'lenta').          */
const AudioVoces=(()=>{
  const C=AUDIO_CFG;
  const ss=canSpeak?window.speechSynthesis:null;
  let lista=[];          // voces en español, ordenadas de mejor a peor: {id, nombre, pais, genero, natural, local, v}
  let cargadas=false;    // el navegador ya devolvió alguna voz (de cualquier idioma)
  let firma='';          // para saber si la lista cambió de verdad
  const oyentes=[];

  const PAISES={ar:'Argentina',bo:'Bolivia',cl:'Chile',co:'Colombia',cr:'Costa Rica',cu:'Cuba',do:'República Dominicana',
    ec:'Ecuador',es:'España',gq:'Guinea Ecuatorial',gt:'Guatemala',hn:'Honduras',mx:'México',ni:'Nicaragua',pa:'Panamá',
    pe:'Perú',pr:'Puerto Rico',py:'Paraguay',sv:'El Salvador',us:'Estados Unidos',uy:'Uruguay',ve:'Venezuela','419':'Latinoamérica'};

  /* Nombres de voces conocidas (Windows, Edge, Mac, iPhone…) para saber si son de mujer o de hombre */
  const MUJERES=new Set(('elena sofia catalina salome maria belkys ramona andrea elvira ximena teresa marta karla dalia yolanda '+
    'margarita camila karina tania lorena paloma valentina paola helena laura sabina monica paulina angelica francisca soledad '+
    'marisol isabela isabel carmen lucia beatriz candela carlota larissa marina nuria renata abril estrella irene laia lia triana '+
    'vera flo sandy shelley abuela grandma esperanza ana rosa luciana victoria julia sara susana penelope lupe mia jimena alba '+
    'elsa ines lola silvia raquel gabriela daniela fernanda mariana natalia patricia').split(' '));
  const HOMBRES=new Set(('tomas marcelo lorenzo gonzalo juan manuel emilio luis alvaro javier andres carlos jorge federico '+
    'roberto alex victor mario rodrigo alonso mateo sebastian pablo raul diego cecilio gerardo liberto luciano pelayo yago arnau '+
    'dario elias nil saul teo eddy reed rocko abuelo grandpa enrique miguel jose antonio felipe hector ricardo santiago martin '+
    'jaime ivan oscar hugo daniel eduardo fernando francisco gabriel ignacio joaquin julio lucas marcos nicolas rafael sergio '+
    'jordi alberto esteban guillermo xavier jesus ruben ramon').split(' '));
  /* Los nombres de Microsoft vienen sin tilde: "Tomas" → "Tomás" */
  const TILDES={tomas:'Tomás',salome:'Salomé',alvaro:'Álvaro',sebastian:'Sebastián',andres:'Andrés',ramon:'Ramón',raul:'Raúl',
    victor:'Víctor',maria:'María',sofia:'Sofía',lucia:'Lucía',angelica:'Angélica',monica:'Mónica',dario:'Darío',elias:'Elías',
    saul:'Saúl',ines:'Inés',nicolas:'Nicolás',martin:'Martín',joaquin:'Joaquín',hector:'Héctor',ivan:'Iván',oscar:'Óscar',
    jose:'José',ruben:'Rubén',jesus:'Jesús',belen:'Belén'};

  const sinTildes=s=>String(s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase();
  const region=lang=>(String(lang||'').replace(/_/g,'-').split('-')[1]||'').toLowerCase();
  const esEspanol=lang=>/^es([-_]|$)/i.test(String(lang||''));
  function ordenPais(r){const i=C.paises.indexOf(r);return i<0?C.paises.length-1.5:i} // los que no están, antes de España

  /* "Microsoft Elena Online (Natural) - Spanish (Argentina)" → "Elena" */
  function nombreCorto(v){
    const n=String(v.name||'').trim();
    const ms=n.match(/^Microsoft\s+(.+?)(?:\s+Online)?(?:\s+\(Natural\))?\s+-\s/i);
    if(ms)return ms[1].trim();
    if(/^Google\b/i.test(n))return 'Google';
    const limpio=n.replace(/\s*\(.*$/,'').replace(/\s+-\s+.*$/,'').trim();
    // Nombres técnicos (los de Android, por ejemplo "es-us-x-esc-local") no sirven para mostrar
    if(!limpio||limpio.length>22||/^[a-z]{2,3}[-_][a-z0-9]{2,4}\b/i.test(limpio)||/[-_]x[-_]/i.test(limpio))return '';
    return limpio;
  }
  const conTilde=n=>{const k=sinTildes(n);return TILDES[k]||n};

  /* 'f' (mujer), 'm' (hombre) o '' (no se sabe) */
  function genero(corto,completo){
    const c=sinTildes(completo);
    if(/\b(female|mujer|femenin)/.test(c))return 'f';
    if(/\b(male|hombre|masculin)/.test(c))return 'm';
    if(/^google\b/.test(c))return 'f'; // las voces de Google en español son de mujer
    const p=sinTildes(corto).split(/\s+/)[0];
    return MUJERES.has(p)?'f':HOMBRES.has(p)?'m':'';
  }

  function refrescar(){
    if(!ss)return;
    let todas=[];try{todas=ss.getVoices()||[]}catch(e){}
    if(todas.length)cargadas=true;
    const vistas={},nueva=[];
    for(const v of todas){
      if(!esEspanol(v.lang))continue;
      const id=v.voiceURI||v.name;if(!id||vistas[id])continue;vistas[id]=1;
      const r=region(v.lang),corto=nombreCorto(v);
      nueva.push({id,nombre:conTilde(corto),pais:PAISES[r]||'Español',orden:ordenPais(r),genero:genero(corto,v.name),
        natural:/natural|neural|premium|enhanced|mejorad|wavenet/i.test(v.name),local:!!v.localService,v});
    }
    // De mejor a peor: país preferido → natural (suena mejor) → instalada (anda sin internet y avisa por qué palabra va) → nombre
    nueva.sort((a,b)=>a.orden-b.orden||(b.natural-a.natural)||(b.local-a.local)||(a.nombre||'~').localeCompare(b.nombre||'~','es'));
    // Las voces sin nombre lindo se numeran por país: "Voz 1 · México"
    const cuenta={};
    nueva.forEach(x=>{if(!x.nombre){cuenta[x.pais]=(cuenta[x.pais]||0)+1;x.nombre='Voz '+cuenta[x.pais]}});
    lista=nueva;
    const f=lista.map(x=>x.id).join('|')+(cargadas?'+':'');
    if(f!==firma){firma=f;oyentes.forEach(fn=>fn())}
  }

  /* ---------- Personajes ---------- */
  /* Para el tono conviene una voz instalada (las de internet a veces ignoran el tono) */
  function vozBase(g){
    const de=lista.filter(x=>x.genero===g);
    const pool=de.length?de:lista;
    return pool.find(x=>x.local)||pool[0]||null;
  }
  function personaje(pid){
    const p=C.personajes.find(x=>x.id===pid);if(!p)return null;
    const b=vozBase(p.base);
    return {id:'personaje:'+p.id,nombre:p.nombre,personaje:p,genero:p.base,pais:'',v:b?b.v:null,base:b};
  }
  const personajes=()=>C.personajes.map(p=>personaje(p.id));

  /* ---------- Elegida ---------- */
  /* Si el usuario venía de una versión anterior, se pasa a lo nuevo:
     estilos Librín/Gigante/Lenta → voces y velocidad; Gigante ahora se llama Librón */
  function migrar(){
    if(S.voz==='personaje:gigante'){S.voz='personaje:libron';save()}
    if(S.estilo===undefined)return;
    if(S.estilo==='librin')S.voz='personaje:librin';
    if(S.estilo==='gigante')S.voz='personaje:libron';
    if(S.estilo==='lenta')S.ritmo='lenta';
    delete S.estilo;save();
  }
  function buscar(id){
    if(!id)return null;
    if(id.indexOf('personaje:')===0)return personaje(id.slice(10));
    return lista.find(x=>x.id===id)||null;
  }
  /* La que se usa ahora: la elegida si está en este equipo; si no, la primera de la lista */
  function actual(){
    migrar();
    if(!lista.length)refrescar();
    return buscar(S.voz)||lista[0]||null;
  }
  const faltante=()=>{migrar();return !!S.voz&&cargadas&&!buscar(S.voz)};
  const conNombre=x=>!!x&&!x.personaje&&x.nombre!=='Google'&&!/^Voz \d/.test(x.nombre);
  function ritmo(){migrar();return C.ritmos.find(r=>r.id===S.ritmo)||C.ritmos[0]}

  /* ---------- Listas que se muestran ---------- */
  /* Arma los grupos: hasta "cuantas" de mujer y de hombre (si faltan de un lado, se completa
     con las que haya), y los personajes (en el cuento, los de "personajesCuento"; en Opciones, todos).
     La voz elegida siempre aparece: si no entraba, ocupa el último lugar de su grupo. */
  function grupos(cuantas,enCuento){
    const T=C.textos,f=[],m=[],o=[],total=cuantas*2;
    lista.forEach(x=>{if(x.genero==='f'&&f.length<cuantas)f.push(x);else if(x.genero==='m'&&m.length<cuantas)m.push(x)});
    for(const x of lista){ // completar si este equipo tiene pocas voces de algún tipo
      if(f.length+m.length+o.length>=total)break;
      if(f.includes(x)||m.includes(x))continue;
      (x.genero==='f'?f:x.genero==='m'?m:o).push(x);
    }
    let pers=enCuento?C.personajesCuento.map(personaje).filter(Boolean):personajes();
    const el=actual();
    if(el){
      const esta=[...f,...m,...o,...pers].some(x=>x.id===el.id);
      if(!esta){
        if(el.personaje)pers[pers.length-1]=el;
        else{const g=el.genero==='f'?f:el.genero==='m'?m:o;if(g.length)g[g.length-1]=el;else g.push(el)}
      }
    }
    if(!lista.length)pers=[]; // sin voces en español no se arman personajes
    return [
      {id:'f',titulo:T.mujeres,items:f},
      {id:'m',titulo:T.hombres,items:m},
      {id:'o',titulo:T.otras,items:o},
      {id:'p',titulo:pers.length===1?T.personaje:T.personajes,items:pers}
    ].filter(g=>g.items.length);
  }
  const opciones=()=>grupos(C.vocesOpciones,false);
  const cuento=()=>grupos(C.vocesCuento,true);
  /* Para avisar en Opciones si no hay voces de mujer o de hombre */
  function faltaGenero(){
    if(!lista.length)return '';
    const f=lista.some(x=>x.genero==='f'),m=lista.some(x=>x.genero==='m');
    return !m?'hombre':!f?'mujer':'';
  }

  if(ss){
    refrescar();
    if(ss.addEventListener)ss.addEventListener('voiceschanged',refrescar);else ss.onvoiceschanged=refrescar;
    setTimeout(()=>{cargadas=true;refrescar()},2500); // por si el navegador nunca avisa que cargó las voces
  }

  return {
    lista:()=>lista, cargadas:()=>cargadas,
    buscar, actual, faltante, conNombre, ritmo, opciones, cuento, faltaGenero, refrescar,
    alCambiar:fn=>{oyentes.push(fn)}
  };
})();
