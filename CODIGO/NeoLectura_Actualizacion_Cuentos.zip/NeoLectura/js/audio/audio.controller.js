/* =====================  AUDIOLIBRO · CONTROLADOR  =====================
   Escucha los botones del reproductor, la barra de volumen y la elección de
   voz y velocidad, y actualiza la pantalla cuando el motor avisa que algo
   cambió (sin volver a dibujar toda la app, así no se pierde el foco ni se
   corta la lectura). También pinta el texto a medida que se lee.
   El panel de voces se agrega al <body>, como las ventanas de racha.        */
const AudioControl=(()=>{
  const C=AUDIO_CFG,T=C.textos;
  let volAntes=C.volumenInicial; // para volver al volumen anterior al quitar el silencio
  let panelEl=null,fondoEl=null,botonEl=null; // panel de voces abierto, su fondo (celular) y el botón que lo abrió
  const esCelular=()=>window.matchMedia&&window.matchMedia('(max-width:480px)').matches;
  const sinMovimiento=()=>window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let textoEl=null,marcaAntes=null; // para no volver a pintar si la palabra no cambió
  let seguir=true,tScroll=0;          // acompañar la lectura con el scroll (se apaga si el usuario se mueve solo)

  /* Actualiza el reproductor con el estado del motor */
  function pintar(){
    const box=document.querySelector('[data-audio-player]');
    if(!box){cerrarPanel(false);return}
    const i=Audiolibro.info(),$=s=>box.querySelector(s);
    const play=$('[data-audio="tocar"]');
    if(play&&play.dataset.e!==i.estado){
      const p=AudioVista.principal(i.estado);
      play.dataset.e=i.estado;play.innerHTML=p.html;play.setAttribute('aria-label',p.txt);
    }
    box.classList.toggle('sonando',i.estado==='sonando');
    $('[data-audio="reiniciar"]').disabled=i.estado==='listo';
    $('[data-audio="atras"]').disabled=!i.puedeAtras;
    $('[data-audio="adelante"]').disabled=!i.puedeAdelante;
    const ya=AudioVista.mmss(i.seg),tot=AudioVista.mmss(i.total),bar=$('.ap-bar');
    $('[data-audio-ya]').textContent=ya;
    $('[data-audio-tot]').textContent=tot;
    bar.firstElementChild.style.width=i.pct+'%';
    bar.setAttribute('aria-valuenow',Math.round(i.pct));
    bar.setAttribute('aria-valuetext',T.tiempo(ya,tot));
    pintarTexto(i.estado);
  }

  /* Pinta el texto: las palabras ya leídas en azul y la que se está leyendo resaltada.
     Si la palabra se va de la pantalla (letra grande, celular), la acompaña con el scroll,
     salvo que el usuario haya movido la pantalla él mismo para mirar otra parte. */
  function pintarTexto(estado){
    const box=document.querySelector('[data-audio-texto]');if(!box)return;
    const w=Audiolibro.palabra(),marca=w?w.ini+':'+w.fin:'-';
    if(box===textoEl&&marca===marcaAntes)return;
    textoEl=box;marcaAntes=marca;
    box.querySelectorAll('.w').forEach(s=>{
      const i=+s.dataset.i;
      s.classList.toggle('leido',!!w&&i<w.ini);
      s.classList.toggle('actual',!!w&&i>=w.ini&&i<w.fin);
    });
    if(estado==='sonando'&&seguir&&Date.now()-tScroll>600){
      const a=box.querySelector('.w.actual');
      if(a&&!seVe(a)){tScroll=Date.now();a.scrollIntoView({block:'center',behavior:sinMovimiento()?'auto':'smooth'})}
    }
  }
  /* Si el usuario mueve la pantalla (rueda, dedo o teclado) mientras escucha, se deja de acompañar.
     Vuelve a acompañar cuando toca un botón del reproductor. */
  const dejarDeSeguir=()=>{seguir=false};
  window.addEventListener('wheel',dejarDeSeguir,{passive:true});
  window.addEventListener('touchmove',dejarDeSeguir,{passive:true});
  window.addEventListener('keydown',e=>{if(/^(Arrow(Up|Down)|Page(Up|Down)|Home|End| )$/.test(e.key)&&!e.target.closest('[data-audio-player],[data-audio-panel],input,button'))seguir=false});
  function seVe(el){
    const r=el.getBoundingClientRect(),hdr=document.querySelector('.hdr');
    const arriba=hdr?hdr.getBoundingClientRect().bottom:0;
    return r.top>=arriba+4&&r.bottom<=window.innerHeight-4;
  }

  /* Actualiza todas las barras de volumen que haya en pantalla */
  function pintarVolumen(){
    const v=Math.round((typeof S.vol==='number'?S.vol:C.volumenInicial)*100),mudo=v===0;
    document.querySelectorAll('.ap-vol').forEach(box=>{
      const r=box.querySelector('[data-audio-vol]'),b=box.querySelector('[data-audio="mudo"]'),o=box.querySelector('[data-audio-pct]');
      if(r){if(+r.value!==v)r.value=v;r.style.setProperty('--v',v+'%');r.setAttribute('aria-valuetext',v+'%')}
      if(b){
        const lbl=mudo?T.activar:T.silenciar,grande=box.classList.contains('grande');
        b.innerHTML=ic(AudioVista.iconoVol(v/100),grande?22:18);
        b.setAttribute('aria-label',lbl);b.title=lbl;b.classList.toggle('on',mudo);
      }
      if(o)o.textContent=v+'%';
    });
  }

  /* Vuelve a dibujar las listas de voces, las velocidades y el botón de voz del reproductor.
     Si el foco estaba en una opción, lo devuelve a la misma opción. */
  function pintarVoces(){
    const f=document.activeElement,tipo=f&&f.dataset?f.dataset.audio:null;
    const enLista=(tipo==='voz'||tipo==='ritmo')?f.closest('[data-audio-voces],[data-audio-ritmos]'):null;
    document.querySelectorAll('[data-audio-voces]').forEach(el=>{el.innerHTML=AudioVista.listaVoces(el.hasAttribute('data-cuento'))});
    document.querySelectorAll('[data-audio-ritmos]').forEach(el=>{el.innerHTML=AudioVista.ritmos()});
    const b=document.querySelector('[data-audio="panel"]');
    if(b){const bv=AudioVista.botonVoz();b.innerHTML=bv.html;b.setAttribute('aria-label',bv.lbl);b.title=bv.lbl}
    if(enLista&&document.body.contains(enLista)){
      const sel=enLista.querySelector(`[data-audio="${tipo}"][aria-checked="true"]`)||enLista.querySelector('[data-audio]');
      if(sel)sel.focus({preventScroll:true});
    }
    if(panelEl)ubicar();
  }

  function cambiarVolumen(v){
    if(v>0)volAntes=v;
    Audiolibro.volumen(v);
    pintarVolumen();
  }

  /* ---------- Panel de voces del reproductor ---------- */
  function abrirPanel(btn){
    cerrarPanel(false);
    // En el celular el panel sube desde abajo, con un fondo oscuro que se toca para cerrar
    fondoEl=document.createElement('div');fondoEl.className='ap-fondo';fondoEl.dataset.audio='cerrar';
    document.body.appendChild(fondoEl);
    const tmp=document.createElement('div');tmp.innerHTML=AudioVista.panel();
    panelEl=tmp.firstElementChild;document.body.appendChild(panelEl);
    botonEl=btn;btn.setAttribute('aria-expanded','true');
    ubicar();
    requestAnimationFrame(()=>{if(panelEl)panelEl.classList.add('ver');if(fondoEl)fondoEl.classList.add('ver')});
    const sel=panelEl.querySelector('[data-audio="voz"][aria-checked="true"]')||panelEl.querySelector('[data-audio="cerrar"]');
    if(sel)sel.focus({preventScroll:true});
    // que la voz elegida se vea sin tener que buscarla (solo si quedó escondida)
    const lista=panelEl.querySelector('.ap-voces'),op=lista&&lista.querySelector('[aria-checked="true"]');
    if(op){
      const arriba=op.offsetTop-lista.offsetTop;
      if(arriba+op.offsetHeight>lista.clientHeight)lista.scrollTop=arriba-(lista.clientHeight-op.offsetHeight)/2;
    }
  }
  /* En compu y tablet lo pone debajo del botón, sin salirse de la pantalla.
     En el celular lo acomoda el CSS (abajo, a todo el ancho). */
  function ubicar(){
    if(!panelEl||!botonEl||!document.body.contains(botonEl))return;
    if(esCelular()){panelEl.style.left=panelEl.style.top=panelEl.style.width='';return}
    const r=botonEl.getBoundingClientRect(),vw=document.documentElement.clientWidth,w=Math.min(340,vw-24);
    const izq=Math.min(Math.max(12,r.right-w),vw-12-w);
    panelEl.style.width=w+'px';
    panelEl.style.left=(izq+window.scrollX)+'px';
    panelEl.style.top=(r.bottom+8+window.scrollY)+'px';
  }
  function cerrarPanel(volverFoco){
    if(!panelEl)return;
    panelEl.remove();panelEl=null;
    if(fondoEl){fondoEl.remove();fondoEl=null}
    if(botonEl){
      botonEl.setAttribute('aria-expanded','false');
      if(volverFoco&&document.body.contains(botonEl))botonEl.focus({preventScroll:true});
    }
    botonEl=null;
  }

  Audiolibro.alCambiar(motivo=>{if(motivo==='detener')cerrarPanel(false);pintar()});
  AudioVoces.alCambiar(pintarVoces); // el navegador cargó (o cambió) sus voces

  /* Eventos */
  document.addEventListener('click',e=>{
    if(panelEl&&!panelEl.contains(e.target)&&!e.target.closest('[data-audio="panel"],.ap-fondo'))cerrarPanel(false); // clic afuera
    const t=e.target.closest('[data-audio]');if(!t||t.disabled)return;
    if(/^(tocar|reiniciar|atras|adelante)$/.test(t.dataset.audio))seguir=true;
    switch(t.dataset.audio){
      case 'tocar':Audiolibro.tocar();break;
      case 'reiniciar':Audiolibro.reiniciar();break;
      case 'atras':Audiolibro.saltar(-C.salto);break;
      case 'adelante':Audiolibro.saltar(C.salto);break;
      case 'mudo':
        if(S.vol>0){volAntes=S.vol;cambiarVolumen(0)}
        else cambiarVolumen(volAntes||C.volumenInicial);
        break;
      case 'probar':Audiolibro.probar();break;
      case 'panel':if(panelEl)cerrarPanel(true);else abrirPanel(t);break;
      case 'cerrar':cerrarPanel(true);break;
      case 'voz':Audiolibro.cambiarVoz(t.dataset.id);pintarVoces();break;
      case 'ritmo':Audiolibro.cambiarRitmo(t.dataset.id);pintarVoces();break;
    }
  });
  document.addEventListener('input',e=>{
    if(e.target.matches&&e.target.matches('[data-audio-vol]'))cambiarVolumen(+e.target.value/100);
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&panelEl){cerrarPanel(true);return}
    // Flechas para moverse entre las opciones de una lista (voces o velocidades)
    const t=e.target;if(!t||!t.getAttribute||t.getAttribute('role')!=='radio')return;
    const g=t.closest('[role="radiogroup"]');if(!g)return;
    const paso={ArrowDown:1,ArrowRight:1,ArrowUp:-1,ArrowLeft:-1}[e.key];
    const ops=[...g.querySelectorAll('[role="radio"]')];
    let i=ops.indexOf(t);
    if(paso)i=Math.min(ops.length-1,Math.max(0,i+paso));
    else if(e.key==='Home')i=0;
    else if(e.key==='End')i=ops.length-1;
    else return;
    e.preventDefault();ops[i].focus();
  });
  window.addEventListener('resize',ubicar);

  return {pintar,pintarVolumen,pintarVoces,cerrarPanel};
})();
