/* =====================  RACHA · LÓGICA  =====================
   Calcula la racha con la fecha local del dispositivo. Los datos se guardan
   dentro del progreso de cada usuario (S.racha), así cada lector tiene la suya.
   S.racha = {dias, ultimo:'AAAA-MM-DD', mejor, historial:['AAAA-MM-DD', …]}  */
const Racha=(()=>{
  const C=RACHA_CFG;

  /* --- Fechas (siempre en hora local, no UTC) --- */
  // De dónde sale la fecha de hoy. Normalmente es la del dispositivo; el módulo de
  // pruebas (js/pruebas/prueba-dia.js) la puede adelantar con usarReloj().
  let reloj=()=>new Date();
  const clave=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  const hoy=()=>clave(reloj());
  function sumarDias(k,n){const [y,m,d]=k.split('-').map(Number);return clave(new Date(y,m-1,d+n))}
  function diaSemana(k){const [y,m,d]=k.split('-').map(Number);return new Date(y,m-1,d).getDay()}

  /* Datos de la racha del usuario actual (los crea si no existen) */
  function datos(){
    if(!S.racha||typeof S.racha!=='object')S.racha={dias:0,ultimo:'',mejor:0,historial:[]};
    if(!Array.isArray(S.racha.historial))S.racha.historial=[];
    return S.racha;
  }

  /* Puntos extra que da un día de racha */
  const bonus=dias=>Math.min(dias*C.puntosPorDia,C.tope);

  /* Estado para mostrar:
     'hecha'     → hoy ya se aprobó un quiz
     'pendiente' → la racha sigue viva pero falta el quiz de hoy
     'apagada'   → se perdió (o nunca empezó) */
  function estado(){
    const r=datos(),h=hoy();
    if(r.ultimo===h)return {tipo:'hecha',dias:r.dias,mejor:r.mejor,hoyGana:0,mananaGana:bonus(r.dias+1)};
    if(r.ultimo===sumarDias(h,-1)&&r.dias>0)return {tipo:'pendiente',dias:r.dias,mejor:r.mejor,hoyGana:bonus(r.dias+1)};
    return {tipo:'apagada',dias:0,mejor:r.mejor,perdida:r.dias,hoyGana:bonus(1)};
  }

  /* Últimos 7 días (terminando hoy) para el calendario */
  function semana(){
    const r=datos(),h=hoy(),hechos=new Set(r.historial);
    return Array.from({length:7},(_,i)=>{
      const k=sumarDias(h,i-6),dw=diaSemana(k);
      return {clave:k,letra:C.dias[dw],nombre:C.diasLargos[dw],hecho:hechos.has(k),hoy:k===h};
    });
  }

  /* Se llama al aprobar un quiz. Si es el primero del día, suma un día de racha
     y devuelve el resultado; si hoy ya se había contado, devuelve null.
     NO suma los puntos: eso lo hace finishQuiz (navigation.js) con "bonus". */
  function completarHoy(){
    const r=datos(),h=hoy();
    if(r.ultimo===h)return null;
    const seguia=r.ultimo===sumarDias(h,-1)&&r.dias>0;
    const anterior=r.dias;
    r.dias=seguia?r.dias+1:1;
    r.ultimo=h;
    if(!r.historial.includes(h))r.historial.push(h);
    if(r.historial.length>C.historialMax)r.historial=r.historial.slice(-C.historialMax);
    const record=r.dias>r.mejor;
    r.mejor=Math.max(r.mejor,r.dias);
    return {dias:r.dias,bonus:bonus(r.dias),record:record&&r.dias>1,nueva:r.dias===1,perdida:!seguia&&anterior>0?anterior:0};
  }

  function reiniciar(){S.racha=null}

  const usarReloj=fn=>{reloj=typeof fn==='function'?fn:()=>new Date()};

  return {hoy,sumarDias,estado,semana,completarHoy,bonus,reiniciar,usarReloj};
})();
