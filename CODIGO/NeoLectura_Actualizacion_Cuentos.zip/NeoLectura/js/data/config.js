const SIZES=['1.0625rem','1.3rem','1.6rem'],SIZE_NAMES=['Normal','Grande','Muy grande'];
const PARTS=3;

