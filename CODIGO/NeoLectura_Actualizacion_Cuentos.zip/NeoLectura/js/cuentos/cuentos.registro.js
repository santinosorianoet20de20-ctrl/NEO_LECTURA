/* =====================  CUENTOS · REGISTRO  =====================
   Cada cuento es un NIVEL y vive en su propio archivo en esta carpeta
   (caperucita-roja.js, el-gato-con-botas.js, …). Cada archivo llama a
   registrarCuento({...}) con sus datos, y cuentos.camino.js los ordena
   del más corto al más largo y los encadena.

   PARA AGREGAR UN CUENTO: copiar uno de los archivos, cambiar los datos y
   sumar su <script> en index.html (después de este archivo y antes de
   cuentos.camino.js). Los dibujos van en img/escenas/<id>/ (ver LEEME.md ahí).
   PARA QUITAR UNO: borrar su archivo y su <script>.

   Campos de un cuento:
     id             sin espacios ni ":" (con él se guarda el progreso)
     titulo, autor, genero
     aprobar        respuestas correctas del quiz que hacen falta para pasar
                    al nivel siguiente (si falta: la mitad de las preguntas)
     dibujoPortada  qué muestra la portada (guía para la versión final)
     partes         las 3 partes, cada una con:
       titulo       el título de la parte
       librin       la pregunta que hace Librín (o Librón) mientras se lee
       dibujo       qué muestra la escena de esa parte (guía para la versión final)
       texto        un elemento por párrafo. Dentro de un párrafo, '\n' es un
                    salto de línea (para los versos de las moralejas)
       imagen       (opcional) otra ruta para la escena
     palabras       {palabra:'definición'}: se marcan solas la primera vez que
                    aparecen en cada parte, y Librín explica qué significan.
                    Tienen que estar escritas igual que en el texto (con tildes).
     quiz           [{parte, pregunta, opciones}]: la PRIMERA opción es la
                    correcta; la app las mezcla al mostrarlas (siempre igual).
                    "parte" dice de qué parte es la pregunta (1, 2 o 3).
   Las 3 partes de un cuento tienen que durar más o menos lo mismo: se puede
   revisar en la consola del navegador con  Camino.medir()                  */
const CUENTOS=[];
function registrarCuento(c){CUENTOS.push(c)}
