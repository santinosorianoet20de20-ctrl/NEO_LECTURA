/* =====================  CUENTO · CAPERUCITA ROJA  =====================
   Charles Perrault. Texto del PDF del proyecto (dominio público), con los errores
   de tipeo corregidos. Qué es cada campo: js/cuentos/cuentos.registro.js
   El número de nivel no se escribe acá: sale solo del largo del cuento
   (js/cuentos/cuentos.camino.js).                                        */
registrarCuento({
  id:'caperucita-roja',
  titulo:'Caperucita Roja',
  autor:'Charles Perrault',
  genero:'Cuento clásico',
  aprobar:3,   // respuestas correctas que hacen falta para pasar al nivel siguiente (de 6)
  dibujoPortada:'Caperucita Roja camina por el bosque con su canasta mientras un lobo la espía detrás de un árbol.',

  partes:[
    /* ---------- Parte 1 ---------- */
    {titulo:'Un encargo para la abuela',
     librin:'¿Qué le contó Caperucita al lobo? ¿Te parece que hizo bien en contarle? 🤔',
     dibujo:'Un bosque con un camino de tierra. Caperucita Roja (una niña con capa roja con capucha y una canasta) habla con un lobo gris que le sonríe. Entre los árboles se ven dos leñadores con hachas y, a lo lejos, un molino.',
     texto:[
      'Había una vez una niñita en un pueblo, la más bonita que jamás se hubiera visto; su madre estaba enloquecida con ella y su abuela mucho más todavía. Esta buena mujer le había mandado hacer una caperucita roja y le sentaba tanto que todos la llamaban Caperucita Roja.',
      'Un día su madre, habiendo cocinado unas tortas, le dijo:',
      '—Anda a ver cómo está tu abuela, pues me dicen que ha estado enferma; llévale una torta y este tarrito de mantequilla.',
      'Caperucita Roja partió en seguida a ver a su abuela que vivía en otro pueblo. Al pasar por un bosque, se encontró con el compadre lobo, que tuvo muchas ganas de comérsela, pero no se atrevió porque unos leñadores andaban por ahí cerca. Él le preguntó a dónde iba. La pobre niña, que no sabía que era peligroso detenerse a hablar con un lobo, le dijo:',
      '—Voy a ver a mi abuela, y le llevo una torta y un tarrito de mantequilla que mi madre le envía.',
      '—¿Vive muy lejos?, le dijo el lobo.',
      '—¡Oh, sí!, dijo Caperucita Roja, más allá del molino que se ve allá lejos, en la primera casita del pueblo.',
      '—Pues bien, dijo el lobo, yo también quiero ir a verla; yo iré por este camino, y tú por aquél, y veremos quién llega primero.',
     ]},
    /* ---------- Parte 2 ---------- */
    {titulo:'El camino más corto',
     librin:'¿Por qué el lobo eligió el camino más corto? ¿Y qué hacía Caperucita mientras tanto? 🦋',
     dibujo:'Un camino que se divide en dos. Por el camino corto corre el lobo hacia una casita; por el largo, Caperucita junta flores entre mariposas y avellanos.',
     texto:[
      'El lobo partió corriendo a toda velocidad por el camino que era más corto y la niña se fue por el más largo entreteniéndose en coger avellanas, en correr tras las mariposas y en hacer ramos con las florecillas que encontraba. Poco tardó el lobo en llegar a casa de la abuela; golpea: Toc, toc.',
      '—¿Quién es?',
      '—Es su nieta, Caperucita Roja, dijo el lobo, disfrazando la voz, le traigo una torta y un tarrito de mantequilla que mi madre le envía.',
      'La cándida abuela, que estaba en cama porque no se sentía bien, le gritó:',
      '—Tira la aldaba y el cerrojo caerá.',
      'El lobo tiró la aldaba, y la puerta se abrió. Se abalanzó sobre la buena mujer y la devoró en un santiamén, pues hacía más de tres días que no comía. En seguida cerró la puerta y fue a acostarse en el lecho de la abuela, esperando a Caperucita Roja quien, un rato después, llegó a golpear la puerta: Toc, toc.',
      '—¿Quién es?',
      'Caperucita Roja, al oír la ronca voz del lobo, primero se asustó, pero creyendo que su abuela estaba resfriada, contestó:',
      '—Es su nieta, Caperucita Roja, le traigo una torta y un tarrito de mantequilla que mi madre le envía.',
      'El lobo le gritó, suavizando un poco la voz:',
      '—Tira la aldaba y el cerrojo caerá.',
     ]},
    /* ---------- Parte 3 ---------- */
    {titulo:'¡Qué dientes tan grandes!',
     librin:'Las respuestas del lobo esconden lo que quiere hacer. ¿Cuál te dio más miedo? ¿Y qué nos enseña la moraleja? 📖',
     dibujo:'El cuarto de la abuela. El lobo está acostado en la cama con gorro de dormir y la frazada hasta el hocico; Caperucita, al lado de la cama, lo mira sorprendida. En una repisa están la torta y el tarrito de mantequilla.',
     texto:[
      'Caperucita Roja tiró la aldaba y la puerta se abrió. Viéndola entrar, el lobo le dijo, mientras se escondía en la cama bajo la frazada:',
      '—Deja la torta y el tarrito de mantequilla en la repisa y ven a acostarte conmigo.',
      'Caperucita Roja se desviste y se mete a la cama y quedó muy asombrada al ver la forma de su abuela en camisa de dormir. Ella le dijo:',
      '—Abuela, ¡qué brazos tan grandes tienes!',
      '—Es para abrazarte mejor, hija mía.',
      '—Abuela, ¡qué piernas tan grandes tienes!',
      '—Es para correr mejor, hija mía.',
      '—Abuela, ¡qué orejas tan grandes tienes!',
      '—Es para oír mejor, hija mía.',
      '—Abuela, ¡qué ojos tan grandes tienes!',
      '—Es para ver mejor, hija mía.',
      '—Abuela, ¡qué dientes tan grandes tienes!',
      '—¡Para comerte mejor!',
      'Y diciendo estas palabras, este lobo malo se abalanzó sobre Caperucita Roja y se la comió.',
      'Moraleja:',
      'Aquí vemos que la adolescencia,\nen especial las señoritas,\nbien hechas, amables y bonitas\nno deben a cualquiera oír con complacencia,\ny no resulta causa de extrañeza\nver que muchas del lobo son la presa.\nY digo el lobo, pues bajo su envoltura\nno todos son de igual calaña:\nlos hay con no poca maña,\nsilenciosos, sin odio ni amargura,\nque en secreto, pacientes, con dulzura\nvan a la siga de las damiselas\nhasta las casas y en las callejuelas;\nmas, bien sabemos que los zalameros\nentre todos los lobos ¡ay! son los más fieros.',
     ]}
  ],

  // Palabras difíciles: se marcan solas la primera vez que aparecen en cada parte
  palabras:{
    'enloquecida':'Aquí quiere decir que la quería muchísimo.',
    'caperucita':'Capa corta con capucha, que cubre la cabeza y los hombros.',
    'tarrito':'Frasco chiquito.',
    'compadre':'Forma de llamar a alguien conocido del lugar, como decir «don lobo».',
    'leñadores':'Personas que cortan árboles para sacar leña.',
    'molino':'Edificio con aspas grandes que muele el trigo para hacer harina.',
    'avellanas':'Frutos secos chiquitos y redondos, con cáscara dura.',
    'cándida':'Inocente, que cree todo lo que le dicen.',
    'aldaba':'Traba de la puerta con un cordón: al tirarla, la puerta se destraba.',
    'cerrojo':'Barra de metal que se corre para trabar una puerta.',
    'abalanzó':'Se tiró encima de golpe.',
    'santiamén':'Un instante: «en un santiamén» es rapidísimo.',
    'lecho':'Cama.',
    'ronca':'Voz grave y áspera, como cuando te duele la garganta.',
    'frazada':'Manta gruesa para abrigarse en la cama.',
    'repisa':'Estante pegado a la pared.',
    'Moraleja':'La enseñanza que deja un cuento.',
    'complacencia':'Con gusto, aceptando todo lo que dicen.',
    'calaña':'Clase o tipo (se dice de personas que no son buenas).',
    'maña':'Habilidad, astucia.',
    'damiselas':'Muchachas jóvenes.',
    'zalameros':'Personas que te halagan con palabras dulces para conseguir algo.',
  },

  // Quiz: van en orden de parte y cada vez más difíciles. La PRIMERA opción es la correcta
  // (la app las mezcla al mostrarlas, siempre en el mismo orden).
  quiz:[
    {parte:1, pregunta:'¿Por qué todos la llamaban Caperucita Roja?',
     opciones:['Porque su abuela le había hecho una caperucita roja', 'Porque le gustaban mucho las frutillas', 'Porque vivía en una casa pintada de rojo']},
    {parte:1, pregunta:'¿Por qué el lobo no se comió a Caperucita en el bosque?',
     opciones:['Porque había unos leñadores cerca', 'Porque no tenía hambre', 'Porque Caperucita salió corriendo']},
    {parte:2, pregunta:'¿Qué hizo Caperucita mientras el lobo corría por el camino corto?',
     opciones:['Juntó avellanas, siguió mariposas e hizo ramos de flores', 'Se sentó a descansar debajo de un árbol', 'Volvió a su casa a buscar otra torta']},
    {parte:2, pregunta:'¿Cómo hizo el lobo para que la abuela le abriera la puerta?',
     opciones:['Disfrazó la voz y dijo que era Caperucita', 'Rompió la ventana de un golpe', 'Esperó a que la abuela saliera de la casa']},
    {parte:3, pregunta:'Cuando Caperucita oyó la voz ronca, ¿por qué no se dio cuenta de que era el lobo?',
     opciones:['Porque creyó que su abuela estaba resfriada', 'Porque no escuchaba bien desde afuera', 'Porque el lobo no le habló']},
    {parte:3, pregunta:'¿Qué nos quiere enseñar la moraleja?',
     opciones:['Que no hay que confiar en cualquiera que nos habla con dulzura', 'Que hay que visitar seguido a los abuelos', 'Que los lobos viven en los bosques']},
  ]
});
