/* =====================  CUENTOS · CAMINO DE NIVELES  =====================
   Arma los niveles con los cuentos registrados (js/cuentos/*.js):
   - Los ordena del más corto al más largo: el más corto es el Nivel 1.
   - Cada cuento es un nivel con 3 partes y un quiz (como los niveles de antes).
   - Un nivel se desbloquea al aprobar el quiz del nivel anterior.
   El resto de la app usa STORIES (la lista ya armada, en el formato de
   siempre) y Camino (para saber el número de nivel y qué está desbloqueado). */
const CAMINO_CFG={
  orden:'largo',            // 'largo' = del más corto al más largo · o una lista fija: ['caperucita-roja', …]
  escenas:'img/escenas/',   // carpeta de los dibujos: <carpeta><id>/portada.svg, parte-1.svg, parte-2.svg, parte-3.svg
  formato:'svg',            // cuando lleguen las versiones finales (por ejemplo en PNG), se cambia solo acá
  aprobarPorDefecto:.5      // si un cuento no dice "aprobar": la mitad de las preguntas
};

const Camino=(()=>{
  const C=CAMINO_CFG;
  const plano=c=>c.partes.map(p=>p.texto.join('\n\n')).join('\n\n');

  /* Marca las palabras del vocabulario como {palabra|definición} la primera vez
     que aparecen (palabra entera, igual que está escrita). Se buscan todas sobre
     el texto original, así una definición nunca se marca adentro de otra. */
  const literal=w=>w.replace(/[.*+?^$(){}|[\]\\]/g,'\\$&');
  function marcar(texto,palabras){
    const marcas=[];
    for(const [w,def] of Object.entries(palabras||{})){
      const re=new RegExp('(^|[^\\p{L}])('+literal(w)+')(?![\\p{L}])','u');
      const m=re.exec(texto);
      if(m)marcas.push({ini:m.index+m[1].length,fin:m.index+m[0].length,w,def});
    }
    marcas.sort((a,b)=>a.ini-b.ini);
    let h='',i=0;
    for(const k of marcas){if(k.ini<i)continue;h+=texto.slice(i,k.ini)+'{'+k.w+'|'+k.def+'}';i=k.fin}
    return h+texto.slice(i);
  }

  /* Mezcla las opciones del quiz (la primera es la correcta) siempre de la misma
     forma para cada pregunta, así la respuesta no está siempre en el mismo lugar */
  function mezclar(opciones,clave){
    let h=7;for(const c of clave)h=(h*31+c.codePointAt(0))%2147483647;
    const r=seed(h||1),o=opciones.map((t,i)=>({t,i}));
    for(let i=o.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[o[i],o[j]]=[o[j],o[i]]}
    return {o:o.map(x=>x.t),a:o.findIndex(x=>x.i===0)};
  }

  const imagen=(id,nombre)=>`${C.escenas}${id}/${nombre}.${C.formato}`;

  /* Cuento (formato de los archivos) → nivel (formato que usa la app) */
  function armar(c,n){
    const quiz=c.quiz.map(q=>Object.assign({q:q.pregunta,parte:q.parte},mezclar(q.opciones,c.id+'|'+q.pregunta)));
    return {
      id:c.id,title:c.titulo,genre:c.genero||'Cuento',autor:c.autor||'',open:true,nivel:n,
      img:c.portada||imagen(c.id,'portada'),dibujo:c.dibujoPortada||'',
      levels:[{
        name:c.titulo,
        aprobar:c.aprobar||Math.ceil(quiz.length*C.aprobarPorDefecto),
        parts:c.partes.map((p,i)=>({t:p.titulo,x:marcar(p.texto.join('\n\n'),c.palabras),lb:p.librin,
          img:p.imagen||imagen(c.id,'parte-'+(i+1)),dibujo:p.dibujo||''})),
        quiz
      }]
    };
  }

  // Orden del camino
  const lista=CUENTOS.slice();
  if(Array.isArray(C.orden))lista.sort((a,b)=>C.orden.indexOf(a.id)-C.orden.indexOf(b.id));
  else lista.sort((a,b)=>plano(a).length-plano(b).length);
  const niveles=lista.map((c,i)=>armar(c,i+1));

  const pos=sid=>niveles.findIndex(s=>s.id===sid);
  const anterior=sid=>niveles[pos(sid)-1]||null;
  const siguiente=sid=>{const i=pos(sid);return i<0?null:niveles[i+1]||null};
  // Un cuento está aprobado cuando se aprobó el quiz de todos sus niveles (hoy, uno solo)
  const aprobado=sid=>{const s=niveles[pos(sid)];return !!s&&s.levels.every((_,l)=>!!S.done[kd(sid,l)])};
  const desbloqueado=sid=>{const a=anterior(sid);return pos(sid)>=0&&(!a||aprobado(a.id))};
  const aprobar=(sid,l)=>niveles[pos(sid)].levels[l].aprobar;
  // "Nivel 2" (si algún día un cuento tiene más de un nivel: "Nivel 2.1", "Nivel 2.2"…)
  const etiqueta=(sid,l=0)=>{const s=niveles[pos(sid)];return 'Nivel '+s.nivel+(s.levels.length>1?'.'+(l+1):'')};

  /* Para revisar en la consola que las 3 partes duren lo mismo: Camino.medir() */
  function medir(){
    const A=typeof AUDIO_CFG!=='undefined'?AUDIO_CFG:{letrasPorSegundo:15,velocidad:.9,pesoPausa:3,pausas:/[,;:—–]/};
    const seg=t=>{t=plain(t);let v=0;for(const ch of t)v+=1+(A.pausas.test(ch)?A.pesoPausa:0);return v/(A.letrasPorSegundo*A.velocidad)};
    const filas=niveles.map(s=>{const p=s.levels[0].parts.map(x=>seg(x.x));
      return {nivel:s.nivel,cuento:s.title,'parte 1 (min)':+(p[0]/60).toFixed(1),'parte 2 (min)':+(p[1]/60).toFixed(1),'parte 3 (min)':+(p[2]/60).toFixed(1),
        'diferencia':Math.round((Math.max(...p)-Math.min(...p))/(p[0]+p[1]+p[2])*100)+'%'}});
    if(typeof console!=='undefined'&&console.table)console.table(filas);
    return filas;
  }

  return {niveles,anterior,siguiente,aprobado,desbloqueado,aprobar,etiqueta,medir,marcar};
})();

/* La lista de cuentos que usa toda la app, ya ordenada */
const STORIES=Camino.niveles;
/* Portada de un cuento (antes se dibujaba en js/illustrations.js) */
const cover=s=>s.img;
