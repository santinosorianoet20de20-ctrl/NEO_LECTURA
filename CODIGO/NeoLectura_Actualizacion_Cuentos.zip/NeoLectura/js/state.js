/* =====================  ESTADO  ===================== */
const KEY_BASE='neolectura.v1';
let KEY=KEY_BASE; // cambia según quién inicia sesión (ver useProfile)
// Las cuentas nuevas (y el invitado) empiezan con 0 puntos.
// Audiolibro: vol = volumen (0 a 1) · voz = voz elegida ('' = la primera de la lista) · ritmo = 'normal' o 'lenta'
const DEF={name:'Valentín',points:0,parts:{},quiz:{},done:{},size:0,voice:true,vol:1,voz:'',ritmo:'normal',theme:'auto'};
function load(){try{const r=localStorage.getItem(KEY);return r?JSON.parse(r):null}catch(e){return null}}
function save(){
  try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}
  if(typeof Ranking!=='undefined')Ranking.anotar(); // anota los puntos de la cuenta en el ranking (js/ranking)
}
// Copia nueva de los valores por defecto (para que dos usuarios no compartan los mismos objetos)
const blank=()=>Object.assign({},DEF,{parts:{},quiz:{},done:{}});
let S=Object.assign(blank(),load()||{});
let R={s:'home'},Q=null;

/* Carga el progreso de un usuario (null = invitado, usa la clave de siempre).
   Devuelve true si ese usuario ya tenía datos guardados. Lo usa js/login. */
function useProfile(user){
  KEY=user?KEY_BASE+':'+user:KEY_BASE;
  const d=load();
  S=Object.assign(blank(),d||{});
  return !!d;
}

const story=id=>STORIES.find(s=>s.id===id);
const kd=(sid,l)=>sid+':'+l, kp=(sid,l,p)=>sid+':'+l+':'+p;
const doneCount=sid=>story(sid).levels.filter((_,i)=>S.done[kd(sid,i)]).length;
const totalDone=()=>STORIES.filter(s=>s.open).reduce((a,s)=>a+doneCount(s.id),0);
/* Un nivel se puede leer si se aprobó el anterior. El primer nivel de cada cuento
   depende del cuento anterior del camino (js/cuentos/cuentos.camino.js) */
const unlocked=(sid,l)=>l>0?!!S.done[kd(sid,l-1)]:Camino.desbloqueado(sid);
const partsRead=(sid,l)=>{let n=0;for(let p=0;p<PARTS;p++)if(S.parts[kp(sid,l,p)])n++;return n};
const starCount=()=>S.points>=1200?3:S.points>=600?2:S.points>=200?1:0;
const started=sid=>Object.keys(S.parts).some(k=>k.indexOf(sid+':')===0);
const plain=t=>t.replace(/\{([^|}]+)\|[^}]+\}/g,'$1');
const vocab=t=>PARRAFOS(t.replace(/\{([^|}]+)\|([^}]+)\}/g,(m,w,d)=>`<button class="vocab" data-a="def" data-w="${ESC(w)}" data-d="${ESC(d)}">${w}</button>`));
const canSpeak=typeof window!=='undefined'&&'speechSynthesis' in window&&'SpeechSynthesisUtterance' in window;

