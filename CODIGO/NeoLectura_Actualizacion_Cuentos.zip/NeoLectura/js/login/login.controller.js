/* =====================  LOGIN · CONTROLADOR  =====================
   Maneja los eventos del inicio de sesión y lo conecta con la app:
   - Ingresar, crear cuenta o entrar como invitado.
   - Reacciones de Librín según lo que hace el usuario.
   - Abre/cierra la sesión y carga el progreso de cada usuario
     (useProfile está en state.js).
   Usa delegación de eventos (document.addEventListener) porque la app
   vuelve a dibujar las pantallas con innerHTML.                        */
const Login=(()=>{
  const C=LOGIN_CFG,M=C.msg,F=C.frases;
  const $=s=>document.querySelector(s);
  const enLogin=()=>!!$('.lg');
  const espera=ms=>new Promise(r=>setTimeout(r,ms));
  const alAzar=l=>l[Math.floor(Math.random()*l.length)];
  let fallos=0,ocupado=false,toques=0,tToques=0,tip=0,quieto=0;

  /* ---------- Sesión ---------- */
  const activa=()=>!!LoginStorage.sesion();

  // Si se recarga la página con la sesión abierta, se recupera su progreso
  (function restaurar(){const s=LoginStorage.sesion();if(s)useProfile(s.usuario)})();

  function entrar(cuenta){
    const u=cuenta?cuenta.usuario:null;
    const tenia=useProfile(u); // carga el progreso de ese usuario (null = invitado)
    if(cuenta){
      if(!tenia)S.name=cuenta.nombre;
      S.avatar=LOGIN_AVATAR(cuenta.avatar).emoji;
      LoginStorage.marcarIngreso(u);
    }else if(!tenia)S.name=C.textos.invitado;
    save();
    LoginStorage.abrirSesion(u);
    fallos=0;R={s:'home'};Q=null;
    try{history.replaceState({s:'home'},'')}catch(e){}
    render();window.scrollTo(0,0);
    toast(`Hola, ${S.name} ${S.avatar||'📚'}`);
  }

  function salir(){
    const s=LoginStorage.sesion();
    if(s&&s.usuario)LoginStorage.actualizar(s.usuario,{nombre:S.name}); // por si cambió el nombre en Opciones
    Audiolibro.detener(); // corta el audiolibro si estaba sonando (js/audio)
    LoginStorage.cerrarSesion();
    fallos=0;ocupado=false;R={s:'home'};Q=null;
    try{history.replaceState({s:'home'},'')}catch(e){}
    render();window.scrollTo(0,0);
  }

  /* ---------- Ayudas para los campos ---------- */
  function campo(id){
    const i=document.getElementById(id);
    return i?{i,f:i.closest('.lg-field'),m:document.getElementById(id+'-msg')}:null;
  }
  function marcar(id,msg,tipo='err'){
    const c=campo(id);if(!c)return;
    c.f.classList.remove('err','ok');c.f.classList.add(tipo);
    if(tipo==='err')c.i.setAttribute('aria-invalid','true');else c.i.removeAttribute('aria-invalid');
    c.m.innerHTML=ic(tipo==='err'?'alert':'check',14)+'<span>'+msg+'</span>'; // msg sale de LOGIN_CFG, nunca de lo que escribe el usuario
  }
  function limpiar(id){
    const c=campo(id);if(!c)return;
    c.f.classList.remove('err','ok');c.i.removeAttribute('aria-invalid');c.m.textContent='';
  }

  /* Estado de Librín según el campo que tiene el foco */
  function animoFoco(){
    const a=document.activeElement;
    if(!a||a.tagName!=='INPUT'||!a.closest('.lg')||a.type==='checkbox'||a.type==='radio')return 'idle';
    if(a.hasAttribute('data-clave'))return a.type==='password'?'hide':'peek';
    return 'look';
  }

  function error(texto,img){
    Librin.estado('sad',1800,animoFoco,img);Librin.decir(texto);
    const c=$('.lg-card');
    if(c){c.classList.remove('lg-shake');void c.offsetWidth;c.classList.add('lg-shake')}
  }

  function cargando(form,si){
    const b=form.querySelector('[type=submit]');
    if(b){b.disabled=si;b.setAttribute('aria-busy',si)}
  }

  /* Lluvia de estrellas y papelitos al entrar */
  function confeti(origen){
    const r=(origen||$('.lg-card')).getBoundingClientRect();
    const box=document.createElement('div');box.className='lg-confeti';box.setAttribute('aria-hidden','true');
    box.style.cssText=`--ox:${r.left+r.width/2}px;--oy:${r.top+r.height/2}px`;
    const colores=['#F7C900','#58C7C8','#ED823A','#387CC6','#E64D49','#3AA75B'];
    for(let i=0;i<26;i++){
      const a=Math.random()*Math.PI*2,d=80+Math.random()*170,s=document.createElement('i');
      s.style.cssText=`--dx:${(Math.cos(a)*d).toFixed(0)}px;--dy:${(Math.sin(a)*d-50).toFixed(0)}px;--c:${colores[i%colores.length]};--r:${(Math.random()*540-270).toFixed(0)}deg;--t:${(Math.random()*.12).toFixed(2)}s`;
      if(i%3===0){s.className='st';s.innerHTML=ic('star',16,true)}
      box.appendChild(s);
    }
    document.body.appendChild(box);setTimeout(()=>box.remove(),1500);
  }

  /* Festejo y entrada a la app */
  function exito(cuenta,texto,boton){
    ocupado=true;
    Librin.estado('happy');Librin.decir(texto);confeti(boton);
    setTimeout(()=>{
      const lg=$('.lg');if(lg)lg.classList.add('lg-out');
      setTimeout(()=>{ocupado=false;entrar(cuenta)},420);
    },1300);
  }

  /* ---------- Formularios ---------- */
  async function ingresar(form){
    if(ocupado)return;
    const u=form.usuario.value.trim(),p=form.clave.value;
    limpiar('lg-u');limpiar('lg-p');
    const eU=LoginValidar.usuario(u),eP=p?'':M.claveVacia;
    if(eU)marcar('lg-u',eU);
    if(eP)marcar('lg-p',eP);
    if(eU||eP){document.getElementById(eU?'lg-u':'lg-p').focus();error(eU&&eP?F.revisar:(eU||eP));return}

    const cuenta=LoginStorage.buscar(u);
    if(!cuenta){marcar('lg-u',M.noExiste);form.usuario.focus();error(F.noExiste);return}

    ocupado=true;cargando(form,true);
    const ok=await LoginStorage.verificar(cuenta,p);
    await espera(450); // pequeña pausa para que se vea el "cargando"
    cargando(form,false);ocupado=false;
    if(!ok){
      fallos++;marcar('lg-p',M.claveMal);
      form.clave.focus();form.clave.select();
      error(fallos>=3?F.ayuda:F.claveMal,'animo');return;
    }
    LoginStorage.recordar(form.recordar.checked?cuenta.usuario:null);
    exito(cuenta,F.exito(cuenta.nombre),form.querySelector('[type=submit]'));
  }

  async function crear(form){
    if(ocupado)return;
    const n=form.nombre.value.trim().replace(/\s+/g,' '),u=form.usuario.value.trim(),p=form.clave.value;
    const av=(form.querySelector('input[name=avatar]:checked')||{}).value||C.avatares[0].id;
    const errores={
      'lg-cn':LoginValidar.nombre(n),
      'lg-cu':LoginValidar.usuario(u)||(LoginStorage.buscar(u)?M.existe:''),
      'lg-cp':LoginValidar.clave(p)
    };
    const malos=Object.keys(errores).filter(k=>errores[k]);
    Object.keys(errores).forEach(k=>errores[k]?marcar(k,errores[k]):limpiar(k));
    if(malos.length){document.getElementById(malos[0]).focus();error(malos.length>1?F.revisar:errores[malos[0]]);return}

    ocupado=true;cargando(form,true);
    const cuenta=await LoginStorage.crear({usuario:u,nombre:n,avatar:av,clave:p});
    await espera(500);
    cargando(form,false);ocupado=false;
    if(!cuenta){error(M.noGuardo);return}
    LoginStorage.recordar(cuenta.usuario);
    exito(cuenta,F.creada(n),form.querySelector('[type=submit]'));
  }

  /* ---------- Acciones ---------- */
  /* Cambia entre "Iniciar Sesión" y "Crear Cuenta" */
  function panel(n){
    const lg=$('.lg');if(!lg||lg.dataset.panel===n)return;
    lg.dataset.panel=n;
    $('#lg-form-entrar').hidden=n!=='entrar';
    $('#lg-form-crear').hidden=n!=='crear';
    if(n==='crear'){
      const u=$('#lg-u'),cu=$('#lg-cu');
      if(u&&cu&&!cu.value&&u.value.trim()){cu.value=u.value.trim();disponible(cu)}
      const cn=$('#lg-cn');if(cn)cn.focus({preventScroll:true});
      Librin.reaccion('increible',1400,animoFoco);Librin.decir(F.crear); // después del foco, para que no lo pise
    }else{
      const iu=$('#lg-u');if(iu)iu.focus({preventScroll:true});
      Librin.reaccion('bien',1200,animoFoco);Librin.decir(F.volver);
    }
  }

  function ojo(b){
    const i=document.getElementById(b.dataset.for);if(!i)return;
    const ver=i.type==='password';
    i.type=ver?'text':'password';
    b.setAttribute('aria-pressed',ver);
    b.setAttribute('aria-label',ver?'Ocultar contraseña':'Mostrar contraseña');
    b.innerHTML=ic(ver?'eyeoff':'eye',18);
    if(document.activeElement===i){
      Librin.estado(ver?'peek':'hide');Librin.decir(ver?F.espiar:F.clave);
      if(ver)Librin.mirarTexto(i);
    }
  }

  function elegirAvatar(radio){
    document.querySelectorAll('.lg-av').forEach(l=>l.classList.toggle('on',l.contains(radio)));
    const a=LOGIN_AVATAR(radio.value);
    Librin.reaccion('increible',1300,animoFoco);Librin.decir(F.avatar(a.nombre,a.emoji));
  }

  function disponible(input){
    const v=input.value.trim(),f=input.closest('.lg-field'),antes=f&&f.classList.contains('ok');
    if(!v){limpiar(input.id);return}
    if(/\s/.test(v)){marcar(input.id,M.usuarioEspacios);return}
    if(LoginValidar.usuario(v)){limpiar(input.id);return} // no molestar mientras escribe
    if(LoginStorage.buscar(v)){marcar(input.id,M.existe);return}
    marcar(input.id,M.libre,'ok');
    if(!antes&&document.activeElement===input){Librin.reaccion('bien',1100,animoFoco);Librin.decir(F.libre)}
  }

  function medidor(v){
    const m=$('.lg-meter');if(!m)return;
    const n=LoginValidar.fuerza(v),antes=+m.dataset.n;
    m.dataset.n=n;m.querySelector('b').textContent=C.fuerza[n];
    if(n===3&&antes<3){Librin.reaccion('excelente',1200,animoFoco);Librin.decir(F.fuerte)}
  }

  function tocarLibrin(){
    clearTimeout(tToques);toques++;
    tToques=setTimeout(()=>toques=0,1200);
    Librin.animar('boing');
    if(toques>=4){toques=0;Librin.animar('giggle');Librin.reaccion('orgullo',1600,animoFoco);Librin.decir(F.cosquillas);return}
    Librin.reaccion(alAzar(C.librin.divertidas),1500,animoFoco);
    Librin.decir(C.tips[tip++%C.tips.length]);
  }

  /* ---------- Eventos ---------- */
  document.addEventListener('submit',e=>{
    const f=e.target;
    if(f.id==='lg-form-entrar'){e.preventDefault();ingresar(f)}
    else if(f.id==='lg-form-crear'){e.preventDefault();crear(f)}
  });

  document.addEventListener('click',e=>{
    const t=e.target.closest('[data-login]');if(!t||!enLogin())return;
    quieto=0;
    switch(t.dataset.login){
      case 'ir-crear':panel('crear');break;
      case 'ir-entrar':panel('entrar');break;
      case 'ojo':ojo(t);break;
      case 'invitado':if(!ocupado)exito(null,F.invitado,t);break;
      case 'olvide':Librin.reaccion('aprender',2200,animoFoco);Librin.decir(F.olvide);break;
      case 'librin':tocarLibrin();break;
    }
  });

  // El botón del ojo no le saca el foco al campo de contraseña
  document.addEventListener('mousedown',e=>{if(e.target.closest&&e.target.closest('.lg-eye'))e.preventDefault()});

  document.addEventListener('change',e=>{
    const t=e.target;
    if(t.name==='avatar'&&t.closest('.lg'))elegirAvatar(t);
  });

  document.addEventListener('input',e=>{
    const t=e.target;if(!t.closest||!t.closest('.lg')||t.tagName!=='INPUT')return;
    quieto=0;
    const f=t.closest('.lg-field');
    if(f&&f.classList.contains('err')&&t.id!=='lg-cu')limpiar(t.id);
    if(t.type==='text')Librin.mirarTexto(t);
    switch(t.id){
      case 'lg-cu':disponible(t);break;
      case 'lg-cp':medidor(t.value);break;
      case 'lg-cn':{const n=t.value.trim();if(n.length>=2&&!LoginValidar.nombre(n))Librin.decir(F.hola2(n));break;}
    }
  });

  document.addEventListener('focusin',e=>{
    const t=e.target;if(ocupado||!t.closest||!t.closest('.lg')||t.tagName!=='INPUT')return;
    const m=animoFoco();if(m==='idle')return;
    Librin.estado(m);
    if(m!=='hide')Librin.mirarTexto(t);else Librin.centrar();
    const frases={'lg-u':F.usuario,'lg-cu':F.usuario,'lg-cn':F.nombre,'lg-p':m==='hide'?F.clave:F.espiar,'lg-cp':m==='hide'?F.claveNueva:F.espiar};
    if(frases[t.id])Librin.decir(frases[t.id]);
  });

  document.addEventListener('focusout',()=>{
    if(!enLogin())return;
    setTimeout(()=>{
      if(ocupado||!enLogin()||animoFoco()!=='idle')return;
      const m=Librin.animo();
      if(m==='look'||m==='hide'||m==='peek'){Librin.estado('idle');Librin.centrar()}
    },0);
  });

  // Puntero: Librín se inclina hacia el puntero y el fondo se mueve un poquito
  let px=0,py=0,cuadro=0;
  document.addEventListener('pointermove',e=>{
    if(!enLogin())return;
    px=e.clientX;py=e.clientY;
    if(!cuadro)cuadro=requestAnimationFrame(mover);
  },{passive:true});
  function mover(){
    cuadro=0;const lg=$('.lg');if(!lg)return;
    lg.style.setProperty('--mx',(px/innerWidth-.5).toFixed(3));
    lg.style.setProperty('--my',(py/innerHeight-.5).toFixed(3));
    if(animoFoco()==='idle')Librin.mirarA(px,py);
  }

  // Si nadie lo usa por un rato, Librín hace una reacción solo
  if(C.reaccionSola)setInterval(()=>{
    if(!enLogin()||ocupado||document.hidden)return;
    if(++quieto<C.reaccionSola)return;
    quieto=0;
    if(animoFoco()==='idle'&&Librin.animo()==='idle')Librin.reaccion(alAzar(C.librin.divertidas),1700);
  },1000);

  return {activa,salir};
})();
