/* =====================  PRUEBA TEMPORAL · CAMBIAR DE DÍA  =====================
   Botón flotante para adelantar el día y probar la racha sin esperar a mañana.
   - "Día +1" adelanta un día (se puede tocar varias veces).
   - "Hoy" vuelve a la fecha real.
   El día simulado se guarda en el navegador, así que sigue igual si se recarga
   la página. Solo afecta a la racha (usa Racha.usarReloj de racha.logic.js).

   PARA QUITARLO: borrar este archivo y su línea <script> en index.html.
   Nada más de la app depende de él.                                       */
(()=>{
  if(typeof Racha==='undefined'||!Racha.usarReloj)return;
  const K='neolectura.prueba.dias';
  const DIAS=['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
  let dias=0;try{dias=parseInt(localStorage.getItem(K)||'0',10)||0}catch(e){}

  const fecha=()=>{const d=new Date();d.setDate(d.getDate()+dias);return d};
  const texto=d=>`${DIAS[d.getDay()]} ${d.getDate()}/${d.getMonth()+1}`;
  function aplicar(){
    Racha.usarReloj(dias?fecha:null);
    try{if(dias)localStorage.setItem(K,dias);else localStorage.removeItem(K)}catch(e){}
  }

  /* Estilos (van acá adentro para que el módulo sea un solo archivo) */
  const css=document.createElement('style');
  css.textContent=`
    .pd{position:fixed;left:12px;bottom:12px;z-index:13;display:flex;align-items:center;gap:6px;padding:6px 6px 6px 12px;
      border-radius:999px;background:#2B2140;color:#fff;font:800 12px/1 'Nunito',system-ui,sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.3)}
    .pd[hidden]{display:none}
    .pd b{font-weight:900;color:#FFD54A}
    .pd button{height:28px;padding:0 10px;border-radius:999px;background:rgba(255,255,255,.16);color:#fff;font:800 12px 'Nunito',system-ui,sans-serif}
    .pd button:hover{background:rgba(255,255,255,.28)}
    .pd .pd-mas{background:#FFD54A;color:#3a2a00}
    .pd .pd-mas:hover{background:#FFE07A}
    @media (max-width:600px){.pd{bottom:72px}.pd .pd-txt{display:none}} /* en el celular, más arriba (no lo tapan los avisos) y más corto */`;
  document.head.appendChild(css);

  const box=document.createElement('div');
  box.className='pd';box.setAttribute('role','group');box.setAttribute('aria-label','Prueba: cambiar de día');
  document.body.appendChild(box);

  function pintar(){
    box.hidden=!(typeof Login!=='undefined'&&Login.activa()); // solo con la sesión abierta
    box.innerHTML=`<span>🧪 <span class="pd-txt">Prueba · hoy: </span><b>${texto(fecha())}</b>${dias?` (+${dias})`:''}</span>
      <button class="pd-mas" data-pd="mas" title="Adelantar un día">Día +1</button>
      ${dias?'<button data-pd="hoy" title="Volver a la fecha real">Hoy</button>':''}`;
  }

  box.addEventListener('click',e=>{
    const b=e.target.closest('[data-pd]');if(!b)return;
    if(b.dataset.pd==='mas')dias++;else dias=0;
    aplicar();
    // si se vuelve a hoy con una racha "del futuro", se avisa (se limpia con Reiniciar progreso en Opciones)
    const futuro=!dias&&S.racha&&S.racha.ultimo>Racha.hoy();
    render();pintar();
    if(typeof toast==='function')toast(futuro?'La racha quedó con días del futuro: límpiala con "Reiniciar progreso" en Opciones':`Ahora es ${texto(fecha())}`);
  });

  // Se muestra u oculta cada vez que la app se dibuja (al entrar, salir o cambiar de pantalla)
  const renderOriginal=render;
  render=function(){renderOriginal.apply(this,arguments);pintar()};

  aplicar();
  if(dias)render();else pintar(); // si ya había un día simulado, la pantalla se dibuja con esa fecha
})();
