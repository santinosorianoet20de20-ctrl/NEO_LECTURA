# NeoLectura — versión modular

Esta versión separa el código original por responsabilidades, manteniendo el contenido y la lógica originales.
Desde esta actualización incluye el **inicio de sesión** (degradé azul–turquesa, tarjeta de vidrio esmerilado) con Librín reaccionando a lo que hace el usuario.

## Estructura

- `index.html` — estructura HTML mínima y carga de archivos.
- `css/styles.css` — estilos originales de la app.
- `css/login.css` — estilos del inicio de sesión (fondo, tarjeta, botones y animaciones de Librín).
- `css/racha.css` — estilos de la racha diaria (indicador, detalle y aviso).
- `css/audio.css` — estilos del reproductor del audiolibro, del texto que se pinta mientras se lee y de las voces en Opciones (todo empieza con `ap-`).
- `css/companero.css` — Librín compañero con su globito (lectura y quiz, todo empieza con `cp-`) y el Librín chico de las tarjetas.
- `css/cuentos.css` — el camino de niveles de la pantalla principal, el dibujo de cada escena, los párrafos del cuento y el aviso de nivel desbloqueado.
- `img/racha/` — fuego de racha (`fuego.svg` encendido y `fuego-apagado.svg`).
- `img/escenas/` — los dibujos de cada cuento: `<cuento>/portada.svg` y `parte-1.svg`, `parte-2.svg`, `parte-3.svg`. Son **bocetos simples** para pasarle a otra IA; `img/escenas/LEEME.md` explica las medidas, el estilo, cómo es cada personaje, qué muestra cada escena y cómo reemplazarlos.
- `img/librin/` — Librín: la versión base (`saludo.png`) y sus 20 reacciones (PNG con fondo transparente, todas de 513×508 para que no "salte" al cambiar): `bien`, `excelente`, `guino`, `vamos`, `orgullo`, `increible`, `animo`, `ojos-cerrados`, `aprender`, `logrado` y las nuevas `muy-bien`, `segui-asi`, `mejorar`, `vos-podes`, `nublado`, `no-te-rindas`, `gran-trabajo`, `pensando`, `genial`, `triste`. Se usan en el inicio de sesión, en las tarjetas y en el compañero de lectura.
- `img/libron/` — Librón: la versión base (`saludo.png`) y sus 20 reacciones, con **los mismos nombres** que las de Librín, mismo tamaño y ubicadas igual (recortadas de la hoja de reacciones, sin fondo ni globitos).
- `js/utils.js` — utilidades, iconos, `PARRAFOS()` (párrafos y versos de los cuentos), `MASCOTA()` (Librín, o Librón si el usuario eligió su voz), `MASCOTA_RUTA('reacción')` y `MASCOTA_IMG('reacción')`, que ponen la imagen de la mascota. En `MASCOTAS` están las dos mascotas y sus **cambios de cara** (si a una le falta una cara con el mismo sentimiento, usa otra).
- `js/cuentos/` — **los cuentos: cada uno es un nivel y vive en su propio archivo** (ver «Cuentos y niveles»):
  - `cuentos.registro.js` — explica qué lleva cada cuento y define `registrarCuento()`.
  - `caperucita-roja.js`, `el-gato-con-botas.js`, `barba-azul.js`, `hansel-y-gretel.js` — texto (de los PDF del proyecto) dividido en 3 partes, vocabulario, preguntas de Librín, descripción de cada dibujo y quiz.
  - `cuentos.camino.js` — ordena los cuentos del más corto al más largo, arma los niveles (`STORIES`), marca el vocabulario, mezcla las opciones del quiz y dice qué nivel está desbloqueado (`Camino`). En `CAMINO_CFG` se cambia el orden, la carpeta de los dibujos y su formato.
- `js/data/config.js` — tamaños de letra y cantidad de partes (los jugadores inventados del ranking ya no están).
- `js/state.js` — estado, localStorage y funciones relacionadas con el progreso (un progreso por usuario). Las cuentas nuevas empiezan con **0 puntos**.
- `js/screens.js` — pantallas/interfaz.
- `js/login/` — módulo de inicio de sesión:
  - `login.config.js` — textos, frases de Librín, qué imagen usa en cada momento, avatares y reglas. **Para cambiar un texto o una reacción, se cambia acá.**
  - `login.storage.js` — cuentas (localStorage), sesión (sessionStorage) y hash de contraseñas.
  - `login.validation.js` — validación de usuario, contraseña y nombre, y fuerza de la contraseña.
  - `login.mascot.js` — Librín: cambia de imagen según el estado, se inclina hacia el puntero y muestra el globito.
  - `login.view.js` — HTML de la pantalla de inicio de sesión.
  - `login.controller.js` — eventos, reacciones de Librín y conexión con la app (entrar / salir).
- `js/racha/` — módulo de racha diaria:
  - `racha.config.js` — puntos por día, tope, imágenes y textos. **Para cambiar cuántos puntos da la racha, se cambia acá.**
  - `racha.logic.js` — fechas, estado de la racha (hecha / pendiente / apagada) y suma del día.
  - `racha.view.js` — HTML del indicador, del detalle y del aviso de racha completa.
  - `racha.controller.js` — abre y cierra las ventanas, animación del aviso.
- `js/audio/` — módulo del audiolibro (lectura en voz alta):
  - `audio.config.js` — segundos que saltan los botones, cuántas voces se muestran, **cómo suenan Librín y Librón**, velocidades y textos. **Para cambiar el salto de 5 segundos, el tono de un personaje o cuántas voces aparecen, se cambia acá.**
  - `audio.voces.js` — arma la lista de voces en español del equipo (nombre, país, mujer u hombre), los personajes y las listas de Opciones y del cuento.
  - `audio.motor.js` — habla con la voz del navegador, lleva la cuenta del tiempo y de la palabra que se está leyendo, pausa, reanuda, salta y cambia volumen, voz y velocidad.
  - `audio.view.js` — HTML del reproductor, del texto palabra por palabra, del panel de voces y de las tarjetas de Opciones (y sus íconos).
  - `audio.controller.js` — eventos de los botones, del volumen y de la elección de voz; pinta el texto mientras se lee y abre/cierra el panel de voces.
- `js/companero/` — Librín compañero de lectura:
  - `companero.config.js` — todo lo que dice Librín y qué cara pone en cada momento. **Para cambiar sus frases, se cambia acá.**
  - `companero.view.js` — HTML de Librín con su globito (lectura, preguntas del quiz y resultado).
  - `companero.controller.js` — en la lectura, cambia el comentario según el audiolibro, el vocabulario o si lo tocan.
- `js/ranking/` — ranking de cuentas reales:
  - `ranking.config.js` — textos y cuántos se muestran.
  - `ranking.storage.js` — **fuente de datos**: lee y guarda la tabla del ranking (hoy en localStorage). Es lo único que habría que cambiar para usar un servidor.
  - `ranking.logic.js` — anota los puntos de la cuenta al guardar el progreso y arma la lista ordenada.
  - `ranking.view.js` — pantalla del ranking.
- `css/ranking.css` — detalles de la pantalla del ranking (las filas usan los estilos de siempre).
- `js/pruebas/prueba-dia.js` — **TEMPORAL**: botón para cambiar de día y probar la racha (ver «Racha diaria»).
- `js/navigation.js` — navegación, eventos y lógica de interacción.

## Cuentos y niveles

Los niveles ahora son **los 4 cuentos de los PDF**, en orden del más corto al más largo. Cada uno es un nivel: **3 partes + un quiz**, igual que los niveles de antes (audiolibro, texto que se pinta, vocabulario, Librín y puntos).

| Nivel | Cuento | Duración de cada parte (aprox.) | Quiz | Para aprobar |
|---|---|---|---|---|
| 1 | Caperucita Roja (Perrault) | 1,5 · 1,6 · 1,8 min | 6 preguntas, 3 opciones | 3 correctas |
| 2 | El gato con botas (Perrault) | 3,7 · 3,6 · 3,9 min | 8 preguntas, 4 opciones | 5 correctas |
| 3 | Barba Azul (Perrault) | 4,2 · 4,1 · 4,9 min | 9 preguntas, 4 opciones | 6 correctas |
| 4 | Hansel y Gretel (Grimm) | 5,8 · 6,5 · 6,3 min | 10 preguntas, 4 opciones | 7 correctas |

- **Hay que aprobar cada nivel para pasar al siguiente.** En la pantalla principal los cuentos bloqueados tienen un candado que dice cuál hay que aprobar; tampoco se puede entrar por la dirección. Al aprobar, el resultado avisa «🔓 ¡Desbloqueaste el Nivel 2…!» y *Siguiente nivel* abre el cuento que sigue.
- **Partes de la misma duración:** cada cuento está cortado en 3 partes que duran casi lo mismo (menos de 10 % de diferencia), siempre al terminar un párrafo y en un momento de la historia que tenga sentido. En la última parte están las moralejas. Para revisarlo después de cambiar un texto: `Camino.medir()` en la consola del navegador.
- **Texto:** es el de los PDF, completo, con los errores de tipeo corregidos («pálida corno» → «como», «la oreja solamente» → «la vieja», etc.). Se ve en párrafos (las moralejas, en versos).
- **Vocabulario:** cada cuento tiene sus palabras difíciles (`palabras`) y se marcan solas la primera vez que aparecen en cada parte. Hay más en los cuentos más difíciles (castellano antiguo: «afligiros», «heredad», «dragón» como soldado…).
- **Quizzes más difíciles:** dentro de cada cuento las preguntas van por parte (dice «Sobre la parte 2») y se ponen más difíciles hacia el final; entre cuentos hay más preguntas, más opciones y hace falta acertar más. Los primeros niveles preguntan qué pasó; los últimos, por qué pasó, en qué orden, qué significa una palabra en el texto o qué enseña la moraleja.
- **Opciones:** en el archivo del cuento la primera opción es siempre la correcta; la app las mezcla al mostrarlas (siempre igual para cada pregunta).
- **Dibujos:** cada parte muestra el dibujo de su escena arriba del texto, y cada tarjeta tiene su portada (ver `img/escenas/LEEME.md`).
- **Para agregar un cuento:** copiar uno de los archivos de `js/cuentos/`, cambiar los datos, sumar su `<script>` en `index.html` (antes de `cuentos.camino.js`) y sus dibujos en `img/escenas/<id>/`. Se ubica solo en el camino según su largo (o con un orden fijo en `CAMINO_CFG.orden`).
- El progreso de los cuentos viejos (El León y el Ratón, El Roble y la Caña) ya no se usa, pero los puntos que se habían ganado se conservan.

## Inicio de sesión

- Aparece apenas se abre la app. La sesión dura mientras la pestaña esté abierta (si se recarga, sigue adentro; si se vuelve a abrir la app, pide iniciar sesión otra vez).
- **Iniciar Sesión**: usuario, contraseña (con botón para verla), "Recordarme" y "¿Olvidaste tu contraseña?". Botones **Entrar 🚀** y **Crear cuenta ✨**.
- **Crear Cuenta**: nombre, usuario (avisa si ya existe), contraseña con medidor de 1 a 3 estrellas y personaje (avatar).
- **o entra como invitado**: usa el progreso guardado de siempre (`neolectura.v1`), así no se pierde lo que ya estaba.
- Cada usuario tiene su propio progreso guardado en `neolectura.v1:<usuario>`.
- Respeta el tema Claro/Oscuro/Automático de Opciones y la opción de "reducir movimiento" del sistema.

### Reacciones de Librín

| Momento | Imagen |
|---|---|
| Esperando (se mece saludando) | `saludo.png` |
| Escribe el usuario o el nombre | `aprender.png` |
| Escribe la contraseña (no mira) | `ojos-cerrados.png` |
| Muestra la contraseña (espía) | `guino.png` |
| Error en un campo | `vamos.png` |
| Contraseña incorrecta | `animo.png` |
| Usuario libre / volver a iniciar sesión | `bien.png` |
| Contraseña súper segura | `excelente.png` |
| Elige personaje / abre Crear cuenta | `increible.png` |
| Cosquillas (tocarlo 4 veces rápido) | `orgullo.png` |
| Entró a la app (salta) | `logrado.png` |

Además se inclina hacia el puntero, da consejos si lo tocan y, si nadie lo usa por un rato, hace una reacción solo (`reaccionSola` en `login.config.js`).

## Racha diaria de lectura

- Se suma **1 día de racha al aprobar el primer quiz del día** (aprobar = llegar a las correctas que pide ese cuento). Los demás quizzes de ese día no suman otro día.
- Si pasa un día entero sin aprobar un quiz, la racha se apaga y vuelve a empezar desde 1.
- **Puntos extra**: cada día de racha da 5 puntos más que el anterior (día 1: +5, día 2: +10, día 3: +15…), con un tope de +100 por día (desde el día 20). Para comparar: leer una parte da +50 y cada respuesta correcta +100, así que la racha no desbalancea el sistema.
- **Indicador** en la tarjeta del menú principal: fuego encendido (hoy ya leíste), fuego dormido con "!" (falta el quiz de hoy) o apagado (racha en 0), con los últimos 7 días. Al tocarlo se abre el detalle (semana, récord y cuántos puntos se ganan hoy).
- **Aviso de racha completa**: aparece al aprobar el primer quiz del día, con el fuego, el número de días, la semana, los puntos ganados y "¡Nuevo récord!" si corresponde.
- Usa la fecha del dispositivo y se guarda en el progreso de cada usuario (`S.racha`). "Reiniciar progreso" en Opciones también reinicia la racha.

### Probar la racha (botón temporal)

Abajo a la izquierda hay un botón **🧪 Prueba** (solo con la sesión abierta): **Día +1** adelanta un día y **Hoy** vuelve a la fecha real. El día simulado se guarda en el navegador, así que sigue igual al recargar. Solo afecta a la racha. Ejemplo: aprobar un quiz → *Día +1* → la racha queda «pendiente» → aprobar otro quiz → 2 días (+10 puntos) → *Día +1* dos veces → la racha se apaga.

**Para quitarlo:** borrar la carpeta `js/pruebas/` y su línea `<script>` en `index.html`. La racha usa `Racha.usarReloj()` (en `racha.logic.js`), que sin el módulo de prueba sigue con la fecha real. Si después de probar quedan días «del futuro» en la racha, se limpian con *Reiniciar progreso* en Opciones.

## Ranking

- **Solo cuentas reales:** se sacaron los jugadores inventados. Aparecen únicamente las cuentas creadas con *Crear cuenta*; el invitado puede ver el ranking pero no aparece en él.
- **Se mantiene entre sesiones:** cada vez que se guarda el progreso de una cuenta (al leer una parte, al terminar un quiz, al cambiar el nombre…), se anotan su nombre, su personaje y sus puntos en una tabla guardada en el navegador (`neolectura.ranking` en localStorage). Al cerrar y volver a abrir la app, siguen ahí. Las cuentas creadas antes de esta actualización se agregan solas con el progreso que ya tenían.
- **Pantalla:** la mascota te señala («¡Buen trabajo!») y dice en qué puesto estás. Tu fila tiene borde turquesa y dice *Tú*.
- **Importante:** como la app no tiene servidor, el ranking muestra las cuentas creadas **en ese dispositivo/navegador**. Para un ranking compartido entre todas las compus hay que guardar la tabla en un servidor (por ejemplo, Supabase o Firebase): alcanza con reemplazar `ranking.storage.js` por uno que tenga las mismas funciones (`leer`, `guardar`, `borrar`).

## Librín compañero

> **Si el usuario elige la voz de Librón** (en Opciones o en el reproductor), aparece **Librón en lugar de Librín** en las tarjetas de inicio, niveles y créditos, en la lectura y en los quizzes, con las mismas reacciones y su nombre en rojo. Si lo cambia desde el reproductor, la mascota cambia en el momento. El inicio de sesión sigue con Librín, porque ahí todavía no hay un usuario con voz elegida.

Librín (con las imágenes nuevas) acompaña la lectura y los quizzes con un globito. El dibujo plano de antes ya no se usa: en las tarjetas de inicio, niveles y créditos ahora está Librín saludando, con un libro y festejando.

**En la lectura** (debajo del texto):

| Momento | Cara | Qué dice |
|---|---|---|
| Al entrar a una parte | `pensando` | La pregunta para pensar de esa parte (`librin` en el archivo del cuento). En la última parte agrega que después viene el quiz |
| Empieza el audiolibro | `guino` | Que siga con la vista las palabras azules (unos segundos y vuelve a la pregunta) |
| Por la mitad | `vos-podes` | ¡Ya vas por la mitad! |
| Pausa / sigue | `ojos-cerrados` / `segui-asi` | Hacemos una pausa… / ¡Seguimos! |
| Termina | `muy-bien` | ¡Muy bien! + «¿Ya puedes responder?» con la pregunta de la parte |
| Toca una palabra subrayada | `aprender` | Qué significa (reemplaza la cajita de definición de antes) |
| Lo tocan a él | `excelente`, `genial`, `gran-trabajo`, `segui-asi` | Algo divertido |

**En el quiz** (debajo de las opciones): da ánimo antes de responder (`vamos` en la primera, `pensando` en las del medio, `vos-podes` en la última), festeja los aciertos con globo verde (`muy-bien`, `gran-trabajo`, `genial`, `excelente`, `increible`, van rotando) y en los errores dice cuál era la respuesta con globo rojo y **siempre con cara triste** (`no-te-rindas`, preocupado, o `nublado`; como el `no-te-rindas` de Librón sonríe, Librón usa `nublado` en su lugar). En el resultado: `increible` si respondió todo bien, `logrado` si aprobó, `orgullo` si terminó el último cuento del camino, `nublado` («Si te cuesta un poco más, está bien…») si no aprobó y `triste` («Hoy no te salió como querías… pero cada intento es una nueva oportunidad») si no acertó ninguna. En el ranking, la mascota te señala (`gran-trabajo`). Al terminar el quiz siempre está el botón **🏠 Volver al menú** (a la pantalla principal), además de *Siguiente nivel* / *Ver el cuento* o *Repasar* / *Reintentar*.

Para un cuento nuevo, alcanza con ponerle `librin:'…'` a cada parte; si falta, Librín dice una frase general.

## Audiolibro (lectura en voz alta)

En cada parte del cuento, debajo del título, hay un reproductor compacto:

| Botón | Qué hace |
|---|---|
| ⏮ | Reinicia la parte desde el principio y la lee de nuevo |
| ↺5 | Retrocede 5 segundos |
| ▶ Escuchar / ⏸ Pausar / ▶ Reanudar | Un solo botón para iniciar, pausar y reanudar (cambia según el momento). Al terminar dice **Otra vez** |
| 5↻ | Adelanta 5 segundos |
| 🔊 + barrita | Volumen. Tocar el parlante silencia / vuelve al volumen anterior |
| 🗣 Elena ▾ | Abre el panel con las **voces principales**, **Librín y Librón**, y la **velocidad** (en el celular sube desde abajo) |

- Abajo de los botones se ve el avance (tiempo actual, barra y duración).
- El volumen es el mismo que el de **Opciones → Volumen de la voz** (versión grande, con porcentaje y botón **Probar**). Se guarda en el progreso de cada usuario (`S.vol`, de 0 a 1).
- El audio se corta solo al pasar de parte, al tocar «Volver», al usar el botón atrás del navegador y al cerrar sesión.
- En compu el reproductor ocupa una fila; en tablet, dos; en celular, tres (botones · avance · voz y volumen).

### Texto sincronizado

- Mientras suena, el texto se **pinta del azul de la app** (`#1B7DCB`; en modo oscuro, un celeste que se lee bien) a medida que se lee, y la palabra que se está diciendo queda **resaltada**.
- En pausa queda marcada la palabra desde donde va a seguir; con ⏮, ↺5 y 5↻ el pintado se mueve junto con el audio; al terminar queda todo pintado.
- Si el texto es largo (letra "Muy grande", celular), la pantalla **acompaña la lectura** sola. Si el usuario mueve la pantalla para mirar otra cosa, deja de acompañar hasta que toque un botón del reproductor.
- Las palabras del vocabulario siguen siendo botones con su definición.
- Con las voces que avisan por qué palabra van (las de Windows, las naturales de Edge, las de Mac/iPhone) el pintado es exacto. Con las que no avisan (las de Google en Chrome) se calcula por tiempo, contando una pausita en cada coma, y se vuelve a acomodar al empezar cada frase.

### Voces

- **Dónde se eligen:** en **Opciones → Voz del audiolibro** y en el botón 🗣 del reproductor de cada cuento. Es la misma elección (se guarda en `S.voz` y `S.ritmo` de cada usuario), así que se cambia en un lado y se ve en el otro.
- **En el cuento:** 2 de mujer, 2 de hombre y los personajes **Librín y Librón**, así se puede cambiar de uno a otro sin salir del cuento (y la mascota cambia en el momento). Abajo está la velocidad y el enlace «Más voces en Opciones».
- **En Opciones (unas 12):** hasta **5 de mujer y 5 de hombre** (en compu, en dos columnas) y los **personajes** Librín y Librón. Cada voz muestra su país y si es *Natural* o *Necesita internet*.
- **Qué voces aparecen primero:** Argentina, Uruguay, Latinoamérica, Estados Unidos y España al final (orden en `paises` de `audio.config.js`); dentro de cada país, las naturales y después las instaladas.
- **Mujer u hombre:** el navegador no lo dice, así que se adivina por el nombre de la voz (Elena, Tomás, Sabina, Raúl…). Si un equipo no tiene voces de algún tipo, se completa con las que haya y Opciones lo avisa. Si la voz elegida no está entre las que se muestran, igual aparece (ocupa el último lugar de su grupo).
- **Personajes** (voces propias, armadas sobre una voz del equipo cambiándole el tono):
  - 📘 **Librín** — aguda y divertida, pensada para los más chicos (sobre una voz de mujer, tono 1,65).
  - 📚 **Librón** (el libro rojo con barba, `img/libron/saludo.png`; cuando se lo elige, también reemplaza a Librín como mascota) — grave y tranquila, más madura (sobre una voz de hombre, tono 0,7 y un poco más lenta).
  - Se ajustan en `personajes` de `audio.config.js`, y `personajesCuento` dice cuáles aparecen en el panel del cuento (ahora los dos, para poder cambiar entre Librín y Librón ahí mismo).
- **Velocidad:** 🙂 Normal o 🐢 Lenta, para cualquier voz (también para los personajes).
- **Cambiar mientras suena:** el cuento sigue desde la misma palabra con la voz o la velocidad nueva. Si está en pausa o sin empezar, la voz saluda ("¡Hola! Soy Elena…") para que se escuche cómo es, sin perder por dónde iba.
- **Cuántas voces hay depende del equipo**, porque las pone el navegador y no NeoLectura: en **Microsoft Edge** hay decenas de voces naturales en español (también de Argentina); en Chrome están las de Google y las del sistema; en Windows se pueden sumar voces desde *Configuración → Hora e idioma → Voz*. Si la voz elegida no está en el equipo (por ejemplo, se eligió en otra compu), se usa la primera de la lista y Opciones lo avisa.
- Algunas voces ignoran el tono. Por eso los personajes se arman, si se puede, sobre una voz instalada en el equipo (esas sí lo cambian).
- Quien tenía elegido el estilo Librín o Gigante de una versión anterior (o la voz Gigante) pasa solo a la voz Librín o Librón.

### Cómo funciona por dentro

La app usa la voz del navegador (Web Speech API), que no tiene barra de tiempo ni deja adelantar o retroceder. Por eso `audio.motor.js`:

1. Corta el texto en frases y las lee de a una (así Chrome no corta la voz a los ~15 segundos).
2. Guarda la posición como "letra por la que va" y la convierte a segundos con una velocidad estimada (las comas cuentan como unas letras más, por la pausita). Esa velocidad se ajusta sola midiendo cuánto tarda la voz real en cada frase. Si la voz avisa por qué palabra va (evento `boundary`), se usa ese dato, que es exacto.
3. Pausar = cortar la voz y recordar la palabra; reanudar = volver a hablar desde esa palabra (funciona igual en todos los navegadores).
4. Adelantar/retroceder = mover la posición 5 segundos (redondeando al comienzo de una palabra) y seguir hablando desde ahí.
5. Si se cambia el volumen, la voz o la velocidad mientras suena, sigue desde la misma palabra con el cambio aplicado.
6. Como cada voz habla a su ritmo, la velocidad estimada se guarda por voz, y la velocidad elegida la multiplica (por eso con "Lenta" la duración del cuento se ve más larga).
7. Para pintar el texto, cada palabra va en un `<span data-i="…">` con la letra donde empieza; el controlador marca como `leido` las anteriores a la palabra actual y como `actual` la que se está diciendo.

> Como los tiempos son estimados, los 5 segundos pueden no ser exactos al primer salto; después de la primera frase la estimación se ajusta. Algunas voces (por ejemplo, en algunos Android) ignoran el volumen: en ese caso se usa el volumen del dispositivo.

> Es un prototipo sin servidor: las cuentas quedan guardadas en el navegador de este dispositivo. En una app real, el usuario y la contraseña se verifican en un servidor.

## Importante

Las cuentas nuevas (y el invitado nuevo) empiezan con **0 puntos** (`points` en `DEF`, `js/state.js`). *Reiniciar progreso* también vuelve a 0. Las cuentas que ya existían conservan sus puntos.

Abrir `index.html` desde un servidor local/repo web es recomendable para probar el proyecto (también funciona abriéndolo directo).
