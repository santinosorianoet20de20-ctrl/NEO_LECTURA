# NeoLectura — versión modular

Esta versión separa el código original por responsabilidades, manteniendo el contenido y la lógica originales.
Desde esta actualización incluye el **inicio de sesión** (degradé azul–turquesa, tarjeta de vidrio esmerilado) con Librín reaccionando a lo que hace el usuario.

## Estructura

- `index.html` — estructura HTML mínima y carga de archivos.
- `css/styles.css` — estilos originales de la app.
- `css/login.css` — estilos del inicio de sesión (fondo, tarjeta, botones y animaciones de Librín).
- `css/racha.css` — estilos de la racha diaria (indicador, detalle y aviso).
- `css/audio.css` — estilos del reproductor del audiolibro, del texto que se pinta mientras se lee y de las voces en Opciones (todo empieza con `ap-`).
- `css/companero.css` — Librín compañero con su globito (lectura y quiz, todo empieza con `cp-`) y el Librín chico de las tarjetas.
- `img/racha/` — fuego de racha (`fuego.svg` encendido y `fuego-apagado.svg`).
- `img/librin/` — Librín: la versión base (`saludo.png`) y sus 10 reacciones (PNG con fondo transparente, todas de 513×508 para que no "salte" al cambiar). Se usan en el inicio de sesión, en las tarjetas y en el compañero de lectura.
- `img/libron/` — Librón: la versión base (`saludo.png`) y sus 10 reacciones, con **los mismos nombres** que las de Librín, mismo tamaño y ubicadas igual (recortadas de la hoja de reacciones, sin fondo ni globitos).
- `js/utils.js` — utilidades, iconos, `MASCOTA()` (Librín, o Librón si el usuario eligió su voz) y `MASCOTA_IMG('reacción')`, que pone la imagen de la mascota (reemplaza al dibujo plano de antes).
- `js/illustrations.js` — ilustraciones SVG y generación de portadas.
- `js/data/stories.js` — cuentos, niveles, partes y preguntas. Cada parte tiene `lb`: lo que dice Librín mientras se lee (una pregunta para pensar).
- `js/data/config.js` — ranking inicial, tamaños de letra y cantidad de partes.
- `js/state.js` — estado, localStorage y funciones relacionadas con el progreso (ahora con un progreso por usuario).
- `js/screens.js` — pantallas/interfaz.
- `js/login/` — módulo de inicio de sesión:
  - `login.config.js` — textos, frases de Librín, qué imagen usa en cada momento, avatares y reglas. **Para cambiar un texto o una reacción, se cambia acá.**
  - `login.storage.js` — cuentas (localStorage), sesión (sessionStorage) y hash de contraseñas.
  - `login.validation.js` — validación de usuario, contraseña y nombre, y fuerza de la contraseña.
  - `login.mascot.js` — Librín: cambia de imagen según el estado, se inclina hacia el puntero y muestra el globito.
  - `login.view.js` — HTML de la pantalla de inicio de sesión.
  - `login.controller.js` — eventos, reacciones de Librín y conexión con la app (entrar / salir).
- `js/racha/` — módulo de racha diaria:
  - `racha.config.js` — puntos por día, tope, imágenes y textos. **Para cambiar cuántos puntos da la racha, se cambia acá.**
  - `racha.logic.js` — fechas, estado de la racha (hecha / pendiente / apagada) y suma del día.
  - `racha.view.js` — HTML del indicador, del detalle y del aviso de racha completa.
  - `racha.controller.js` — abre y cierra las ventanas, animación del aviso.
- `js/audio/` — módulo del audiolibro (lectura en voz alta):
  - `audio.config.js` — segundos que saltan los botones, cuántas voces se muestran, **cómo suenan Librín y Librón**, velocidades y textos. **Para cambiar el salto de 5 segundos, el tono de un personaje o cuántas voces aparecen, se cambia acá.**
  - `audio.voces.js` — arma la lista de voces en español del equipo (nombre, país, mujer u hombre), los personajes y las listas de Opciones y del cuento.
  - `audio.motor.js` — habla con la voz del navegador, lleva la cuenta del tiempo y de la palabra que se está leyendo, pausa, reanuda, salta y cambia volumen, voz y velocidad.
  - `audio.view.js` — HTML del reproductor, del texto palabra por palabra, del panel de voces y de las tarjetas de Opciones (y sus íconos).
  - `audio.controller.js` — eventos de los botones, del volumen y de la elección de voz; pinta el texto mientras se lee y abre/cierra el panel de voces.
- `js/companero/` — Librín compañero de lectura:
  - `companero.config.js` — todo lo que dice Librín y qué cara pone en cada momento. **Para cambiar sus frases, se cambia acá.**
  - `companero.view.js` — HTML de Librín con su globito (lectura, preguntas del quiz y resultado).
  - `companero.controller.js` — en la lectura, cambia el comentario según el audiolibro, el vocabulario o si lo tocan.
- `js/navigation.js` — navegación, eventos y lógica de interacción.

## Inicio de sesión

- Aparece apenas se abre la app. La sesión dura mientras la pestaña esté abierta (si se recarga, sigue adentro; si se vuelve a abrir la app, pide iniciar sesión otra vez).
- **Iniciar Sesión**: usuario, contraseña (con botón para verla), "Recordarme" y "¿Olvidaste tu contraseña?". Botones **Entrar 🚀** y **Crear cuenta ✨**.
- **Crear Cuenta**: nombre, usuario (avisa si ya existe), contraseña con medidor de 1 a 3 estrellas y personaje (avatar).
- **o entra como invitado**: usa el progreso guardado de siempre (`neolectura.v1`), así no se pierde lo que ya estaba.
- Cada usuario tiene su propio progreso guardado en `neolectura.v1:<usuario>`.
- Respeta el tema Claro/Oscuro/Automático de Opciones y la opción de "reducir movimiento" del sistema.

### Reacciones de Librín

| Momento | Imagen |
|---|---|
| Esperando (se mece saludando) | `saludo.png` |
| Escribe el usuario o el nombre | `aprender.png` |
| Escribe la contraseña (no mira) | `ojos-cerrados.png` |
| Muestra la contraseña (espía) | `guino.png` |
| Error en un campo | `vamos.png` |
| Contraseña incorrecta | `animo.png` |
| Usuario libre / volver a iniciar sesión | `bien.png` |
| Contraseña súper segura | `excelente.png` |
| Elige personaje / abre Crear cuenta | `increible.png` |
| Cosquillas (tocarlo 4 veces rápido) | `orgullo.png` |
| Entró a la app (salta) | `logrado.png` |

Además se inclina hacia el puntero, da consejos si lo tocan y, si nadie lo usa por un rato, hace una reacción solo (`reaccionSola` en `login.config.js`).

## Racha diaria de lectura

- Se suma **1 día de racha al aprobar el primer quiz del día** (aprobar = la mitad de las respuestas o más). Los demás quizzes de ese día no suman otro día.
- Si pasa un día entero sin aprobar un quiz, la racha se apaga y vuelve a empezar desde 1.
- **Puntos extra**: cada día de racha da 5 puntos más que el anterior (día 1: +5, día 2: +10, día 3: +15…), con un tope de +100 por día (desde el día 20). Para comparar: leer una parte da +50 y cada respuesta correcta +100, así que la racha no desbalancea el sistema.
- **Indicador** en la tarjeta del menú principal: fuego encendido (hoy ya leíste), fuego dormido con "!" (falta el quiz de hoy) o apagado (racha en 0), con los últimos 7 días. Al tocarlo se abre el detalle (semana, récord y cuántos puntos se ganan hoy).
- **Aviso de racha completa**: aparece al aprobar el primer quiz del día, con el fuego, el número de días, la semana, los puntos ganados y "¡Nuevo récord!" si corresponde.
- Usa la fecha del dispositivo y se guarda en el progreso de cada usuario (`S.racha`). "Reiniciar progreso" en Opciones también reinicia la racha.

## Librín compañero

> **Si el usuario elige la voz de Librón** (en Opciones o en el reproductor), aparece **Librón en lugar de Librín** en las tarjetas de inicio, niveles y créditos, en la lectura y en los quizzes, con las mismas reacciones y su nombre en rojo. Si lo cambia desde el reproductor, la mascota cambia en el momento. El inicio de sesión sigue con Librín, porque ahí todavía no hay un usuario con voz elegida.

Librín (con las imágenes nuevas) acompaña la lectura y los quizzes con un globito. El dibujo plano de antes ya no se usa: en las tarjetas de inicio, niveles y créditos ahora está Librín saludando, con un libro y festejando.

**En la lectura** (debajo del texto):

| Momento | Cara | Qué dice |
|---|---|---|
| Al entrar a una parte | `aprender` | La pregunta para pensar de esa parte (`lb` en `stories.js`). En la última parte agrega que después viene el quiz |
| Empieza el audiolibro | `guino` | Que siga con la vista las palabras azules (unos segundos y vuelve a la pregunta) |
| Por la mitad | `vamos` | ¡Ya vas por la mitad! |
| Pausa / sigue | `ojos-cerrados` / `guino` | Hacemos una pausa… / ¡Seguimos! |
| Termina | `bien` | ¡Muy bien! + «¿Ya puedes responder?» con la pregunta de la parte |
| Toca una palabra subrayada | `aprender` | Qué significa (reemplaza la cajita de definición de antes) |
| Lo tocan a él | `excelente`, `increible`… | Algo divertido |

**En el quiz** (debajo de las opciones): da ánimo antes de responder (`vamos`), festeja los aciertos con globo verde (`bien`, `excelente`, `increible`, `orgullo`, van rotando) y en los errores dice cuál era la respuesta con globo rojo (`animo`). En el resultado: `increible` si respondió todo bien, `logrado` si aprobó, `orgullo` si terminó el cuento y `ojos-cerrados` («¡Cada día mejoras más!») si no aprobó. Al terminar el quiz siempre está el botón **🏠 Volver al menú** (a la pantalla principal), además de *Siguiente nivel* / *Ver niveles* o *Repasar* / *Reintentar*.

Para agregar un cuento nuevo, alcanza con ponerle `lb:'…'` a cada parte; si falta, Librín dice una frase general.

## Audiolibro (lectura en voz alta)

En cada parte del cuento, debajo del título, hay un reproductor compacto:

| Botón | Qué hace |
|---|---|
| ⏮ | Reinicia la parte desde el principio y la lee de nuevo |
| ↺5 | Retrocede 5 segundos |
| ▶ Escuchar / ⏸ Pausar / ▶ Reanudar | Un solo botón para iniciar, pausar y reanudar (cambia según el momento). Al terminar dice **Otra vez** |
| 5↻ | Adelanta 5 segundos |
| 🔊 + barrita | Volumen. Tocar el parlante silencia / vuelve al volumen anterior |
| 🗣 Elena ▾ | Abre el panel con las **voces principales**, **Librín y Librón**, y la **velocidad** (en el celular sube desde abajo) |

- Abajo de los botones se ve el avance (tiempo actual, barra y duración).
- El volumen es el mismo que el de **Opciones → Volumen de la voz** (versión grande, con porcentaje y botón **Probar**). Se guarda en el progreso de cada usuario (`S.vol`, de 0 a 1).
- El audio se corta solo al pasar de parte, al tocar «Volver», al usar el botón atrás del navegador y al cerrar sesión.
- En compu el reproductor ocupa una fila; en tablet, dos; en celular, tres (botones · avance · voz y volumen).

### Texto sincronizado

- Mientras suena, el texto se **pinta del azul de la app** (`#1B7DCB`; en modo oscuro, un celeste que se lee bien) a medida que se lee, y la palabra que se está diciendo queda **resaltada**.
- En pausa queda marcada la palabra desde donde va a seguir; con ⏮, ↺5 y 5↻ el pintado se mueve junto con el audio; al terminar queda todo pintado.
- Si el texto es largo (letra "Muy grande", celular), la pantalla **acompaña la lectura** sola. Si el usuario mueve la pantalla para mirar otra cosa, deja de acompañar hasta que toque un botón del reproductor.
- Las palabras del vocabulario siguen siendo botones con su definición.
- Con las voces que avisan por qué palabra van (las de Windows, las naturales de Edge, las de Mac/iPhone) el pintado es exacto. Con las que no avisan (las de Google en Chrome) se calcula por tiempo, contando una pausita en cada coma, y se vuelve a acomodar al empezar cada frase.

### Voces

- **Dónde se eligen:** en **Opciones → Voz del audiolibro** y en el botón 🗣 del reproductor de cada cuento. Es la misma elección (se guarda en `S.voz` y `S.ritmo` de cada usuario), así que se cambia en un lado y se ve en el otro.
- **En el cuento:** 2 de mujer, 2 de hombre y los personajes **Librín y Librón**, así se puede cambiar de uno a otro sin salir del cuento (y la mascota cambia en el momento). Abajo está la velocidad y el enlace «Más voces en Opciones».
- **En Opciones (unas 12):** hasta **5 de mujer y 5 de hombre** (en compu, en dos columnas) y los **personajes** Librín y Librón. Cada voz muestra su país y si es *Natural* o *Necesita internet*.
- **Qué voces aparecen primero:** Argentina, Uruguay, Latinoamérica, Estados Unidos y España al final (orden en `paises` de `audio.config.js`); dentro de cada país, las naturales y después las instaladas.
- **Mujer u hombre:** el navegador no lo dice, así que se adivina por el nombre de la voz (Elena, Tomás, Sabina, Raúl…). Si un equipo no tiene voces de algún tipo, se completa con las que haya y Opciones lo avisa. Si la voz elegida no está entre las que se muestran, igual aparece (ocupa el último lugar de su grupo).
- **Personajes** (voces propias, armadas sobre una voz del equipo cambiándole el tono):
  - 📘 **Librín** — aguda y divertida, pensada para los más chicos (sobre una voz de mujer, tono 1,65).
  - 📚 **Librón** (el libro rojo con barba, `img/libron/saludo.png`; cuando se lo elige, también reemplaza a Librín como mascota) — grave y tranquila, más madura (sobre una voz de hombre, tono 0,7 y un poco más lenta).
  - Se ajustan en `personajes` de `audio.config.js`, y `personajesCuento` dice cuáles aparecen en el panel del cuento (ahora los dos, para poder cambiar entre Librín y Librón ahí mismo).
- **Velocidad:** 🙂 Normal o 🐢 Lenta, para cualquier voz (también para los personajes).
- **Cambiar mientras suena:** el cuento sigue desde la misma palabra con la voz o la velocidad nueva. Si está en pausa o sin empezar, la voz saluda ("¡Hola! Soy Elena…") para que se escuche cómo es, sin perder por dónde iba.
- **Cuántas voces hay depende del equipo**, porque las pone el navegador y no NeoLectura: en **Microsoft Edge** hay decenas de voces naturales en español (también de Argentina); en Chrome están las de Google y las del sistema; en Windows se pueden sumar voces desde *Configuración → Hora e idioma → Voz*. Si la voz elegida no está en el equipo (por ejemplo, se eligió en otra compu), se usa la primera de la lista y Opciones lo avisa.
- Algunas voces ignoran el tono. Por eso los personajes se arman, si se puede, sobre una voz instalada en el equipo (esas sí lo cambian).
- Quien tenía elegido el estilo Librín o Gigante de una versión anterior (o la voz Gigante) pasa solo a la voz Librín o Librón.

### Cómo funciona por dentro

La app usa la voz del navegador (Web Speech API), que no tiene barra de tiempo ni deja adelantar o retroceder. Por eso `audio.motor.js`:

1. Corta el texto en frases y las lee de a una (así Chrome no corta la voz a los ~15 segundos).
2. Guarda la posición como "letra por la que va" y la convierte a segundos con una velocidad estimada (las comas cuentan como unas letras más, por la pausita). Esa velocidad se ajusta sola midiendo cuánto tarda la voz real en cada frase. Si la voz avisa por qué palabra va (evento `boundary`), se usa ese dato, que es exacto.
3. Pausar = cortar la voz y recordar la palabra; reanudar = volver a hablar desde esa palabra (funciona igual en todos los navegadores).
4. Adelantar/retroceder = mover la posición 5 segundos (redondeando al comienzo de una palabra) y seguir hablando desde ahí.
5. Si se cambia el volumen, la voz o la velocidad mientras suena, sigue desde la misma palabra con el cambio aplicado.
6. Como cada voz habla a su ritmo, la velocidad estimada se guarda por voz, y la velocidad elegida la multiplica (por eso con "Lenta" la duración del cuento se ve más larga).
7. Para pintar el texto, cada palabra va en un `<span data-i="…">` con la letra donde empieza; el controlador marca como `leido` las anteriores a la palabra actual y como `actual` la que se está diciendo.

> Como los tiempos son estimados, los 5 segundos pueden no ser exactos al primer salto; después de la primera frase la estimación se ajusta. Algunas voces (por ejemplo, en algunos Android) ignoran el volumen: en ese caso se usa el volumen del dispositivo.

> Es un prototipo sin servidor: las cuentas quedan guardadas en el navegador de este dispositivo. En una app real, el usuario y la contraseña se verifican en un servidor.

## Importante

Las cuentas nuevas empiezan con los puntos de `DEF` en `js/state.js` (1.250, igual que antes). Si se quiere que empiecen en 0, se cambia `points` en `DEF`.

Abrir `index.html` desde un servidor local/repo web es recomendable para probar el proyecto (también funciona abriéndolo directo).
