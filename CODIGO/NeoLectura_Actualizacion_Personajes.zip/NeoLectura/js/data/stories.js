/* =====================  CONTENIDO  ===================== */
/* Para usar tus propias fotos: agrega  img:'ruta/foto.jpg'  a cualquier cuento.
   lb: lo que dice Librín en esa parte (una pregunta para pensar mientras se lee). Si falta, dice una frase general. */
const STORIES=[
 {id:'leon',title:'El León y el Ratón',genre:'Fábula',art:'lion',open:true,levels:[
  {name:'El Encuentro',parts:[
   {t:'El sueño del león',x:'Era una tarde muy calurosa en la {sabana|Llanura enorme con mucho pasto y pocos árboles.}. El gran león, cansado de tanto caminar, se tumbó a la sombra de un árbol y se quedó profundamente dormido. Los demás animales pasaban de puntillas para no despertar al rey.',lb:'¿Por qué crees que los animales caminaban de puntillas? 🤫'},
   {t:'El tropiezo del ratón',x:'Un ratoncito que buscaba semillas no vio al león y, sin querer, corrió por encima de su {melena|El pelo largo y abundante que rodea la cabeza del león.}. ¡Zas! El león abrió un ojo, luego el otro, y con su enorme pata atrapó al pobre ratón.',lb:'¡Uy! ¿Qué crees que hará el león con el ratón? 😮'},
   {t:'El trato',x:'—¡Perdón, majestad! —chilló el ratón—. Si me deja ir, algún día se lo pagaré. ¡Le prometo que lo ayudaré! El león soltó una carcajada: ¿cómo podría ayudarlo alguien tan pequeño? Pero se sintió generoso y lo dejó libre.',lb:'¿Por qué se ríe el león de la promesa del ratón? 🤔'}],
   quiz:[{q:'¿Dónde se quedó dormido el león?',o:['A la sombra de un árbol','Dentro de una cueva','Junto al río'],a:0},
         {q:'¿Qué le prometió el ratón al león?',o:['Traerle comida','Ayudarlo algún día','No molestarlo nunca más'],a:1}]},
  {name:'La Promesa Cumplida',parts:[
   {t:'La trampa',x:'Pasaron los días. Una mañana, unos cazadores atraparon al león en una gruesa red de cuerdas. Por más que {rugía|Hacía el sonido fuerte y grave de los leones.} y se sacudía, no lograba soltarse.',lb:'¿Quién crees que podría ayudar al león ahora?'},
   {t:'El rugido lejano',x:'El ratón escuchó unos rugidos a lo lejos y reconoció esa voz al instante. —¡Es mi amigo el león! —pensó, y salió corriendo hacia el lugar tan rápido como se lo permitieron sus patitas.',lb:'¿Cómo supo el ratón que el que rugía era su amigo? 👂'},
   {t:'Dientes pequeños',x:'El ratoncito trepó por la red y comenzó a {roer|Cortar algo con los dientes, de a poquito.} las cuerdas, una por una. Después de un buen rato, la red se abrió y el león quedó libre.',lb:'¿Qué usó el ratón para liberar al león? 🐭'}],
   quiz:[{q:'¿Cómo atraparon al león los cazadores?',o:['Con una red de cuerdas','Con un pozo profundo','Con una jaula de hierro'],a:0},
         {q:'¿Cómo liberó el ratón al león?',o:['Empujando la red','Royendo las cuerdas','Llamando a otros animales'],a:1}]},
  {name:'Una Amistad Inesperada',parts:[
   {t:'Te debo la vida',x:'—Nunca creí que alguien tan pequeño pudiera salvarme —dijo el león, emocionado—. Te debo la vida, amigo. El ratón sonrió: —Una promesa es una promesa, majestad.',lb:'¿El ratón cumplió su promesa? ¿Cómo te das cuenta?'},
   {t:'Dos amigos inseparables',x:'Desde ese día, el león y el ratón se hicieron {inseparables|Que siempre están juntos y no quieren separarse.}. Compartían la sombra del árbol y, mientras el león descansaba, el ratón le contaba historias de sus aventuras entre los pastizales.',lb:'¿Qué cosas compartían el león y el ratón?'},
   {t:'Lo que dijo la sabana',x:'Los demás animales no lo podían creer: ¡el rey de la sabana, amigo de un ratón! Pero al verlos tan felices juntos, comprendieron que la amistad no se mide por el tamaño.',lb:'Para los animales, ¿la amistad se mide por el tamaño?'}],
   quiz:[{q:'¿Qué le dijo el león al ratón después de ser liberado?',o:['Que le debía la vida','Que se fuera de la sabana','Que volviera mañana'],a:0},
         {q:'¿Qué comprendieron los demás animales?',o:['Que los leones son los mejores amigos','Que la amistad no se mide por el tamaño','Que los ratones son muy rápidos'],a:1}]},
  {name:'El Valor de lo Pequeño',parts:[
   {t:'La pregunta de la jirafa',x:'Un día, una jirafa le preguntó al ratón: —¿No te da miedo andar con un león? El ratón pensó un momento y respondió: —Al principio sí, pero descubrí que el valor no depende del tamaño.',lb:'¿Qué le respondió el ratón a la jirafa? ¿Estás de acuerdo?'},
   {t:'Lo que aprendió el ratón',x:'El ratón siempre creyó que era demasiado chico para hacer cosas importantes. Ahora sabía que un gesto {valiente|Que actúa con coraje, aun cuando siente miedo.} puede cambiarlo todo, incluso si lo hace alguien pequeño.',lb:'¿Alguna vez hiciste algo valiente aunque te sentías pequeño? 💪'},
   {t:'Lo que aprendió el león',x:'El león también aprendió algo valioso: ser rey no es solo tener fuerza, sino saber ser amable y agradecido con quienes te ayudan.',lb:'Además de fuerte, ¿cómo tiene que ser un buen rey? 👑'}],
   quiz:[{q:'¿Qué descubrió el ratón sobre el valor?',o:['Que solo lo tienen los grandes','Que se pierde con el miedo','Que no depende del tamaño'],a:2},
         {q:'¿Qué aprendió el león?',o:['Que ser rey es solo tener fuerza','Que hay que ser amable y agradecido','Que los ratones son peligrosos'],a:1}]},
  {name:'La Gran Lección',parts:[
   {t:'La moraleja',x:'Toda fábula termina con una {moraleja|Enseñanza que deja una historia.}. La de esta es clara: la bondad siempre regresa. Quien ayuda hoy puede recibir ayuda mañana, aunque no lo espere.',lb:'¿Te animas a decir la moraleja con tus propias palabras?'},
   {t:'Nadie es demasiado pequeño',x:'También aprendimos que nadie es demasiado pequeño para ayudar ni demasiado grande para dar las gracias. Cada uno, a su manera, puede hacer algo importante por los demás.',lb:'¿Qué cosa importante puedes hacer tú por los demás?'},
   {t:'Ahora te toca a ti',x:'Piensa: ¿a quién puedes ayudar hoy? Compartir un lápiz, prestar un cuaderno o regalar una sonrisa son pequeños gestos que, como el del ratón, pueden ser enormes.',lb:'Piensa en un pequeño gesto que puedas hacer hoy 😊'}],
   quiz:[{q:'¿Cuál es la moraleja de la fábula?',o:['Que los fuertes siempre ganan','Que la bondad siempre regresa','Que hay que evitar a los ratones'],a:1},
         {q:'Según la fábula, ¿quién puede ayudar a los demás?',o:['Solo los más grandes','Solo los más rápidos','Cualquiera, sin importar su tamaño'],a:2}]}
 ]},
 {id:'roble',title:'El Roble y la Caña',genre:'Fábula',art:'storm',open:true,levels:[
  {name:'El Roble Orgulloso',parts:[
   {t:'El roble presumido',x:'En la orilla de un río crecían un {roble|Árbol grande y fuerte, de tronco grueso y madera dura.} enorme y una delgada caña. El roble, muy orgulloso de su altura, miraba a todos desde arriba y presumía de su fuerza.',lb:'¿Cómo era el roble? ¿Y cómo era la caña? 🌳'},
   {t:'La humilde caña',x:'—Pobre caña —decía el roble—. Cualquier brisa te hace temblar. Yo, en cambio, soy tan fuerte que nada me mueve. La caña no respondía; solo se mecía con el viento, tranquila.',lb:'¿Por qué crees que la caña no le respondía al roble?'},
   {t:'Nubes en el cielo',x:'Una tarde, el cielo se llenó de nubes oscuras. Las aves volaron a esconderse y el aire se volvió frío. El roble levantó sus ramas, seguro de que nada podría contra él.',lb:'Se viene algo… ¿qué crees que va a pasar? ⛈️'}],
   quiz:[{q:'¿Dónde crecían el roble y la caña?',o:['En la orilla de un río','En lo alto de una montaña','En medio del desierto'],a:0},
         {q:'¿De qué presumía el roble?',o:['De sus frutos dulces','De su altura y su fuerza','De sus flores'],a:1}]},
  {name:'La Tormenta',parts:[
   {t:'El viento llega',x:'De pronto comenzó a soplar un viento muy fuerte. Las hojas volaban por el aire y el río se llenó de olas.',lb:'¿Cómo te imaginas ese viento tan fuerte? 🌬️'},
   {t:'La caña se inclina',x:'La caña, al sentir el viento, se inclinó hasta casi tocar el agua. Cuando el viento pasaba, ella volvía a levantarse, una y otra vez.',lb:'Fíjate qué hace la caña cada vez que sopla el viento.'},
   {t:'El roble resiste',x:'El roble, en cambio, se puso rígido. —¡A mí nadie me dobla! —gritó. Pero el viento sopló cada vez más fuerte y sus ramas empezaron a crujir.',lb:'¿Qué hace el roble distinto de la caña?'}],
   quiz:[{q:'¿Qué hizo la caña cuando llegó el viento?',o:['Se inclinó','Salió corriendo','Se quebró'],a:0},
         {q:'¿Cómo reaccionó el roble?',o:['Se dobló como la caña','Se puso rígido y resistió','Pidió ayuda'],a:1}]},
  {name:'El Crujido del Roble',parts:[
   {t:'Lluvia y truenos',x:'Cayó una lluvia {torrencial|Muy fuerte y abundante.} y los truenos retumbaron en todo el valle. Los relámpagos iluminaban el campo como si fuera de día.',lb:'¿Qué quiere decir que la lluvia fue «torrencial»? ¡Toca la palabra!'},
   {t:'Cada vez más fuerte',x:'El viento no se cansaba. La caña seguía doblándose con cada ráfaga y el roble seguía firme, aunque ya nadie escuchaba sus palabras orgullosas.',lb:'¿Quién crees que va a aguantar mejor la tormenta?'},
   {t:'¡Crac!',x:'Entonces se oyó un enorme ¡CRAC! Una ráfaga gigante arrancó al roble de raíz y lo arrojó al río. Sus ramas quedaron flotando en el agua.',lb:'¡CRAC! ¿Qué le pasó al roble? 😲'}],
   quiz:[{q:'¿Qué le pasó al roble?',o:['Perdió solo unas hojas','Fue arrancado de raíz','Se convirtió en caña'],a:1},
         {q:'¿Qué se oyó cuando el roble cayó?',o:['Una suave canción','Un susurro','Un fuerte ¡CRAC!'],a:2}]},
  {name:'Después del Viento',parts:[
   {t:'Vuelve la calma',x:'Cuando la tormenta terminó, el cielo se aclaró y salió el sol. Todo el campo estaba en silencio y brillaba de agua.',lb:'¿Cómo quedó el campo después de la tormenta? ☀️'},
   {t:'La sorpresa del roble',x:'El roble, tendido en el río, miró a la caña sin poder creerlo: —¿Cómo es que tú, tan delgada, sigues en pie, y yo, tan fuerte, he caído?',lb:'¿Por qué el roble no podía creer lo que veía?'},
   {t:'La respuesta de la caña',x:'La caña sonrió y respondió con dulzura: —Tú luchaste contra el viento con tu fuerza. Yo, en cambio, me incliné ante él, y por eso sigo aquí.',lb:'¿Qué hizo la caña para seguir en pie?'}],
   quiz:[{q:'¿Cómo estaba el campo cuando terminó la tormenta?',o:['Lleno de niebla','En silencio y brillando de agua','Cubierto de nieve'],a:1},
         {q:'¿Por qué seguía en pie la caña?',o:['Porque se inclinó ante el viento','Porque era más alta','Porque tenía raíces enormes'],a:0}]},
  {name:'La Lección del Campo',parts:[
   {t:'Ser flexible',x:'La fábula nos enseña que ser {flexible|Que se dobla sin romperse; también, que sabe adaptarse a los cambios.} es una gran virtud. A veces, ceder un poco nos ayuda a no perderlo todo.',lb:'¿Qué quiere decir ser flexible? Si no lo sabes, ¡toca la palabra!'},
   {t:'Fuerza y humildad',x:'La fuerza sirve, pero sin humildad puede volverse un problema. Quien escucha a los demás y sabe adaptarse suele salir adelante.',lb:'¿Por qué la fuerza sola no alcanza?'},
   {t:'Tu turno',x:'Piensa en alguna situación en la que fue mejor ceder que discutir. ¿Cómo te sentiste después? Seguro fuiste tan sabio como la caña.',lb:'Cuéntale a alguien de tu casa lo que aprendiste hoy 🏡'}],
   quiz:[{q:'¿Qué virtud muestra la caña?',o:['El orgullo','La flexibilidad y la humildad','La velocidad'],a:1},
         {q:'¿Qué nos enseña la fábula?',o:['Que hay que resistir siempre sin doblarse','Que los árboles grandes son invencibles','Que a veces ceder nos ayuda a salir adelante'],a:2}]}
 ]},
 {id:'astro',title:'El Pequeño Astronauta',genre:'Aventura',art:'space',open:false},
 {id:'cerditos',title:'Los Tres Cerditos',genre:'Clásico',art:'pigs',open:false},
 {id:'hansel',title:'Hansel y Gretel',genre:'Cuento clásico',art:'hansel',open:false},
 {id:'bella',title:'La Bella Durmiente',genre:'Fantasía',art:'castle',open:false}
];
