/* =====================  LIBRÍN COMPAÑERO · CONFIGURACIÓN  =====================
   Librín acompaña la lectura y los quizzes: aparece con un globito, dice
   comentarios y cambia de reacción (imágenes de img/librin/).
   Si el usuario eligió la voz de Librón, aparece Librón en su lugar (img/libron/),
   con las mismas reacciones: lo decide MASCOTA() de js/utils.js.
   - En la lectura dice la pregunta "lb" de cada parte (está en js/data/stories.js)
     y reacciona al audiolibro: cuando empieza, por la mitad, en pausa y al final.
     También explica las palabras del vocabulario.
   - En el quiz da ánimo, festeja los aciertos, consuela los errores y comenta el resultado.
   **Para cambiar lo que dice Librín o qué cara pone, se cambia acá.**
   Reacciones: saludo, bien, excelente, guino, vamos, orgullo, increible, animo,
   ojos-cerrados (feliz, aplaudiendo), aprender (con un libro), logrado (saltando). */
const COMP_CFG={
  temporal:5000,   // ms que dura un comentario de paso antes de volver a la pregunta de la parte

  lectura:{
    pregunta:'aprender',   // cara mientras muestra la pregunta de la parte
    // Si una parte no tiene "lb", dice una de estas según la parte (1, 2 o 3)
    generico:['¡Empieza una parte nueva! ¿Qué crees que va a pasar?','¿Te acuerdas de lo que pasó en la parte anterior?','¡Última parte del nivel! Lee con atención.'],
    antesDelQuiz:'Después de esta parte viene el quiz ⭐',
    empieza:['guino','¡A escuchar! Sigue con la vista las palabras que se pintan de azul 👀'],
    sigue:['guino','¡Seguimos!'],
    otraVez:['guino','¡Otra vez! Así te sale cada vez mejor.'],
    mitad:['vamos','¡Ya vas por la mitad! 💪'],
    pausa:['ojos-cerrados','Hacemos una pausa. Cuando quieras, seguimos 😌'],
    fin:['bien','¡Muy bien! Llegaste al final de esta parte 🎉'],
    finPregunta:'¿Ya puedes responder?',
    palabra:'aprender',    // cara cuando explica una palabra del vocabulario
    // Al tocar a Librín
    toques:[['excelente','¡Jeje, me haces cosquillas!'],['increible','¡Me encanta leer contigo!'],['orgullo','¡Qué bien estás leyendo!'],['guino','¡Sigue así!']]
  },

  quiz:{
    primera:['vamos',n=>`¡Vamos con la primera pregunta! Piensa en lo que leíste en «${n}».`],
    otra:['vamos','¡Otra más! Lee todas las opciones antes de elegir.'],
    ultima:['vamos','¡Última pregunta! Tú puedes 💪'],
    // Al acertar (van rotando)
    bien:[['bien','¡Muy bien hecho! 🎉'],['excelente','¡Excelente trabajo!'],['increible','¡Increíble! ¡Esa era!'],['orgullo','¡Estoy muy orgulloso de ti!']],
    // Al errar
    mal:[['animo',r=>`¡Casi! La respuesta correcta era: <b>${r}</b>. ¡No te rindas, lo estás logrando!`],
         ['vamos',r=>`Esta vez no. Era: <b>${r}</b>. ¡Vamos, tú puedes con la que sigue!`]],
    // Resultado
    perfecto:['increible','¡Increíble! ¡Respondiste todo bien!'],
    aprobado:['logrado','¡Lo lograste! Sabía que podías 😄'],
    cuento:['orgullo','¡Terminaste todo el cuento! Estoy muy orgulloso de ti.'],
    desaprobado:['ojos-cerrados','¡Cada día mejoras más! Repasa las partes y vuelve a intentarlo.']
  }
};
