'use strict';
/* =====================  UTILIDADES  ===================== */
const ESC=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
const seed=s=>()=>((s=(s*16807)%2147483647)/2147483647);

const ICON={
 trophy:'<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
 gear:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
 logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
 lock:'<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
 star:'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
 chev:'<path d="m9 18 6-6-6-6"/>',
 back:'<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
 right:'<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
 book:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
 check:'<path d="M20 6 9 17l-5-5"/>',
 casa:'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
 vol:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>'
};
const ic=(n,s=20,fill=false)=>`<svg class="ico" viewBox="0 0 24 24" width="${s}" height="${s}"${fill?' style="fill:currentColor"':''} aria-hidden="true">${ICON[n]}</svg>`;

/* Mascota: Librín, o Librón si el usuario eligió la voz de Librón (en Opciones o en el reproductor).
   Las imágenes están en img/librin/ e img/libron/ con los mismos nombres (una por reacción, todas de 513×508):
   'saludo' (la versión base), 'bien', 'excelente', 'guino', 'vamos', 'orgullo', 'increible', 'animo',
   'ojos-cerrados', 'aprender' y 'logrado'. */
const MASCOTA=()=>{
  const v=typeof S!=='undefined'?S.voz:'';
  return v==='personaje:libron'||v==='personaje:gigante' // "gigante" = nombre viejo de Librón
    ?{id:'libron',nombre:'Librón',carpeta:'img/libron/'}
    :{id:'librin',nombre:'Librín',carpeta:'img/librin/'};
};
const MASCOTA_IMG=(reaccion='saludo',ancho=88)=>`<img class="librin-mini" src="${MASCOTA().carpeta}${reaccion}.png" alt="" width="${ancho}" height="${Math.round(ancho*508/513)}" draggable="false">`;

