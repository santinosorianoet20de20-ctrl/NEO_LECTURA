/* =====================  NAVEGACIÓN  ===================== */
const $app=document.getElementById('app');
function applyPrefs(){
  const r=document.documentElement;
  r.style.setProperty('--fs',SIZES[S.size]||SIZES[0]);
  if(S.theme==='auto')r.removeAttribute('data-theme');else r.setAttribute('data-theme',S.theme);
}
function render(){
  applyPrefs();
  let h;
  if(!Login.activa())h=LoginVista.pantalla(); // sin sesión abierta → inicio de sesión (js/login)
  else if(R.s==='levels'&&story(R.sid)&&unlocked(R.sid,0))h=levelsScreen(R.sid); // un cuento bloqueado no se abre
  else if(R.s==='read'&&story(R.sid)&&story(R.sid).levels[R.l]&&unlocked(R.sid,R.l))h=readScreen(R);
  else if(R.s==='quiz'&&Q)h=quizScreen();
  else if(R.s==='ranking')h=RankingVista.pantalla(); // ranking de cuentas reales (js/ranking)
  else if(R.s==='settings')h=settingsScreen();
  else if(R.s==='credits')h=creditsScreen();
  else{R={s:'home'};h=homeScreen()}
  $app.innerHTML=h;
}
function parseTo(t){const a=t.split(':');return {s:a[0],sid:a[1],l:+a[2],p:+a[3]}}
function go(r){
  if(typeof r==='string')r=parseTo(r);
  if((r.s==='read'||r.s==='quiz')&&!unlocked(r.sid,r.l))return;
  if(r.s==='levels'&&!unlocked(r.sid,0))return; // cuento bloqueado: hay que aprobar el anterior
  if(r.s==='quiz'){
    if(partsRead(r.sid,r.l)<PARTS){toast('Primero lee las 3 partes del nivel 📖');return}
    Q={sid:r.sid,l:r.l,i:0,score:0,pick:null,end:false};
  }
  R=r;
  Audiolibro.detener(); // al cambiar de pantalla se corta el audio (js/audio)
  try{history.pushState(r,'')}catch(e){}
  render();window.scrollTo(0,0);
}
window.addEventListener('popstate',e=>{
  R=e.state||{s:'home'};
  if(R.s==='quiz')R={s:'levels',sid:R.sid};
  Audiolibro.detener(); // el botón "atrás" del navegador también corta el audio
  render();
});

/* Avisos y diálogos */
let tT;
function toast(t){
  let el=document.getElementById('toast');
  if(!el){el=document.createElement('div');el.id='toast';el.className='toast';el.setAttribute('role','status');document.body.appendChild(el)}
  el.textContent=t;el.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>el.classList.remove('show'),2000);
}
function ask(msg,label,fn){
  const m=document.createElement('div');m.className='modal';
  m.innerHTML=`<div class="mbox" role="dialog" aria-modal="true"><p>${msg}</p><div class="mrow"><button class="btn ghost" data-m="no">Cancelar</button><button class="btn pri" data-m="yes">${label}</button></div></div>`;
  m.addEventListener('click',e=>{const b=e.target.closest('[data-m]');
    if(e.target===m||(b&&b.dataset.m==='no'))m.remove();else if(b){m.remove();fn()}});
  document.body.appendChild(m);m.querySelector('[data-m="yes"]').focus();
}

/* Lógica de juego */
function markRead(sid,l,p){
  const k=kp(sid,l,p);
  if(!S.parts[k]){S.parts[k]=true;S.points+=50;save();toast('+50 puntos ⭐')}
}
function finishQuiz(){
  const s=story(Q.sid),L=s.levels[Q.l],n=L.quiz.length,k=kd(Q.sid,Q.l);
  const prev=S.quiz[k]||0,delta=Math.max(0,Q.score-prev)*100;
  // Cada cuento dice cuántas correctas hacen falta (más difícil en los niveles más largos)
  const pass=Q.score>=(L.aprobar||Math.ceil(n/2)),nuevo=pass&&!S.done[k],bonus=nuevo?150:0;
  S.quiz[k]=Math.max(prev,Q.score);
  if(pass)S.done[k]=true;
  // Si es la primera vez que se aprueba el último nivel del cuento, se desbloquea el cuento que sigue
  const abre=nuevo&&Q.l===s.levels.length-1?Camino.siguiente(Q.sid):null;
  const racha=pass?Racha.completarHoy():null; // primer quiz aprobado del día → +1 día de racha (js/racha)
  S.points+=delta+bonus+(racha?racha.bonus:0);save();
  Q.end=true;Q.res={delta,bonus,pass,racha,abre};
}
/* La lectura en voz alta (audiolibro) está en js/audio */

/* Eventos */
document.addEventListener('click',e=>{
  const t=e.target.closest('[data-a]');if(!t)return;
  const a=t.dataset.a,d=t.dataset;
  switch(a){
    case 'nav':go(d.to);break;
    case 'cont':{
      const sid=d.s,l=+d.l;let p=-1;
      for(let j=0;j<PARTS;j++){if(!S.parts[kp(sid,l,j)]){p=j;break}}
      go(p<0?{s:'quiz',sid,l}:{s:'read',sid,l,p});break;}
    case 'next':{
      markRead(R.sid,R.l,R.p);
      go(R.p<PARTS-1?{s:'read',sid:R.sid,l:R.l,p:R.p+1}:{s:'quiz',sid:R.sid,l:R.l});break;}
    case 'def':{
      if(Companero.definir(d.w,d.d))break; // la explica Librín (js/companero)
      const b=document.getElementById('def');if(!b)break;
      b.hidden=false;b.innerHTML='<b>'+ESC(d.w)+':</b> '+ESC(d.d);break;}
    case 'pick':{
      if(Q.pick!=null)break;
      const q=story(Q.sid).levels[Q.l].quiz[Q.i];
      Q.pick=+d.i;if(Q.pick===q.a)Q.score++;render();break;}
    case 'qnext':{
      const n=story(Q.sid).levels[Q.l].quiz.length;
      if(Q.i+1<n){Q.i++;Q.pick=null}else finishQuiz();
      render();window.scrollTo(0,0);
      if(Q.end&&Q.res.racha){const rc=Q.res.racha;setTimeout(()=>RachaControl.avisar(rc),900)} // después de las estrellas (se guarda antes: si reintenta rápido, Q ya es otro)
      break;}
    case 'size':S.size=+d.i;save();render();break;
    case 'voice':S.voice=!S.voice;save();render();break;
    case 'theme':S.theme=d.v;save();render();break;
    case 'reset':ask('¿Seguro que quieres borrar tus puntos, niveles y racha?','Reiniciar',()=>{
      S.points=DEF.points;S.parts={};S.quiz={};S.done={};Racha.reiniciar();save();toast('Progreso reiniciado');render()});break;
    case 'logout':ask('¿Quieres cerrar sesión? Tu progreso se guarda en este dispositivo.','Salir',()=>Login.salir());break;
  }
});
/* Nombre en Opciones: solo se guarda si es un nombre permitido (js/filtro); si no, se avisa debajo */
const nombreLimpio=v=>String(v||'').trim().replace(/\s+/g,' ');
function avisoNombre(input,err){
  const m=document.getElementById('setname-msg');
  if(m){m.textContent=err||'';m.hidden=!err}
  if(err)input.setAttribute('aria-invalid','true');else input.removeAttribute('aria-invalid');
}
document.addEventListener('input',e=>{
  if(e.target.id!=='setname')return;
  const v=nombreLimpio(e.target.value),err=LoginValidar.nombre(v);
  avisoNombre(e.target,err);
  if(!err&&v!==S.name){S.name=v;save()}
});
// Al salir del campo con un nombre no permitido, vuelve el último que estaba bien
document.addEventListener('focusout',e=>{
  if(e.target.id!=='setname'||!LoginValidar.nombre(nombreLimpio(e.target.value)))return;
  e.target.value=Filtro.mostrar(S.name);avisoNombre(e.target,'');
});
document.addEventListener('keydown',e=>{
  const t=e.target;
  if((e.key==='Enter'||e.key===' ')&&t.getAttribute&&t.getAttribute('role')==='button'){e.preventDefault();t.click()}
});

try{history.replaceState({s:'home'},'')}catch(e){}
render();