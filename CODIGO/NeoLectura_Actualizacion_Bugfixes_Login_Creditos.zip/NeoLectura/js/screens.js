/* =====================  PANTALLAS  ===================== */
const bar=(title,back)=>`<header class="hdr bar"><button class="back" data-a="nav" data-to="${back}">${ic('back',16)} Volver</button><h2>${ESC(title)}</h2><span></span></header>`;

function starsRow(){const n=starCount();return `<div class="stars" aria-label="${n} de 3 estrellas">${[0,1,2].map(i=>`<span class="${i<n?'on':''}">${ic('star',16,true)}</span>`).join('')}</div>`}

/* Tarjeta de un cuento en el camino: cada cuento es un nivel y se desbloquea al aprobar el anterior */
function storyCard(s){
  const img=cover(s),nv=`<span class="nv">${Camino.etiqueta(s.id)}</span>`;
  const cap=`<div class="cap"><b>${ESC(s.title)}</b><i>${ESC(s.autor||s.genre)}</i></div>`;
  if(!unlocked(s.id,0)){
    const a=Camino.anterior(s.id);
    return `<article class="story" aria-disabled="true" aria-label="${ESC(s.title)}: bloqueado"><div class="cover"><img src="${img}" alt="">${nv}
      <div class="veil">${ic('lock',26)}<span>Aprueba «${ESC(a?a.title:'')}»</span></div>${cap}</div><div class="foot">Bloqueado</div></article>`;
  }
  const hecho=Camino.aprobado(s.id),st=started(s.id);
  const tot=s.levels.length*PARTS,leidas=s.levels.reduce((n,_,l)=>n+partsRead(s.id,l),0);
  const pie=hecho?'Completado ✓ · Repasar':!st?'¡A leer!':leidas<tot?`Continuar · ${leidas}/${tot} partes`:'Falta el quiz ⭐';
  return `<article class="story open${hecho?' hecho':''}" data-a="nav" data-to="levels:${s.id}" role="button" tabindex="0" aria-label="Abrir ${ESC(s.title)}">
    <div class="cover"><img src="${img}" alt="">${nv}${hecho?`<span class="badge ok">${ic('check',14)}</span>`:st?'':'<span class="badge">¡Nuevo!</span>'}${cap}</div>
    <div class="foot">${pie}</div></article>`;
}

function homeScreen(){
  return `<header class="hdr home"><div><h1>NeoLectura</h1><div class="sub">Bienvenido, ${ESC(Filtro.mostrar(S.name))} ${S.avatar||'👋'}</div></div>
    <div class="acts">
      <button class="rbtn" data-a="nav" data-to="ranking" aria-label="Ranking">${ic('trophy',18)}</button>
      <button class="rbtn" data-a="nav" data-to="settings" aria-label="Opciones">${ic('gear',18)}</button>
      <button class="rbtn" data-a="logout" aria-label="Salir">${ic('logout',18)}</button>
    </div></header>
  <main>
    <section class="mcard">${MASCOTA_IMG('saludo')}<div><div class="mt">¡Elige un cuento!</div><div class="ms">Tienes <b>${fmt(S.points)} puntos</b></div>${starsRow()}</div>${RachaVista.indicador()}</section>
    <div class="sec"><h3>Camino de lectura</h3><span>${totalDone()} de ${STORIES.length} niveles completados</span></div>
    <div class="grid camino">${STORIES.map(storyCard).join('')}</div>
    <div class="links">
      <button class="link" data-a="nav" data-to="ranking"><span style="color:#F2A900">${ic('trophy',24)}</span>Ranking</button>
      <button class="link" data-a="nav" data-to="credits"><span style="color:var(--teal)">${ic('book',24)}</span>Créditos</button>
    </div>
  </main>`;
}

/* Pantalla de un cuento: sus partes + el quiz, y cuál es el nivel que sigue */
function levelsScreen(sid){
  const s=story(sid),sig=Camino.siguiente(sid);
  const lv=s.levels.map((L,i)=>{
    const et=Camino.etiqueta(sid,i);
    if(!unlocked(sid,i))return `<div class="lvl locked"><div class="lvl-top"><div class="num">${ic('lock',22)}</div><div class="t"><h4>${et}: ${ESC(L.name)}</h4><p>Bloqueado</p></div></div></div>`;
    const dn=!!S.done[kd(sid,i)],n=L.quiz.length,mejor=S.quiz[kd(sid,i)]||0;
    const steps=L.parts.map((p,j)=>{const r=!!S.parts[kp(sid,i,j)];
      return `<div class="step" data-a="nav" data-to="read:${sid}:${i}:${j}" role="button" tabindex="0" title="${ESC(p.t)}"><div class="circ ${r?'done':''}">${r?ic('check',18):j+1}</div><span class="lab">${ESC(p.t)}</span></div>`}).join('');
    return `<div class="lvl" data-a="cont" data-s="${sid}" data-l="${i}" role="button" tabindex="0">
      <div class="lvl-top"><div class="num">${s.nivel}</div><div class="t"><h4>${et}: ${ESC(L.name)}</h4><p>${dn?`Completado ✓ · Mejor quiz: ${mejor} de ${n}`:`Quiz de ${n} preguntas · Para aprobar: ${L.aprobar} correctas`}</p></div><span class="go">${ic('chev',22)}</span></div>
      <div class="steps">${steps}<div class="arrow">${ic('right',16)}</div>
      <div class="step q" data-a="nav" data-to="quiz:${sid}:${i}" role="button" tabindex="0"><div class="circ quiz ${dn?'done':''}">${ic('star',20,dn)}</div><span class="lab">Quiz</span></div></div></div>`;
  }).join('');
  // El nivel que sigue en el camino (bloqueado hasta aprobar este)
  const prox=!sig?'':unlocked(sig.id,0)
    ?`<div class="lvl prox" data-a="nav" data-to="levels:${sig.id}" role="button" tabindex="0"><div class="lvl-top"><div class="num">${sig.nivel}</div><div class="t"><h4>Sigue: ${Camino.etiqueta(sig.id)} · ${ESC(sig.title)}</h4><p>¡Ya está desbloqueado!</p></div><span class="go">${ic('chev',22)}</span></div></div>`
    :`<div class="lvl locked prox"><div class="lvl-top"><div class="num">${ic('lock',22)}</div><div class="t"><h4>Sigue: ${Camino.etiqueta(sig.id)} · ${ESC(sig.title)}</h4><p>Se desbloquea al aprobar el quiz de este cuento</p></div></div></div>`;
  return bar(s.title,'home')+`<main><div class="doc" style="max-width:none">
    <section class="mcard" style="min-height:102px;border-radius:24px">${MASCOTA_IMG('aprender')}<div><div class="mt">${Camino.etiqueta(sid)} · ${ESC(s.title)}</div><div class="ms">${ESC(s.autor)} · 3 partes + un quiz</div><div class="cnt">${sig?'Lee las 3 partes y aprueba el quiz para desbloquear el siguiente cuento.':'¡Es el último nivel del camino!'}</div></div></section>
    ${lv}${prox}</div></main>`;
}

function readScreen(r){
  const s=story(r.sid),L=s.levels[r.l],P=L.parts[r.p];
  const last=r.p===PARTS-1;
  // El dibujo de la escena de esta parte (img/escenas/<cuento>/parte-N; ver js/cuentos/cuentos.camino.js)
  return bar(s.title,'levels:'+r.sid)+`<main><div class="doc"><article class="paper">
    <div class="banner escena"><img src="${P.img||cover(s)}" alt=""></div>
    <div class="in"><div class="meta">${Camino.etiqueta(r.sid,r.l)}: ${ESC(L.name)} · Parte ${r.p+1} de ${PARTS}</div>
    <h2>${ESC(P.t)}</h2>
    ${canSpeak&&S.voice?AudioVista.reproductor(kp(r.sid,r.l,r.p),plain(P.x))+`
    <p class="txt" data-audio-texto>${AudioVista.textoSincronizado(P.x)}</p>`:`<p class="txt">${vocab(P.x)}</p>`}
    ${P.x.indexOf('{')>-1?`<p class="hint">Toca las palabras subrayadas y <span data-cp-nombre>${MASCOTA().nombre}</span> te cuenta qué significan.</p>`:''}
    ${CompaneroVista.lectura(P,r.p,last)}
    <div class="tools"><span></span>
      <div class="dots" aria-hidden="true">${[0,1,2].map(i=>`<i class="${i===r.p?'on':''}"></i>`).join('')}</div></div>
    <div class="nav">${r.p>0?`<button class="btn ghost" data-a="nav" data-to="read:${r.sid}:${r.l}:${r.p-1}">${ic('back',16)} Anterior</button>`:'<span></span>'}
      <button class="btn ${last?'gold':'pri'}" data-a="next">${last?'Ir al Quiz '+ic('star',18,true):'Siguiente '+ic('right',16)}</button></div>
    </div></article></div></main>`;
}

function quizScreen(){
  const s=story(Q.sid),L=s.levels[Q.l],n=L.quiz.length;
  const head=bar('Quiz · '+Camino.etiqueta(Q.sid,Q.l),'levels:'+Q.sid);
  if(Q.end){
    const r=Q.res,sig=Q.l<s.levels.length-1?null:Camino.siguiente(Q.sid),lastLv=Q.l===s.levels.length-1&&!sig;
    const msg=[`Acertaste ${Q.score} de ${n}.`];
    if(!r.pass)msg.push(`Para aprobar necesitas ${L.aprobar} correctas.`);
    if(r.delta)msg.push(`Ganaste +${fmt(r.delta)} puntos.`);
    if(r.bonus)msg.push(`Bono por completar el nivel: +${r.bonus}.`);
    if(r.racha)msg.push(`🔥 Racha de ${r.racha.dias} ${r.racha.dias===1?'día':'días'}: +${r.racha.bonus} puntos.`);
    const abre=r.abre?`<p class="res-abre">🔓 ¡Desbloqueaste el ${Camino.etiqueta(r.abre.id)}: <b>${ESC(r.abre.title)}</b>!</p>`:'';
    // "Repasa…" y "¡Terminaste…!" los dice la mascota (js/companero)
    // "Volver al menú" está siempre (va a la pantalla principal, con todos los cuentos)
    const menu=pri=>`<button class="btn ${pri?'pri':'ghost'}" data-a="nav" data-to="home">${ic('casa',18)} Volver al menú</button>`;
    const destino=sig?`read:${sig.id}:0:0`:`read:${Q.sid}:${Q.l+1}:0`;
    const btns=r.pass
      ?(lastLv?`<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Ver el cuento</button>${menu(true)}`
              :`${menu()}<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Ver el cuento</button><button class="btn pri" data-a="nav" data-to="${destino}">Siguiente nivel ${ic('right',16)}</button>`)
      :`${menu()}<button class="btn ghost" data-a="nav" data-to="levels:${Q.sid}">Repasar</button><button class="btn pri" data-a="nav" data-to="quiz:${Q.sid}:${Q.l}">Reintentar</button>`;
    const tam=n<=5?48:n<=8?36:30; // con más preguntas, estrellas más chicas
    return head+`<main><div class="doc"><div class="paper"><div class="in center" style="padding-top:28px">
      <div class="bigstars">${Array.from({length:n},(_,i)=>`<span class="${i<Q.score?'on':''}">${ic('star',tam,true)}</span>`).join('')}</div>
      <h2>${r.pass?'¡Nivel completado!':'¡Casi lo logras!'}</h2>
      ${CompaneroVista.quizResultado(r.pass,Q.score===n,lastLv,Q.score===0)}
      ${abre}<p class="res-txt">${msg.join(' ')}</p><div class="res-btns">${btns}</div></div></div></div></main>`;
  }
  const q=L.quiz[Q.i],pk=Q.pick;
  const opts=q.o.map((t,k)=>{let c='opt';if(pk!=null){if(k===q.a)c+=' ok';else if(k===pk)c+=' bad'}
    return `<button class="${c}" data-a="pick" data-i="${k}" ${pk!=null?'disabled':''}><span class="k">${'ABCDEF'[k]}</span>${ESC(t)}</button>`}).join('');
  // La mascota da ánimo antes de responder y reacciona a la respuesta (js/companero)
  const fb=pk==null?CompaneroVista.quizPregunta(Q.i,n,L.name):CompaneroVista.quizRespuesta(pk===q.a,Q.i,n,Q.score,q.o[q.a]);
  return head+`<main><div class="doc"><div class="paper"><div class="in">
    <div class="meta">Pregunta ${Q.i+1} de ${n}${q.parte?` · Sobre la parte ${q.parte}`:''}</div>
    <div class="pbar"><i style="width:${(Q.i+(pk!=null?1:0))/n*100}%"></i></div>
    <div class="qq">${ESC(q.q)}</div>${opts}${fb}
    ${pk!=null?`<div class="nav"><span></span><button class="btn pri" data-a="qnext">${Q.i+1<n?'Siguiente':'Ver resultado'} ${ic('right',16)}</button></div>`:''}
    </div></div></div></main>`;
}

const AVC=['#F26B1D','#35BFC0','#1B7DCB','#8E63D4','#E0568A','#3BAA6B','#D99A00','#5C7CFA','#E06666'];
/* La pantalla del ranking está en js/ranking/ranking.view.js */

function creditsScreen(){
  return bar('Créditos','home')+`<main><div class="doc">
    <section class="mcard">${MASCOTA_IMG('bien')}<div><div class="mt">NeoLectura</div><div class="ms">Plantilla de lectura dinámica</div></div></section>
    <section class="set credit equipo"><h4><span style="color:var(--teal)">${ic('equipo',22)}</span>Equipo</h4>
      <p>${ESC(EQUIPO.nombre)}, conformado por: ${EQUIPO.integrantes.map(ESC).join('; ')}</p>
      <ul class="roles">${EQUIPO.roles.map(([rol,quien])=>`<li><span>${ESC(rol)}</span><b>${ESC(quien)}</b></li>`).join('')}</ul></section>
    <section class="set credit"><h4><span style="color:var(--teal)">${ic('book',22)}</span>Cuentos</h4><p>Caperucita Roja, El gato con botas y Barba Azul, de Charles Perrault, y Hansel y Gretel, de los hermanos Grimm. Textos de dominio público.</p></section>
    <section class="set credit"><h4><span style="color:var(--teal)">${ic('star',22)}</span>Ilustraciones</h4><p>Dibujos simples de cada escena, hechos para este prototipo. Pronto llegan las versiones finales.</p></section>
    <section class="set credit"><h4><span style="color:var(--teal)">${ic('vol',22)}</span>Lectura en voz alta</h4><p>Usa la voz del navegador o del dispositivo, por lo que puede sonar distinto según el equipo.</p></section>
  </div></main>`;
}

function settingsScreen(){
  const themes=[['auto','Automático'],['light','Claro'],['dark','Oscuro']];
  return bar('Opciones','home')+`<main><div class="doc">
    <section class="mcard"><span style="color:var(--blue)">${ic('gear',44)}</span><div><div class="mt">Opciones</div><div class="ms">Ajusta NeoLectura a tu gusto</div></div></section>
    <section class="set"><h4>Tu nombre</h4><p>Aparece en la pantalla principal y en el ranking. Para entrar sigues usando tu usuario.</p><input id="setname" class="inp" maxlength="14" value="${ESC(Filtro.mostrar(S.name))}" autocomplete="off" aria-label="Tu nombre" aria-describedby="setname-msg"><p class="set-err" id="setname-msg" aria-live="polite" hidden></p></section>
    <section class="set"><h4>Tamaño de letra</h4><p>Cambia el tamaño del texto de los cuentos.</p>
      <div class="chips">${SIZE_NAMES.map((n,i)=>`<button class="chip ${S.size===i?'on':''}" data-a="size" data-i="${i}">${n}</button>`).join('')}</div>
      <p class="prev" style="font-size:var(--fs)">Así se verá el texto del cuento.</p></section>
    <section class="set two"><div><h4>Lectura en voz alta</h4><p>Muestra el reproductor de audio en cada parte del cuento.</p></div>
      <button class="sw ${S.voice?'on':''}" data-a="voice" role="switch" aria-checked="${S.voice}" aria-label="Lectura en voz alta"></button></section>
    ${canSpeak&&S.voice?AudioVista.opcionesVoz()+AudioVista.opciones():''}
    <section class="set"><h4>Tema</h4><p>El modo Claro es el diseño original.</p>
      <div class="chips">${themes.map(([v,n])=>`<button class="chip ${S.theme===v?'on':''}" data-a="theme" data-v="${v}">${n}</button>`).join('')}</div></section>
    <section class="set"><h4>Progreso</h4><p>Borra tus puntos y niveles para empezar de nuevo.</p><button class="btn danger" data-a="reset" style="margin-top:12px">Reiniciar progreso</button></section>
  </div></main>`;
}

/* La pantalla de inicio de sesión está en js/login/login.view.js */

