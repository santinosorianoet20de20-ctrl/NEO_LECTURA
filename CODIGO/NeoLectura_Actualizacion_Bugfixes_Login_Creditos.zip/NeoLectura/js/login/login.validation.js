/* =====================  LOGIN · VALIDACIONES  =====================
   Cada función devuelve '' si el dato está bien, o el mensaje de error. */
const LoginValidar=(()=>{
  const REG=LOGIN_CFG.reglas,M=LOGIN_CFG.msg;

  /* Usuario para ENTRAR: solo la forma (así una cuenta vieja siempre puede entrar) */
  function usuario(v){
    v=String(v||'').trim();
    if(!v)return M.usuarioVacio;
    if(/\s/.test(v))return M.usuarioEspacios;
    if(v.length<REG.usuarioMin)return M.usuarioCorto;
    if(!REG.usuarioRegex.test(v))return M.usuarioRaro;
    return '';
  }
  /* Usuario para CREAR una cuenta: la forma + el filtro de palabras (js/filtro).
     Es también el nombre que se muestra, así que tiene que ser amable */
  function usuarioNuevo(v){
    return usuario(v)||Filtro.revisar(String(v||'').trim());
  }
  /* Nombre que se muestra a partir del usuario: con la primera letra en mayúscula ("sofía_10" → "Sofía_10") */
  const nombreDe=u=>{u=String(u||'').trim();return u.charAt(0).toUpperCase()+u.slice(1)};
  function clave(v){
    v=String(v||'');
    if(!v)return M.claveVacia;
    if(v.length<REG.claveMin)return M.claveCorta;
    return '';
  }
  /* Nombre que se muestra (se cambia en Opciones): letras, números y espacios + el filtro de palabras */
  function nombre(v){
    v=String(v||'').trim();
    if(!v)return M.nombreVacio;
    if(v.length<REG.nombreMin)return M.nombreCorto;
    if(v.length>REG.nombreMax||!/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9' ._-]+$/.test(v))return M.nombreRaro;
    return Filtro.revisar(v);
  }
  /* Fuerza de la contraseña de 0 a 3 (se muestra como estrellas) */
  function fuerza(c){
    c=String(c||'');
    if(c.length<REG.claveMin)return 0;
    const letras=/[a-zñ]/i.test(c),numeros=/\d/.test(c),extra=/[A-ZÑ]/.test(c)||/[^a-z0-9ñ]/i.test(c);
    if(c.length>=8&&letras&&numeros&&extra)return 3;
    if(c.length>=6&&letras&&numeros)return 2;
    return 1;
  }
  return {usuario,usuarioNuevo,nombreDe,clave,nombre,fuerza};
})();
