/* =====================  LOGIN · ALMACENAMIENTO  =====================
   Cuentas de usuario y sesión.
   - Las cuentas se guardan en localStorage (quedan en este dispositivo).
   - La sesión se guarda en sessionStorage: dura mientras la pestaña esté
     abierta, así que al volver a abrir la app aparece el inicio de sesión.
   - La contraseña nunca se guarda tal cual: se guarda su hash (SHA-256).
   NOTA: es un prototipo sin servidor. En una app real las cuentas y las
   contraseñas se verifican en un servidor, no en el navegador.          */
const LoginStorage=(()=>{
  const K={cuentas:'neolectura.cuentas',recordar:'neolectura.recordar',sesion:'neolectura.sesion'};
  let memSesion=null; // respaldo por si el navegador bloquea sessionStorage

  /* --- Lectura/escritura segura (si el almacenamiento falla, no se rompe la app) --- */
  const local=()=>{try{return window.localStorage}catch(e){return null}};
  const sesionSt=()=>{try{return window.sessionStorage}catch(e){return null}};
  function leer(st,k,def){try{const v=st.getItem(k);return v?JSON.parse(v):def}catch(e){return def}}
  function escribir(st,k,v){try{if(v==null)st.removeItem(k);else st.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  // El usuario se guarda en minúscula y sin tildes (la ñ queda): "Sofía" y "sofia" son la misma cuenta
  const id=u=>String(u||'').trim().toLowerCase().replace(/ñ/g,'\u0000').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\u0000/g,'ñ');

  /* --- Hash de la contraseña --- */
  function hashSimple(t){ // cyrb53: respaldo si no está disponible crypto.subtle
    let h1=0xdeadbeef,h2=0x41c6ce57;
    for(let i=0,ch;i<t.length;i++){ch=t.charCodeAt(i);h1=Math.imul(h1^ch,2654435761);h2=Math.imul(h2^ch,1597334677)}
    h1=Math.imul(h1^(h1>>>16),2246822507);h1^=Math.imul(h2^(h2>>>13),3266489909);
    h2=Math.imul(h2^(h2>>>16),2246822507);h2^=Math.imul(h1^(h1>>>13),3266489909);
    return (4294967296*(2097151&h2)+(h1>>>0)).toString(16);
  }
  async function hash(usuario,clave,alg){
    const texto='neolectura|'+id(usuario)+'|'+clave; // el usuario funciona como "sal"
    if(alg!=='simple'&&window.crypto&&crypto.subtle&&window.TextEncoder){
      try{
        const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(texto));
        return {alg:'sha256',valor:Array.from(new Uint8Array(buf),b=>b.toString(16).padStart(2,'0')).join('')};
      }catch(e){}
    }
    return {alg:'simple',valor:hashSimple(texto)};
  }

  /* --- Cuentas --- */
  function cuentas(){const c=leer(local(),K.cuentas,[]);return Array.isArray(c)?c:[]}
  const guardar=lista=>escribir(local(),K.cuentas,lista);
  const buscar=u=>cuentas().find(c=>c.usuario===id(u))||null;

  async function crear({usuario,nombre,avatar,clave}){
    const h=await hash(usuario,clave);
    const ahora=Date.now();
    const cuenta={usuario:id(usuario),nombre:String(nombre).trim(),avatar,clave:h.valor,alg:h.alg,creada:ahora,ultimo:ahora};
    const lista=cuentas();lista.push(cuenta);
    return guardar(lista)?cuenta:null;
  }
  async function verificar(cuenta,clave){
    const h=await hash(cuenta.usuario,clave,cuenta.alg);
    return h.valor===cuenta.clave;
  }
  function actualizar(u,cambios){
    const lista=cuentas(),i=lista.findIndex(c=>c.usuario===id(u));
    if(i<0)return;
    Object.assign(lista[i],cambios);guardar(lista);
  }
  const marcarIngreso=u=>actualizar(u,{ultimo:Date.now()});
  const recientes=(n=4)=>cuentas().sort((a,b)=>(b.ultimo||0)-(a.ultimo||0)).slice(0,n);

  /* --- "Recordar mi usuario" --- */
  const recordado=()=>leer(local(),K.recordar,'')||'';
  const recordar=u=>escribir(local(),K.recordar,u?id(u):null);

  /* --- Sesión actual (usuario:null = invitado) --- */
  const sesion=()=>leer(sesionSt(),K.sesion,null)||memSesion;
  function abrirSesion(u){memSesion={usuario:u?id(u):null,desde:Date.now()};escribir(sesionSt(),K.sesion,memSesion)}
  function cerrarSesion(){memSesion=null;escribir(sesionSt(),K.sesion,null)}

  return {cuentas,buscar,crear,verificar,actualizar,marcarIngreso,recientes,recordado,recordar,sesion,abrirSesion,cerrarSesion};
})();
