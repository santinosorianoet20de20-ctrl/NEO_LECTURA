/* =====================  LOGIN · VISTA  =====================
   Arma el HTML de la pantalla de inicio de sesión (igual que las demás
   pantallas de screens.js, devuelve un texto con el HTML).              */
const LoginVista=(()=>{
  const C=LOGIN_CFG,RG=C.reglas;

  /* Íconos extra que usa el login (se suman a los de utils.js) */
  Object.assign(ICON,{
    eye:'<path d="M2.06 12.35a1 1 0 0 1 0-.7 10.75 10.75 0 0 1 19.88 0 1 1 0 0 1 0 .7 10.75 10.75 0 0 1-19.88 0"/><circle cx="12" cy="12" r="3"/>',
    eyeoff:'<path d="M10.73 5.08a10.74 10.74 0 0 1 11.2 6.57 1 1 0 0 1 0 .7 10.75 10.75 0 0 1-1.44 2.49"/><path d="M14.08 14.16a3 3 0 0 1-4.24-4.24"/><path d="M17.48 17.5a10.75 10.75 0 0 1-15.42-5.15 1 1 0 0 1 0-.7 10.75 10.75 0 0 1 4.45-5.14"/><path d="m2 2 20 20"/>',
    alert:'<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>'
  });

  /* Fondo: burbujas de vidrio que suben despacito */
  function fondo(){
    const r=seed(20);let bur='';
    for(let i=0;i<C.decor.burbujas;i++){
      bur+=`<i class="lg-bub" style="--x:${(r()*96).toFixed(1)}%;--s:${(24+r()*80).toFixed(0)}px;--d:${(18+r()*16).toFixed(1)}s;--w:-${(r()*34).toFixed(1)}s"></i>`;
    }
    return `<div class="lg-bg" aria-hidden="true"><i class="lg-glow g1"></i><i class="lg-glow g2"></i>${bur}</div>`;
  }

  /* Campo con etiqueta oculta (se ve el placeholder, como en el diseño), mensaje y ojo opcional */
  function campo(o){
    const msg=o.id+'-msg';
    return `<div class="lg-field">
      <label class="vh" for="${o.id}">${o.label}</label>
      <div class="lg-inp">
        <input id="${o.id}" name="${o.name}" type="${o.clave?'password':'text'}"${o.clave?' data-clave':''} maxlength="${o.max}" autocomplete="${o.auto}" autocapitalize="${o.cap||'off'}" autocorrect="off" spellcheck="false" placeholder="${o.label}" value="${ESC(o.valor||'')}" aria-describedby="${msg}">
        ${o.clave?`<button type="button" class="lg-eye" data-login="ojo" data-for="${o.id}" aria-label="Mostrar contraseña" aria-pressed="false">${ic('eye',18)}</button>`:''}
      </div>
      <p class="lg-msg" id="${msg}" aria-live="polite"></p>${o.extra||''}
    </div>`;
  }

  function avatares(){
    return `<fieldset class="lg-avs"><legend>Elige tu personaje</legend><div class="lg-av-grid">${C.avatares.map((a,i)=>
      `<label class="lg-av${i===0?' on':''}" style="--av-bg:${a.bg};--av-ring:${a.ring}" title="${a.nombre}">
        <input type="radio" name="avatar" value="${a.id}"${i===0?' checked':''} aria-label="${a.nombre}"><span aria-hidden="true">${LOGIN_EMOJI(a)}</span></label>`).join('')}</div></fieldset>`;
  }

  const medidor=()=>`<div class="lg-meter" data-n="0"><span class="lg-stars" aria-hidden="true">${[0,1,2].map(()=>`<i>${ic('star',14,true)}</i>`).join('')}</span><b>${C.fuerza[0]}</b></div>`;

  function formEntrar(rec){
    return `<form id="lg-form-entrar" class="lg-panel" aria-labelledby="lg-h-entrar" novalidate>
      <h2 id="lg-h-entrar">Iniciar Sesión</h2>
      ${campo({id:'lg-u',name:'usuario',label:'Usuario',max:RG.usuarioMax,auto:'username',valor:rec})}
      ${campo({id:'lg-p',name:'clave',label:'Contraseña',clave:true,max:RG.claveMax,auto:'current-password'})}
      <div class="lg-row">
        <label class="lg-check"><input type="checkbox" name="recordar"${rec?' checked':''}><span class="lg-box" aria-hidden="true">${ic('check',12)}</span>Recordarme</label>
        <button type="button" class="lg-link" data-login="olvide">¿Olvidaste tu contraseña?</button>
      </div>
      <button class="lg-btn lg-pri" type="submit"><span>Entrar</span><span aria-hidden="true">🚀</span></button>
      <p class="lg-or"><span>¿Todavía no tienes cuenta?</span></p>
      <button type="button" class="lg-btn lg-sec" data-login="ir-crear"><span>Crear cuenta</span><span aria-hidden="true">✨</span></button>
    </form>`;
  }

  function formCrear(){
    return `<form id="lg-form-crear" class="lg-panel" aria-labelledby="lg-h-crear" novalidate hidden>
      <h2 id="lg-h-crear">Crear Cuenta</h2>
      ${campo({id:'lg-cu',name:'usuario',label:'Elige tu nombre de usuario',max:RG.usuarioMax,auto:'username',extra:`<p class="lg-hint">${C.textos.ayudaUsuario}</p>`})}
      ${campo({id:'lg-cp',name:'clave',label:'Crea una contraseña',clave:true,max:RG.claveMax,auto:'new-password',extra:medidor()})}
      ${avatares()}
      <button class="lg-btn lg-pri" type="submit"><span>Crear mi cuenta</span><span aria-hidden="true">✨</span></button>
      <p class="lg-alt">¿Ya tienes cuenta? <button type="button" class="lg-link" data-login="ir-entrar">Inicia sesión</button></p>
    </form>`;
  }

  /* Pantalla completa */
  function pantalla(){
    const rec=LoginStorage.recordado(),cuenta=rec?LoginStorage.buscar(rec):null;
    const saludo=cuenta?C.frases.deNuevo(Filtro.mostrar(cuenta.nombre)):C.frases.hola;
    return `<div class="lg" data-panel="entrar">${fondo()}
      <div class="lg-wrap">
        <header class="lg-head"><h1>${C.textos.titulo}</h1><p>${C.textos.lema}</p></header>
        <div class="lg-stage">
          <button type="button" class="librin" data-login="librin" data-mood="idle" aria-label="${C.textos.librinAria}">${Librin.html()}</button>
          <p class="lg-bubble pop" id="lg-bubble" role="status" data-t="${ESC(saludo)}">${ESC(saludo)}</p>
        </div>
        <section class="lg-card" aria-label="Inicio de sesión">
          ${formEntrar(cuenta?cuenta.usuario:'')}
          ${formCrear()}
        </section>
        <button type="button" class="lg-guest" data-login="invitado">o entra como invitado</button>
      </div>
    </div>`;
  }

  return {pantalla};
})();
