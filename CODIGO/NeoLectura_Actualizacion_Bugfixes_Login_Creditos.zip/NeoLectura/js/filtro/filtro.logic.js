/* =====================  FILTRO DE NOMBRES · LÓGICA  =====================
   Filtro.revisar(texto) → '' si el nombre está bien, o el mensaje de por qué no.
   Filtro.permitido(texto) → true / false.
   Filtro.mostrar(nombre)  → el nombre, o "Lector" si no está permitido
                             (para cuentas creadas antes de que existiera el filtro).
   Las listas están en filtro.config.js.

   Cómo revisa un nombre:
   1. Lo pasa a minúscula y le saca las tildes (la ñ queda).
   2. Arma varias "formas" para atrapar trampas:
      - con los números como letras (0→o, 1→i, 3→e, 4→a, 5→s, 7→t, @→a, $→s);
      - con las letras repetidas juntadas ("puuuta" → "puta").
   3. En cada forma busca las "partes" en todo el nombre pegado (sin espacios
      ni símbolos) y las "enteras" palabra por palabra.                       */
const Filtro=(()=>{
  const C=FILTRO_CFG;
  const LEET={'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s','!':'i'};

  // Minúscula y sin tildes ni diéresis (la ñ se mantiene: es otra letra)
  const base=t=>String(t||'').toLowerCase().replace(/ñ/g,'\u0000').normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/\u0000/g,'ñ');
  const leet=t=>t.replace(/[013457@$!]/g,c=>LEET[c]);
  const tres=t=>t.replace(/(.)\1{2,}/g,'$1$1'); // "puuuuta" → "puuta"
  const una=t=>t.replace(/(.)\1+/g,'$1');        // "puuta"   → "puta"
  const dobles=w=>/(.)\1/.test(w);
  const LET=/[a-zñ]+/g;

  /* Las formas de un texto: cada una con el texto pegado (solo letras) y sus palabras */
  function formas(t){
    const b=base(t),res=[];
    for(const x of [b,leet(b)]){
      const v1=tres(x),v2=una(v1);
      res.push({junto:(x.match(LET)||[]).join(''),palabras:x.match(LET)||[],soloSimples:false}); // tal cual ("xxx", "kkk")
      res.push({junto:(v1.match(LET)||[]).join(''),palabras:v1.match(LET)||[],soloSimples:false});
      // con todas las letras juntadas solo se comparan palabras sin letras dobles ("zorra" no, para no bloquear "Zora")
      res.push({junto:(v2.match(LET)||[]).join(''),palabras:v2.match(LET)||[],soloSimples:true});
    }
    return res;
  }

  /* ¿Aparece alguna de estas palabras en el texto? */
  function aparece(f,partes,enteras){
    let junto=f.junto;
    for(const p of C.permitidas)junto=junto.split(p).join('·'); // las palabras inocentes no cuentan
    const ok=w=>!f.soloSimples||!dobles(w);
    if(partes.some(p=>ok(p)&&junto.includes(p)))return true;
    return enteras.some(w=>ok(w)&&(f.palabras.includes(w)||f.junto===w));
  }

  function revisar(texto){
    const t=String(texto||'');
    const b=base(t);
    if(((b.match(/[a-zñ]/g))||[]).length<2)return C.msg.letras;
    const numeros=(t.match(/\d/g)||[]).length;
    if(numeros>C.maxNumeros||C.datosPersonales.some(d=>b.includes(d)))return C.msg.datos;
    const F=formas(t);
    if(F.some(f=>aparece(f,C.partes,C.enteras)))return C.msg.palabra;
    if(F.some(f=>aparece(f,C.reservados.partes,C.reservados.enteras)))return C.msg.reservado;
    return '';
  }
  const permitido=t=>!revisar(t);
  const mostrar=n=>permitido(n)?String(n):C.reemplazo;

  return {revisar,permitido,mostrar,base};
})();
