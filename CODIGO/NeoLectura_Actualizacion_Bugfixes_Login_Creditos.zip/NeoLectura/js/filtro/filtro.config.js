/* =====================  FILTRO DE NOMBRES · LISTAS  =====================
   Palabras que no se permiten en los nombres de usuario ni en el nombre que
   se muestra (Opciones y ranking). NeoLectura es para chicos de primaria:
   nada de malas palabras, insultos, temas fuertes ni datos personales.

   Cómo se escriben las palabras (para agregar o sacar una):
   - En minúscula y SIN tildes (la ñ sí se escribe: "coño").
   - "partes": se buscan en cualquier lugar del nombre, aunque esté pegado a
     otras palabras o separado con puntos ("elpelotudo", "m.i.e.r.d.a").
     Sirven para palabras que no aparecen dentro de palabras inocentes.
   - "enteras": solo cuentan si son una palabra completa ("culo" sí, pero
     "película" o "Vehículo" no). Sirven para palabras cortas que aparecen
     dentro de nombres comunes (pene → Penélope, verga → Vergara, coger → recoger).
   - "permitidas": palabras inocentes que contienen una de las "partes" y que
     no tienen que bloquearse (computadora contiene "puta", controlo contiene "trolo").
   - "reservados": nombres que podrían usarse para hacerse pasar por un adulto
     o por la app.
   El filtro también entiende trampas comunes: letras repetidas ("puuuta"),
   números en lugar de letras ("p0rn0", "1diota") y símbolos en el medio.
   El usuario nunca ve qué palabra se bloqueó (así no aprende a esquivarla).  */
const FILTRO_CFG={
  partes:[
    // Insultos y groserías (rioplatenses y generales)
    'pelotud','boludo','boluda','idiot','imbecil','estupid','tarado','tarada','mogolic','retrasad','subnormal',
    'gilipoll','pendej','cabron','malparid','hijodeputa','hijadeputa','hdp','lpm','lcdtm','ctm','conchetumadre',
    'conchatumadre','conchesumadre','sorete','mierd','carajo','cagon','cagar','cagad','caguen','pajer','ojete',
    'culiad','culiao','conchud','puta','puto','putit','petera','petero','chupame','chupala','chupalo','chupenla',
    'trolo','tortiller','maricon','villero','sudaca',
    // Contenido sexual
    'porno','porn','sexo','sexy','xxx','vagina','tetona','tetudo','tetuda','garch','poronga','pijud','vergud',
    'prostitu','violad','violac','violar',
    // Violencia y temas fuertes
    'asesin','suicid','terroris','masacr','genocid','degoll','descuartiz','tortur','secuestr','matate','matalo',
    'matenlo','muerete','nazi','hitler','kkk','esvastica',
    // Drogas y alcohol
    'droga','cocain','marihuan','mariguan','falopa','borrach','porrer','extasis','metanfet',
    // En inglés
    'fuck','shit','bitch','asshole','pussy','cunt','slut','whore','nigg','faggot','stfu','motherf','bastard'
  ],
  enteras:[
    // Palabras cortas que aparecen dentro de nombres o palabras inocentes
    'culo','culos','culito','orto','pene','penes','teta','tetas','tetita','pija','verga','chota','choto','concha',
    'cajeta','coger','cojer','cogida','paja','pete','marica','trola','zorra','forro','forra','coño',
    'matar','porro','faso','merca','lsd','fumon',
    'sex','dick','cock','fag','fck','fuk','wtf'
  ],
  permitidas:['comput','disput','diput','imput','reput','amput','deput','control','nazir','petrolo'],
  reservados:{
    partes:['admin','neolectura'],
    enteras:['moderador','moderadora','soporte','sistema','oficial','staff','root','profe','profesor','profesora',
             'maestro','maestra','seño','docente','director','directora']
  },
  // Datos personales: con tantos números juntos (o en total) podría ser un teléfono o un DNI
  maxNumeros:4,
  datosPersonales:['@','gmail','hotmail','outlook','yahoo','www','http','.com'],
  // Nombre que se muestra en lugar de uno no permitido (cuentas viejas en el ranking)
  reemplazo:'Lector',
  // Mensajes (no dicen qué palabra fue)
  msg:{
    palabra:'Ese nombre no está permitido. ¡Elige uno amable! 🙂',
    reservado:'Ese nombre está reservado. Elige otro.',
    datos:'No pongas números largos ni datos personales (teléfono, DNI o mail).',
    letras:'Tu nombre tiene que tener al menos 2 letras.'
  }
};
