const SIZES=['1.0625rem','1.3rem','1.6rem'],SIZE_NAMES=['Normal','Grande','Muy grande'];
const PARTS=3;

/* Créditos del equipo (pantalla Créditos). Para cambiar un nombre o un rol, se cambia acá. */
const EQUIPO={
  nombre:'Equipo 3',
  integrantes:['Jaime Valentín','Galiano Katia','Soriano Santino'],
  roles:[
    ['Organización y documentación','Soriano Santino'],
    ['Diseño visual','Galiano Katia'],
    ['Programación y correcciones','Jaime Valentín']
  ]
};

