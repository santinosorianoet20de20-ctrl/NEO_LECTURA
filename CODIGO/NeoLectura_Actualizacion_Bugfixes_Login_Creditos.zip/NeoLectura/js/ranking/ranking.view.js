/* =====================  RANKING · VISTA  =====================
   Pantalla del ranking: tarjeta de arriba (con la mascota) y una fila por cuenta. */
const RankingVista=(()=>{
  const T=RANKING_CFG.textos;
  const COLORES=typeof AVC!=='undefined'?AVC:['#F26B1D','#35BFC0','#1B7DCB','#8E63D4','#E0568A','#3BAA6B'];

  function filaHTML(x){
    x=Object.assign({},x,{nombre:Filtro.mostrar(x.nombre)}); // nombres de antes del filtro (js/filtro)
    const color=COLORES[(x.nombre.charCodeAt(0)+x.puesto)%COLORES.length];
    const av=x.avatar?`<div class="av" style="background:${color};font-size:20px">${x.avatar}</div>`
                     :`<div class="av" style="background:${color}">${ESC(x.nombre.charAt(0).toUpperCase())}</div>`;
    return `<div class="row ${x.yo?'me':''}"><div class="pos ${x.puesto<=3?'g'+x.puesto:''}">${x.puesto}</div>
      ${av}<div class="nm">${ESC(x.nombre)}${x.yo?`<small>${T.tu}</small>`:''}</div><div class="pts">${fmt(x.puntos)} ${T.pts}</div></div>`;
  }

  function pantalla(){
    const L=Ranking.lista(),invitado=!Ranking.usuarioActual(),yo=L.find(x=>x.yo);
    let cara,tit,det;
    if(invitado){cara='pensando';tit=T.invitadoTit;det=T.invitadoDet}
    else if(!L.length){cara='vos-podes';tit=T.vacioTit;det=T.vacioDet}
    else{cara='gran-trabajo';tit=T.bienYo(ESC(Filtro.mostrar(S.name)));det=yo?T.puesto(yo.puesto,L.length):''}
    const vacio=!L.length&&invitado?`<p class="rk-vacio">${T.vacioTit} ${T.vacioDet}</p>`:'';
    return bar(T.titulo,'home')+`<main><div class="doc">
      <section class="mcard">${MASCOTA_IMG(cara)}<div><div class="mt">${tit}</div><div class="ms">${det}</div>${invitado?'':starsRow()}</div></section>
      ${L.map(filaHTML).join('')}${vacio}
      <p class="rk-nota">${T.nota}</p></div></main>`;
  }

  return {pantalla};
})();
